/* =====================================================================
   Personaliza Studio — Motor de costos y precios
   Josephine | Personaliza y Crea

   Este archivo NO toca la página: solo hace cálculos. Así se puede
   probar por separado (ver pruebas/pruebas-costos.js).

   Todos los valores se pueden cambiar en Cotizador → Mis costos.
   Las claves antiguas se conservan para no perder lo que ya guardaste.
   ===================================================================== */

// [grupo, clave, etiqueta, valor, unidad, opciones(select)]
const AJUSTES_DEF = [
    ['Precio y ganancia', 'horaTrabajo', 'Tu hora de trabajo', 60, '$'],
    ['Precio y ganancia', 'modoGanancia', 'Cómo se calcula la ganancia', 'recargo', 'select',
        [['recargo', '% sobre el costo (recargo)'], ['margen', '% del precio de venta (margen)']]],
    ['Precio y ganancia', 'ganancia', 'Ganancia deseada', 75, '%'],
    ['Precio y ganancia', 'margenMinimo', 'Ganancia mínima (alerta si cobras menos)', 40, '%'],
    ['Precio y ganancia', 'esc1Desde', 'Mayoreo 1 desde', 30, 'pzs'],
    ['Precio y ganancia', 'desc30', 'Descuento mayoreo 1', 10, '%'],
    ['Precio y ganancia', 'esc2Desde', 'Mayoreo 2 desde', 100, 'pzs'],
    ['Precio y ganancia', 'desc100', 'Descuento mayoreo 2', 20, '%'],
    ['Precio y ganancia', 'redondeo', 'Redondeo del precio', 'auto', 'select',
        [['auto', 'Automático ($0.50 / $1 / $5)'], ['0', 'Sin redondeo'], ['0.5', 'A $0.50'], ['1', 'A $1'], ['5', 'A $5'], ['10', 'A $10']]],

    ['Costos indirectos', 'mermaPct', 'Merma o desperdicio de material', 0, '%'],
    ['Costos indirectos', 'desgastePct', 'Luz y desgaste de máquinas (sobre material)', 0, '%'],
    ['Costos indirectos', 'gastosPedido', 'Gastos fijos por pedido (se reparten)', 0, '$'],
    ['Costos indirectos', 'minDiseno', 'Diseño y preparación (cuando se cobra aparte)', 30, 'min'],

    ['Rollos (metro)', 'dtfTextilMetro', 'DTF textil — metro', 250, '$'],
    ['Rollos (metro)', 'dtfTextilAncho', 'DTF textil — ancho', 58, 'cm'],
    ['Rollos (metro)', 'dtfUVMetro', 'DTF UV — metro', 600, '$'],
    ['Rollos (metro)', 'dtfUVAncho', 'DTF UV — ancho', 58, 'cm'],
    ['Rollos (metro)', 'vinilMetro', 'Vinil adhesivo — metro', 400, '$'],
    ['Rollos (metro)', 'vinilAncho', 'Vinil adhesivo — ancho', 55, 'cm'],
    ['Rollos (metro)', 'vinilCorteMetro', 'Vinil de corte — metro', 0, '$'],
    ['Rollos (metro)', 'vinilCorteAncho', 'Vinil de corte — ancho', 30, 'cm'],
    ['Rollos (metro)', 'separacionRollo', 'Separación entre diseños en rollo', 0, 'cm'],

    ['Planillas', 'papelAdhesivo', 'Papel adhesivo tabloide', 11, '$'],
    ['Planillas', 'suajeAdhesivo', 'Corte de papel adhesivo', 25, '$'],
    ['Planillas', 'papelCouche', 'Papel couché tabloide', 11, '$'],
    ['Planillas', 'suajeCouche', 'Corte de couché', 40, '$'],
    ['Planillas', 'papelOpalina', 'Opalina tabloide', 11, '$'],
    ['Planillas', 'suajeOpalina', 'Corte de opalina', 40, '$'],
    ['Planillas', 'tabloideAncho', 'Tabloide — ancho', 48, 'cm'],
    ['Planillas', 'tabloideAlto', 'Tabloide — alto', 33, 'cm'],
    ['Planillas', 'tabloideMargen', 'Margen sin impresión por lado', 1.5, 'cm'],
    ['Planillas', 'separacionPlanilla', 'Separación entre diseños', 0, 'cm'],
    ['Planillas', 'planillaTatuaje', 'Planilla de tatuaje 20 × 28.5 cm', 50, '$'],
    ['Planillas', 'minPlanilla', 'Tu tiempo por planilla', 10, 'min'],

    ['Procesos extra', 'laminadoMate', 'Laminado mate (por planilla)', 0, '$'],
    ['Procesos extra', 'laminadoBrillante', 'Laminado brillante (por planilla)', 0, '$'],
    ['Procesos extra', 'laminadoHolografico', 'Laminado holográfico (por planilla)', 0, '$'],
    ['Procesos extra', 'empaquePieza', 'Empaque individual (por pieza)', 0, '$'],
    ['Procesos extra', 'minCorteManual', 'Corte manual (por pieza)', 0, 'min'],
    ['Procesos extra', 'minDepilado', 'Depilado de vinil (por pieza)', 0, 'min'],
    ['Procesos extra', 'minPlanchado', 'Planchado extra (por pieza)', 0, 'min'],
    ['Procesos extra', 'laserMin', 'Corte láser — uso de máquina', 0, '$/min'],
    ['Procesos extra', 'cncMin', 'Corte CNC con fresa — uso de máquina', 0, '$/min'],

    ['Textiles', 'playeraBlanca', 'Playera blanca (adulto o niño)', 45, '$'],
    ['Textiles', 'playeraNegra', 'Playera negra (adulto o niño)', 53, '$'],
    ['Textiles', 'sudadera', 'Sudadera con capucha', 200, '$'],
    ['Textiles', 'gorra', 'Gorra trucker', 25, '$'],
    ['Textiles', 'minPlayera', 'Tu tiempo por playera (incluye planchado)', 15, 'min'],
    ['Textiles', 'minSudadera', 'Tu tiempo por sudadera (incluye planchado)', 15, 'min'],
    ['Textiles', 'minGorra', 'Tu tiempo por gorra', 5, 'min'],

    ['Vasos y tazas', 'taza', 'Taza blanca 11 oz', 18, '$'],
    ['Vasos y tazas', 'tazaImpresion', 'Sublimación de taza (papel y tinta)', 5, '$'],
    ['Vasos y tazas', 'cajaSet', 'Caja y relleno del set de tazas', 80, '$'],
    ['Vasos y tazas', 'vasoMini', 'Vaso mini 700 ml', 17, '$'],
    ['Vasos y tazas', 'vasoChupon', 'Vaso chupón', 10, '$'],
    ['Vasos y tazas', 'minTaza', 'Tu tiempo por taza', 5, 'min'],
    ['Vasos y tazas', 'minSetTazas', 'Tu tiempo por set de tazas', 10, 'min'],
    ['Vasos y tazas', 'minVaso', 'Tu tiempo por vaso', 5, 'min'],

    ['Fiestas y eventos', 'lonaM2', 'Lona — metro cuadrado', 45, '$'],
    ['Fiestas y eventos', 'minLona', 'Tu tiempo por lona', 10, 'min'],
    ['Fiestas y eventos', 'coro_30x40', 'Coroplast 30 × 40 cm', 90, '$'],
    ['Fiestas y eventos', 'coro_50x60', 'Coroplast 50 × 60 cm', 100, '$'],
    ['Fiestas y eventos', 'coro_70x80', 'Coroplast 70 × 80 cm', 150, '$'],
    ['Fiestas y eventos', 'coro_90', 'Coroplast 90 cm', 220, '$'],
    ['Fiestas y eventos', 'coro_100', 'Coroplast 100 cm', 260, '$'],
    ['Fiestas y eventos', 'coro_110x150', 'Coroplast 110 × 150 cm', 600, '$'],
    ['Fiestas y eventos', 'coro_160x180', 'Coroplast 160 × 180 cm', 750, '$'],
    ['Fiestas y eventos', 'coro_mampara', 'Mampara 110 × 200 cm', 900, '$'],
    ['Fiestas y eventos', 'minCoroplast', 'Tu tiempo por figura de coroplast', 15, 'min'],
    ['Fiestas y eventos', 'cakeToppers', 'Cake toppers 6 cm (paquete de 30)', 12, '$'],
    ['Fiestas y eventos', 'minCakeToppers', 'Tu tiempo por paquete de toppers', 10, 'min'],
    ['Fiestas y eventos', 'gorroFiesta', 'Gorro de fiesta con cara', 12, '$'],
    ['Fiestas y eventos', 'minGorroFiesta', 'Tu tiempo por gorro', 5, 'min'],

    ['Regalos', 'carrito', 'Carrito coleccionable', 80, '$'],
    ['Regalos', 'empaqueCarrito', 'Empaque del carrito', 12, '$'],
    ['Regalos', 'minCarrito', 'Tu tiempo por carrito', 10, 'min'],
];
const AJUSTES_BASE = Object.fromEntries(AJUSTES_DEF.map(d => [d[1], d[3]]));
const KEY_AJUSTES = 'personalizaStudio_ajustesCostos';
const KEY_COSTOS_LIBRES = 'personalizaStudio_costosLibres';

function leerJSON(k, def) {
    try { const v = JSON.parse(localStorage.getItem(k)); return v === null || v === undefined ? (def === undefined ? {} : def) : v; }
    catch (e) { return def === undefined ? {} : def; }
}
function escribirJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
function obtenerAjustes() { return { ...AJUSTES_BASE, ...leerJSON(KEY_AJUSTES) }; }

/* ---------- Redondeo y ganancia ---------- */

// "auto": menos de $10 → a $0.50, menos de $100 → a $1, más → a $5
function redondearPrecio(v, modo) {
    if (modo === undefined) modo = 'auto';
    if (!isFinite(v)) return v;
    if (modo === '0' || modo === 0) return Math.round(v * 100) / 100;
    const x = v - 1e-9;
    if (modo === 'auto') {
        if (x < 10) return Math.ceil(x * 2) / 2;
        if (x < 100) return Math.ceil(x);
        return Math.ceil(x / 5) * 5;
    }
    const paso = parseFloat(modo);
    return paso > 0 ? Math.ceil(x / paso) * paso : Math.round(v * 100) / 100;
}

// Recargo: precio = costo × (1 + %). Margen: precio = costo ÷ (1 − %).
function precioConGanancia(costo, pct, modo) {
    if (modo === 'margen') return pct >= 100 ? Infinity : costo / (1 - pct / 100);
    return costo * (1 + pct / 100);
}
// Regresa ambas medidas para que nunca se confundan
function medirGanancia(precio, costo) {
    const g = precio - costo;
    return { ganancia: g, margen: precio > 0 ? g / precio * 100 : 0, recargo: costo > 0 ? g / costo * 100 : 0 };
}
function gananciaEnModo(precio, costo, modo) {
    const m = medirGanancia(precio, costo);
    return modo === 'margen' ? m.margen : m.recargo;
}

/* ---------- Acomodo en planillas y rollos ---------- */

// orient: 'auto' (lo que rinda más), 'normal' o 'girada'
function acomodar(w, h, areaW, areaH, sep, orient) {
    sep = sep || 0; orient = orient || 'auto';
    const calc = (pw, ph, rot) => {
        const cols = pw > 0 ? Math.floor((areaW + sep) / (pw + sep)) : 0;
        const rows = ph > 0 ? Math.floor((areaH + sep) / (ph + sep)) : 0;
        return { cols, rows, rend: cols * rows, etqW: pw, etqH: ph, rot };
    };
    const n = calc(w, h, false), r = calc(h, w, true);
    if (orient === 'normal') return n;
    if (orient === 'girada') return r;
    return r.rend > n.rend ? r : n;
}

// Largo de rollo necesario para "cantidad" piezas
function acomodarRollo(w, h, anchoRollo, sep, cantidad, permitirRotar) {
    sep = sep || 0;
    if (permitirRotar === undefined) permitirRotar = true;
    const opcion = (pw, ph, rot) => {
        const cols = Math.floor((anchoRollo + sep) / (pw + sep));
        if (cols < 1) return null;
        const filas = Math.ceil(cantidad / cols);
        const largo = filas * ph + Math.max(0, filas - 1) * sep;
        return { cols, filas, largo, etqW: pw, etqH: ph, rot, porPieza: (ph + sep) / cols };
    };
    const ops = [opcion(w, h, false)];
    if (permitirRotar) ops.push(opcion(h, w, true));
    const validas = ops.filter(Boolean);
    if (!validas.length) return null;
    const mejor = validas.reduce((a, b) => (b.largo < a.largo || (b.largo === a.largo && b.porPieza < a.porPieza)) ? b : a);
    mejor.desperdicio = mejor.largo > 0 ? Math.max(0, 1 - (cantidad * w * h) / (anchoRollo * mejor.largo)) : 0;
    return mejor;
}

// Costo de UNA pieza en rollo (para precios de lista)
function costoEnRollo(w, h, precioMetro, anchoRollo, sep) {
    const a = acomodarRollo(w, h, anchoRollo, sep || 0, 1, true);
    if (!a) return null;
    const opciones = [];
    [[w, h], [h, w]].forEach(([pw, ph]) => {
        const cols = Math.floor((anchoRollo + (sep || 0)) / (pw + (sep || 0)));
        if (cols > 0) opciones.push((ph + (sep || 0)) / cols);
    });
    return Math.min(...opciones) / 100 * precioMetro;
}
function tabloideUtil(A) {
    return { w: A.tabloideAncho - 2 * A.tabloideMargen, h: A.tabloideAlto - 2 * A.tabloideMargen };
}

/* ---------- Procesos ---------- */

const PROCESOS = {
    material: 'Material base', impresion: 'Impresión', diseno: 'Diseño', dtf_textil: 'DTF textil', dtf_uv: 'DTF UV',
    sublimacion: 'Sublimación', vinil: 'Vinil adhesivo', vinil_corte: 'Vinil de corte', laminado: 'Laminado',
    corte_manual: 'Corte manual', suaje: 'Suaje / corte', corte_laser: 'Corte láser', cnc: 'Corte CNC',
    depilado: 'Depilado de vinil', planchado: 'Planchado', empaque: 'Empaque', mano_obra: 'Mano de obra',
    desgaste: 'Luz y desgaste', merma: 'Merma', extra: 'Gastos adicionales'
};

const ESTAMPADOS = { 'Chico 10 × 10 cm': [10, 10], 'Mediano 25 × 30 cm': [25, 30], 'Grande 30 × 40 cm': [30, 40] };
const dtfTextil = (A, nombre) => costoEnRollo(...ESTAMPADOS[nombre], A.dtfTextilMetro, A.dtfTextilAncho, A.separacionRollo);
const PAPELES = {
    'Papel adhesivo': ['papelAdhesivo', 'suajeAdhesivo'],
    'Papel couché': ['papelCouche', 'suajeCouche'],
    'Opalina': ['papelOpalina', 'suajeOpalina']
};
const ROLLOS = {
    'Vinil adhesivo': ['vinilMetro', 'vinilAncho', 'vinil'],
    'Vinil de corte': ['vinilCorteMetro', 'vinilCorteAncho', 'vinil_corte'],
    'DTF textil': ['dtfTextilMetro', 'dtfTextilAncho', 'dtf_textil'],
    'DTF UV': ['dtfUVMetro', 'dtfUVAncho', 'dtf_uv']
};
const CORO = { '30 × 40 cm': 'coro_30x40', '50 × 60 cm': 'coro_50x60', '70 × 80 cm': 'coro_70x80', '90 cm': 'coro_90', '100 cm': 'coro_100', '110 × 150 cm': 'coro_110x150', '160 × 180 cm': 'coro_160x180', 'Mampara 110 × 200 cm': 'coro_mampara' };
const TAM_STICKER = ['1 cm', '2 cm', '3 cm', '4 cm', '5 cm', '6 cm', '7 cm', '8 cm', '9 cm', '10 cm'];
const cm = s => parseFloat(s);

function planillaPapel(A, papel, w, h, detalle) {
    const u = tabloideUtil(A); const [p, s] = PAPELES[papel];
    return {
        modo: 'planilla', w, h, plW: A.tabloideAncho, plH: A.tabloideAlto, uW: u.w, uH: u.h, sep: A.separacionPlanilla,
        lineasLote: [{ c: `${papel} tabloide`, m: A[p], proc: 'impresion' }, { c: 'Suaje / corte', m: A[s], proc: 'suaje' }],
        minLote: A.minPlanilla, soporte: `${papel} tabloide`, detalle,
        incluidos: ['material', 'impresion', 'suaje', 'mano_obra']
    };
}

/* Cada producto regresa:
   modo 'pieza'    → lineas (material por pieza) + min (minutos por pieza)
   modo 'planilla' → lineasLote (material por planilla) + minLote
   modo 'rollo'    → medida en rollo
   incluidos       → procesos que YA están en el costo base (no se pueden volver a cobrar) */
const PRODUCTOS_COT = [
    { id: 'playera', nombre: '👕 Playera', cat: 'Textiles', opciones: [
        { id: 'talla', label: 'Talla', choices: ['Adulto', 'Infantil'], sinPrecio: true },
        { id: 'color', label: 'Color', choices: ['Blanca', 'Negra'] },
        { id: 'est', label: 'Estampado DTF', choices: Object.keys(ESTAMPADOS), def: 'Mediano 25 × 30 cm' }],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: `Playera ${o.color.toLowerCase()}`, m: o.color === 'Negra' ? A.playeraNegra : A.playeraBlanca, proc: 'material' },
            { c: `DTF textil ${o.est.replace(/^\S+ /, '')}`, m: dtfTextil(A, o.est), proc: 'dtf_textil' }],
          min: A.minPlayera, incluidos: ['material', 'dtf_textil', 'planchado', 'mano_obra'], detalle: `${o.talla}, ${o.color}, estampado ${o.est}` }) },
    { id: 'sudadera', nombre: '🧥 Sudadera con capucha', cat: 'Textiles', opciones: [
        { id: 'est', label: 'Estampado DTF (frente)', choices: Object.keys(ESTAMPADOS), def: 'Mediano 25 × 30 cm' }],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: 'Sudadera con capucha', m: A.sudadera, proc: 'material' },
            { c: `DTF textil ${o.est.replace(/^\S+ /, '')}`, m: dtfTextil(A, o.est), proc: 'dtf_textil' }],
          min: A.minSudadera, incluidos: ['material', 'dtf_textil', 'planchado', 'mano_obra'], detalle: `Estampado ${o.est}` }) },
    { id: 'gorra', nombre: '🧢 Gorra trucker', cat: 'Textiles', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: 'Gorra trucker', m: A.gorra, proc: 'material' },
            { c: 'DTF textil 10 × 10 cm', m: dtfTextil(A, 'Chico 10 × 10 cm'), proc: 'dtf_textil' }],
          min: A.minGorra, incluidos: ['material', 'dtf_textil', 'planchado', 'mano_obra'], detalle: 'Logo DTF 10 × 10 cm' }) },

    { id: 'taza', nombre: '☕ Taza 11 oz', cat: 'Vasos y tazas', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: 'Taza blanca 11 oz', m: A.taza, proc: 'material' },
            { c: 'Sublimación (papel y tinta)', m: A.tazaImpresion, proc: 'sublimacion' }],
          min: A.minTaza, incluidos: ['material', 'sublimacion', 'mano_obra'], detalle: 'Cerámica blanca, diseño a color' }) },
    { id: 'set_tazas', nombre: '🎁 Set de 2 tazas con caja', cat: 'Vasos y tazas', unidad: 'set', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: '2 tazas blancas', m: 2 * A.taza, proc: 'material' },
            { c: 'Sublimación de 2 tazas', m: 2 * A.tazaImpresion, proc: 'sublimacion' },
            { c: 'Caja y relleno', m: A.cajaSet, proc: 'empaque' }],
          min: A.minSetTazas, incluidos: ['material', 'sublimacion', 'empaque', 'mano_obra'], detalle: '2 tazas + caja de regalo' }) },
    { id: 'vaso_mini', nombre: '🥤 Vaso mini', cat: 'Vasos y tazas', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: 'Vaso mini 700 ml', m: A.vasoMini, proc: 'material' },
            { c: 'Etiqueta DTF UV 8 × 10 cm', m: costoEnRollo(8, 10, A.dtfUVMetro, A.dtfUVAncho, A.separacionRollo), proc: 'dtf_uv' }],
          min: A.minVaso, incluidos: ['material', 'dtf_uv', 'mano_obra'], detalle: '700 ml, etiqueta DTF UV 8 × 10 cm' }) },
    { id: 'vaso_chupon', nombre: '🍼 Vaso chupón', cat: 'Vasos y tazas', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: 'Vaso chupón', m: A.vasoChupon, proc: 'material' },
            { c: 'Etiqueta DTF UV 7 × 7 cm', m: costoEnRollo(7, 7, A.dtfUVMetro, A.dtfUVAncho, A.separacionRollo), proc: 'dtf_uv' }],
          min: A.minVaso, incluidos: ['material', 'dtf_uv', 'mano_obra'], detalle: 'Etiqueta DTF UV 7 × 7 cm' }) },

    { id: 'lonas', nombre: '🖼️ Lona', cat: 'Fiestas y eventos', opciones: [
        { id: 'medida', label: 'Medida', choices: ['1 × 1 m', '2 × 1 m', '0.60 × 3 m', 'Medida personalizada'] },
        { id: 'anchoM', label: 'Ancho (m)', tipo: 'numero', def: 1.5, si: o => o.medida === 'Medida personalizada' },
        { id: 'altoM', label: 'Alto (m)', tipo: 'numero', def: 1, si: o => o.medida === 'Medida personalizada' }],
      calc: (o, A) => {
          const m = { '1 × 1 m': [1, 1], '2 × 1 m': [2, 1], '0.60 × 3 m': [0.6, 3] }[o.medida] || [parseFloat(o.anchoM) || 0, parseFloat(o.altoM) || 0];
          const m2 = m[0] * m[1];
          return { modo: 'pieza', lineas: [{ c: `Lona impresa ${m2.toFixed(2)} m²`, m: m2 * A.lonaM2, proc: 'impresion' }],
              min: A.minLona, incluidos: ['material', 'impresion', 'mano_obra'], detalle: `${m[0]} × ${m[1]} m (${m2.toFixed(2)} m²)` };
      } },
    { id: 'coroplast', nombre: '🐘 Figura de coroplast', cat: 'Fiestas y eventos', opciones: [
        { id: 'tam', label: 'Tamaño', choices: Object.keys(CORO) }],
      calc: (o, A) => ({ modo: 'pieza', lineas: [{ c: `Coroplast impreso ${o.tam}`, m: A[CORO[o.tam]], proc: 'material' }],
          min: A.minCoroplast, incluidos: ['material', 'impresion', 'corte_manual', 'mano_obra'], detalle: o.tam }) },
    { id: 'cabezones', nombre: '🎓 Cabezón', cat: 'Fiestas y eventos', opciones: [
        { id: 'tam', label: 'Tamaño', choices: ['30 × 40 cm', '50 × 60 cm', '70 × 80 cm'] }],
      calc: (o, A) => ({ modo: 'pieza', lineas: [{ c: `Coroplast impreso ${o.tam}`, m: A[CORO[o.tam]], proc: 'material' }],
          min: A.minCoroplast, incluidos: ['material', 'impresion', 'corte_manual', 'mano_obra'], detalle: `Coroplast ${o.tam}` }) },
    { id: 'cake_toppers', nombre: '🎂 Cake toppers de caras', cat: 'Fiestas y eventos', unidad: 'paquete', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [{ c: 'Paquete de 30 toppers', m: A.cakeToppers, proc: 'material' }],
          min: A.minCakeToppers, incluidos: ['material', 'impresion', 'mano_obra'], detalle: 'Paquete de 30 piezas de 6 cm' }) },
    { id: 'gorros_fiesta', nombre: '🥳 Gorro de fiesta con cara', cat: 'Fiestas y eventos', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [{ c: 'Gorro de fiesta', m: A.gorroFiesta, proc: 'material' }],
          min: A.minGorroFiesta, incluidos: ['material', 'impresion', 'mano_obra'], detalle: 'Con foto del festejado' }) },

    { id: 'tatuajes', nombre: '🩹 Tatuajes', cat: 'Stickers y tatuajes', opciones: [
        { id: 'tam', label: 'Tamaño', choices: ['3 cm', '4 cm', '5 cm', '6 cm', '8 cm', '10 cm'], def: '5 cm' }],
      calc: (o, A) => ({ modo: 'planilla', w: cm(o.tam), h: cm(o.tam), plW: 20, plH: 28.5, uW: 20, uH: 28.5, sep: A.separacionPlanilla,
          lineasLote: [{ c: 'Planilla de tatuaje 20 × 28.5 cm', m: A.planillaTatuaje, proc: 'impresion' }], minLote: A.minPlanilla,
          soporte: 'Planilla de tatuaje 20 × 28.5 cm', detalle: `${cm(o.tam)} × ${cm(o.tam)} cm`, incluidos: ['material', 'impresion', 'mano_obra'] }) },
    { id: 'stickers', nombre: '⭐ Stickers circulares / silueta', cat: 'Stickers y tatuajes', opciones: [
        { id: 'forma', label: 'Forma', choices: ['Circular', 'Silueta'], sinPrecio: true },
        { id: 'tam', label: 'Tamaño', choices: TAM_STICKER, def: '5 cm' }],
      calc: (o, A) => planillaPapel(A, 'Papel adhesivo', cm(o.tam), cm(o.tam), `${o.forma} de ${o.tam}`) },
    { id: 'stickers_nombre', nombre: '✏️ Stickers con nombre', cat: 'Escolares', opciones: [],
      calc: (o, A) => planillaPapel(A, 'Papel adhesivo', 7, 5, 'Etiqueta 7 × 5 cm') },
    { id: 'etiquetas', nombre: '🏷️ Etiquetas escolares', cat: 'Escolares', opciones: [],
      calc: (o, A) => planillaPapel(A, 'Papel adhesivo', 12, 6, 'Etiqueta 12 × 6 cm') },
    { id: 'forrado', nombre: '📚 Forrado de cuadernos', cat: 'Escolares', unidad: 'cuaderno', libre: true, opciones: [
        { id: 'costoLibre', label: 'Tu costo por cuaderno ($)', tipo: 'numero', def: '' }],
      calc: (o, A) => ({ modo: 'pieza', lineas: [{ c: 'Material del forrado', m: parseFloat(o.costoLibre) || 0, proc: 'material' }],
          min: 0, incluidos: ['material', 'impresion', 'mano_obra'], detalle: 'Portada personalizada' }) },

    { id: 'carrito', nombre: '🚗 Carrito personalizado', cat: 'Regalos', opciones: [],
      calc: (o, A) => ({ modo: 'pieza', lineas: [
            { c: 'Carrito coleccionable', m: A.carrito, proc: 'material' },
            { c: 'Empaque blíster', m: A.empaqueCarrito, proc: 'empaque' }],
          min: A.minCarrito, incluidos: ['material', 'impresion', 'empaque', 'mano_obra'], detalle: 'Auto + empaque blíster con foto' }) },

    { id: 'medida', nombre: '📐 Otra medida (etiqueta, vinil, DTF)', cat: 'Medida personalizada', opciones: [
        { id: 'material', label: 'Material', choices: ['Papel adhesivo', 'Papel couché', 'Opalina', 'Vinil adhesivo', 'Vinil de corte', 'DTF textil', 'DTF UV'] },
        { id: 'ancho', label: 'Ancho (cm)', tipo: 'numero', def: 5 },
        { id: 'alto', label: 'Alto (cm)', tipo: 'numero', def: 5 }],
      calc: (o, A) => {
          const w = parseFloat(o.ancho) || 0, h = parseFloat(o.alto) || 0;
          if (PAPELES[o.material]) return planillaPapel(A, o.material, w, h, `${o.material}, ${w} × ${h} cm`);
          const r = ROLLOS[o.material];
          return { modo: 'rollo', w, h, precioMetro: A[r[0]], anchoRollo: A[r[1]], sep: A.separacionRollo, proc: r[2],
              soporte: o.material, detalle: `${o.material}, ${w} × ${h} cm`, incluidos: ['material', r[2]] };
      } },
];
const productoCot = id => PRODUCTOS_COT.find(p => p.id === id);

/* Procesos que se pueden AGREGAR a un producto. Si el producto ya lo
   incluye en su costo base (incluidos), no se ofrece: así no se cobra dos veces.
   costo() regresa { pieza:$, minPieza, lote:$, minLote, pedido:$, minPedido } */
const EXTRAS = [
    { id: 'dtf_adicional', proc: 'dtf_textil', nombre: 'Estampado DTF adicional (espalda o manga)',
      aplica: p => ['playera', 'sudadera'].includes(p.id), siempre: true,
      param: { tipo: 'select', choices: Object.keys(ESTAMPADOS), def: 'Grande 30 × 40 cm' },
      costo: (A, v) => ({ pieza: dtfTextil(A, v), minPieza: A.minPlanchado }), faltan: A => A.minPlanchado ? [] : ['Planchado extra (min)'] },
    { id: 'laminado', proc: 'laminado', nombre: 'Laminado', aplica: (p, c) => c.modo === 'planilla' && p.id !== 'tatuajes',
      param: { tipo: 'select', choices: ['Mate', 'Brillante', 'Holográfico'], def: 'Mate' },
      costo: (A, v) => ({ lote: A['laminado' + { Mate: 'Mate', Brillante: 'Brillante', 'Holográfico': 'Holografico' }[v]] }),
      faltan: (A, v) => A['laminado' + { Mate: 'Mate', Brillante: 'Brillante', 'Holográfico': 'Holografico' }[v]] ? [] : [`Laminado ${v.toLowerCase()}`] },
    { id: 'corte_manual', proc: 'corte_manual', nombre: 'Corte manual', aplica: () => true,
      costo: A => ({ minPieza: A.minCorteManual }), faltan: A => A.minCorteManual ? [] : ['Corte manual (min)'] },
    { id: 'depilado', proc: 'depilado', nombre: 'Depilado de vinil', aplica: (p, c) => c.modo === 'rollo' && /vinil/.test(c.proc || ''),
      costo: A => ({ minPieza: A.minDepilado }), faltan: A => A.minDepilado ? [] : ['Depilado (min)'] },
    { id: 'planchado', proc: 'planchado', nombre: 'Planchado (aplicar en prenda)', aplica: (p, c) => c.modo === 'rollo' && c.proc === 'dtf_textil',
      costo: A => ({ minPieza: A.minPlanchado }), faltan: A => A.minPlanchado ? [] : ['Planchado extra (min)'] },
    { id: 'empaque', proc: 'empaque', nombre: 'Empaque individual', aplica: () => true,
      costo: A => ({ pieza: A.empaquePieza }), faltan: A => A.empaquePieza ? [] : ['Empaque individual ($)'] },
    { id: 'material_extra', proc: 'extra', nombre: 'Material o gasto adicional por pieza ($)', aplica: () => true, siempre: true,
      param: { tipo: 'numero', def: 0 }, costo: (A, v) => ({ pieza: parseFloat(v) || 0 }) },
    { id: 'tiempo_extra', proc: 'mano_obra', nombre: 'Tiempo extra para este pedido (min)', aplica: () => true, siempre: true,
      param: { tipo: 'numero', def: 15 }, costo: (A, v) => ({ minPedido: parseFloat(v) || 0 }) },
];
function extrasDisponibles(prod, c) {
    return EXTRAS.filter(e => e.aplica(prod, c) && (e.siempre || !(c.incluidos || []).includes(e.proc)));
}

/* ---------- Cálculo de una partida ----------
   item = { tipo:'catalogo', productoId, opciones, cantidad, extras:{id:{on,valor}}, precioManual, personalizacion }
        o { tipo:'libre', nombre, detalle, unidad, cantidad, costoPieza, minPieza, costoPedido, minPedido, ... }
   ctx  = { gastosPedidoParte } (gastos fijos del pedido repartidos)                       */
function cotizarItem(item, A, ctx) {
    A = A || obtenerAjustes(); ctx = ctx || {};
    const t = A.horaTrabajo / 60;
    const q = Math.max(0, parseInt(item.cantidad) || 0);
    const qCalc = q > 0 ? q : 1;
    const merma = (A.mermaPct || 0) / 100, desgaste = (A.desgastePct || 0) / 100;
    const conInd = m => m * (1 + merma + desgaste);
    const desglose = [];      // líneas internas de costo (solo para ti)
    const avisos = [];
    let prod = null, c, nombre, detalle, unidad;

    if (item.tipo === 'libre') {
        nombre = item.nombre; detalle = item.detalle || ''; unidad = item.unidad || 'pieza';
        c = { modo: 'pieza', lineas: [{ c: item.conceptoCosto || 'Material y proceso', m: parseFloat(item.costoPieza) || 0, proc: 'material' }],
              min: parseFloat(item.minPieza) || 0, incluidos: [], pedido: parseFloat(item.costoPedido) || 0, minPedido: parseFloat(item.minPedido) || 0,
              sinIndirectos: !!item.sinIndirectos };
    } else {
        prod = productoCot(item.productoId);
        if (!prod) return { error: 'Producto no encontrado.' };
        c = prod.calc(item.opciones || {}, A);
        nombre = prod.nombre.replace(/^\S+\s/, ''); detalle = c.detalle; unidad = prod.unidad || 'pieza';
    }
    const ind = c.sinIndirectos ? (m => m) : conInd;

    // Cubetas de costo
    let matPieza = 0, minPieza = 0, matLote = 0, minLote = 0, matPedido = c.pedido || 0, minPedido = c.minPedido || 0;
    let info = null, rend = 1, lotes = 0, matRolloTotal = null;

    if (c.modo === 'pieza') {
        (c.lineas || []).forEach(l => { matPieza += l.m || 0; desglose.push({ c: l.c, unidad: 'pieza', m: (l.m || 0) * qCalc, proc: l.proc }); });
        minPieza += c.min || 0;
    } else if (c.modo === 'planilla') {
        if (!(c.w > 0 && c.h > 0)) return null;
        const ac = acomodar(c.w, c.h, c.uW, c.uH, c.sep || 0, item.orientacion || 'auto');
        if (ac.rend === 0) return { error: `${nombre}: la pieza no cabe en la planilla (${c.uW} × ${c.uH} cm útiles).` };
        rend = ac.rend; lotes = Math.ceil(qCalc / rend);
        (c.lineasLote || []).forEach(l => { matLote += l.m || 0; desglose.push({ c: `${l.c} × ${lotes}`, unidad: 'planilla', m: (l.m || 0) * lotes, proc: l.proc }); });
        minLote += c.minLote || 0;
        info = { ...c, ...ac, planillas: lotes };
    } else if (c.modo === 'rollo') {
        if (!(c.w > 0 && c.h > 0)) return null;
        const unit = costoEnRollo(c.w, c.h, c.precioMetro, c.anchoRollo, c.sep);
        if (unit === null) return { error: `${nombre}: la pieza es más ancha que el rollo (${c.anchoRollo} cm).` };
        const ar = acomodarRollo(c.w, c.h, c.anchoRollo, c.sep || 0, qCalc, true);
        matPieza += unit;
        matRolloTotal = ar.largo / 100 * c.precioMetro;
        desglose.push({ c: `${c.soporte}: ${(ar.largo / 100).toFixed(2)} m`, unidad: 'rollo', m: matRolloTotal, proc: c.proc });
        info = { ...c, ...ar };
    }

    // Procesos extra
    const extrasAplicados = [];
    const disponibles = prod ? extrasDisponibles(prod, c) : [];
    Object.entries(item.extras || {}).forEach(([id, st]) => {
        if (!st || !st.on) return;
        const ex = disponibles.find(e => e.id === id);
        if (!ex) return; // ya incluido o no aplica: no se cobra dos veces
        const val = st.valor !== undefined ? st.valor : (ex.param ? ex.param.def : undefined);
        const k = ex.costo(A, val);
        matPieza += k.pieza || 0; minPieza += k.minPieza || 0;
        matLote += k.lote || 0; minLote += k.minLote || 0;
        matPedido += k.pedido || 0; minPedido += k.minPedido || 0;
        const falt = ex.faltan ? ex.faltan(A, val) : [];
        falt.forEach(f => avisos.push({ tipo: 'falta', msg: `Falta capturar el costo de "${f}" en Mis costos.` }));
        extrasAplicados.push({ id, nombre: ex.nombre + (ex.param && ex.param.tipo === 'select' ? `: ${val}` : ''), valor: val });
        if (k.pieza) desglose.push({ c: ex.nombre, unidad: 'pieza', m: k.pieza * qCalc, proc: ex.proc });
        if (k.lote) desglose.push({ c: `${ex.nombre} × ${lotes || 1}`, unidad: 'planilla', m: k.lote * (lotes || 1), proc: ex.proc });
    });

    // Gastos fijos del pedido repartidos
    if (ctx.gastosPedidoParte) { matPedido += ctx.gastosPedidoParte; desglose.push({ c: 'Gastos fijos del pedido (parte)', unidad: 'pedido', m: ctx.gastosPedidoParte, proc: 'extra' }); }

    // Merma y desgaste
    const matBaseTotal = (matRolloTotal !== null ? matRolloTotal + (matPieza - (info ? costoEnRollo(c.w, c.h, c.precioMetro, c.anchoRollo, c.sep) : 0)) * qCalc : matPieza * qCalc) + matLote * lotes;
    if (!c.sinIndirectos && merma > 0) desglose.push({ c: `Merma ${A.mermaPct}%`, unidad: 'pedido', m: matBaseTotal * merma, proc: 'merma' });
    if (!c.sinIndirectos && desgaste > 0) desglose.push({ c: `Luz y desgaste ${A.desgastePct}%`, unidad: 'pedido', m: matBaseTotal * desgaste, proc: 'desgaste' });

    // Costo unitario para precios por escala
    const costoPiezaUnit = ind(matPieza) + minPieza * t;
    const costoLoteUnit = ind(matLote) + minLote * t;
    const costoUnit = costoPiezaUnit + (c.modo === 'planilla' ? costoLoteUnit / rend : 0);
    if (!(costoUnit > 0)) {
        if (prod && prod.libre) return { sinCosto: true, nombre, detalle, unidad };
        if (item.tipo === 'libre' && !(c.pedido > 0)) return { sinCosto: true, nombre, detalle, unidad };
    }

    // Costo real del pedido
    const minutos = minPieza * qCalc + minLote * lotes + minPedido;
    const material = (matRolloTotal !== null ? ind(matRolloTotal) + ind(matPieza - costoEnRollo(c.w, c.h, c.precioMetro, c.anchoRollo, c.sep)) * qCalc : ind(matPieza) * qCalc)
        + ind(matLote) * lotes + ind(matPedido);
    const mo = minutos * t;
    const costoPedido = ind(matPedido) + minPedido * t;
    const costoTotal = material + mo;
    desglose.push({ c: `Mano de obra (${formatoMinutos(minutos)})`, unidad: 'tiempo', m: mo, proc: 'mano_obra' });

    // Escalas de precio
    const modo = A.modoGanancia || 'recargo';
    const porLote = c.modo === 'planilla' ? rend : 1;
    const base = costoUnit * porLote;
    const menudeo = redondearPrecio(precioConGanancia(base, A.ganancia, modo), A.redondeo);
    const piso = precioConGanancia(base, A.margenMinimo, modo);
    const e1 = redondearPrecio(Math.max(menudeo * (1 - A.desc30 / 100), piso), A.redondeo);
    const e2 = redondearPrecio(Math.max(menudeo * (1 - A.desc100 / 100), piso), A.redondeo);
    const escalas = [[`1 a ${A.esc1Desde - 1}`, menudeo], [`${A.esc1Desde} a ${A.esc2Desde - 1}`, e1], [`${A.esc2Desde} o más`, e2]]
        .map(([label, pb]) => ({ label, precio: Math.round(pb / porLote * 100) / 100, precioLote: porLote > 1 ? pb : null }));
    const idx = q >= A.esc2Desde ? 2 : q >= A.esc1Desde ? 1 : 0;

    // Precio del pedido
    const precioExtraPedido = costoPedido > 0 ? redondearPrecio(precioConGanancia(costoPedido, A.ganancia, modo), A.redondeo) : 0;
    let total, nota = '', manual = false;
    const precioManual = parseFloat(item.precioManual);
    if (precioManual > 0) {
        manual = true;
        total = precioManual * q;
    } else {
        total = escalas[idx].precio * q + precioExtraPedido;
        const minimo = redondearPrecio(precioConGanancia(costoTotal, A.margenMinimo, modo), A.redondeo);
        if (q > 0 && total < minimo) {
            total = minimo;
            nota = info && info.planillas ? `Se cobra el mínimo para cubrir ${info.planillas} planilla(s). Caben ${info.planillas * info.rend} piezas por el mismo costo.`
                : 'Se ajustó al precio mínimo para no perder.';
        }
    }
    total = Math.round(total * 100) / 100;
    const med = medirGanancia(total, costoTotal);
    if (q > 0) {
        if (total < costoTotal - 0.005) avisos.push({ tipo: 'perdida', msg: `${nombre}: el precio (${fmt(total)}) no cubre el costo (${fmt(costoTotal)}).` });
        else if (gananciaEnModo(total, costoTotal, modo) < A.margenMinimo - 0.05) avisos.push({ tipo: 'bajo', msg: `${nombre}: ganancia de ${Math.round(gananciaEnModo(total, costoTotal, modo))}% ${modo === 'margen' ? 'del precio' : 'sobre el costo'}, debajo de tu mínimo (${A.margenMinimo}%).` });
    }

    return {
        nombre, detalle, unidad, cantidad: q, c, info, prod,
        costoUnit, material, mo, minutos, costoTotal, escalas, idx, total, nota, manual,
        precioUnit: q > 0 ? total / q : escalas[idx].precio,
        ganancia: med.ganancia, margen: med.margen, recargo: med.recargo,
        desglose, avisos, extrasAplicados, incluidos: (c.incluidos || []).map(p => PROCESOS[p] || p), extrasDisponibles: disponibles
    };
}

/* ---------- Cálculo de la cotización completa ----------
   cot = { items:[], diseno:{on,min}, cargo:{concepto,monto}, descuento:{tipo:'%'|'$',valor}, anticipoPct } */
function cotizarCotizacion(cot, A) {
    A = A || obtenerAjustes();
    const modo = A.modoGanancia || 'recargo';
    const items = cot.items || [];
    const parte = items.length ? (A.gastosPedido || 0) / items.length : 0;
    const res = items.map(it => cotizarItem(it, A, { gastosPedidoParte: parte }));
    const validos = res.filter(r => r && !r.error && !r.sinCosto);
    const avisos = [];
    res.forEach((r, i) => {
        if (!r) avisos.push({ tipo: 'falta', msg: `Partida ${i + 1}: faltan datos.` });
        else if (r.error) avisos.push({ tipo: 'perdida', msg: r.error });
        else if (r.sinCosto) avisos.push({ tipo: 'falta', msg: `${r.nombre}: escribe tu costo para poder calcular el precio.` });
        else avisos.push(...r.avisos);
    });

    let disenoCosto = 0, disenoPrecio = 0;
    if (cot.diseno && cot.diseno.on) {
        const min = parseFloat(cot.diseno.min);
        disenoCosto = (isNaN(min) ? A.minDiseno : min) * A.horaTrabajo / 60;
        disenoPrecio = redondearPrecio(precioConGanancia(disenoCosto, A.ganancia, modo), A.redondeo);
    }
    const cargo = Math.max(0, parseFloat(cot.cargo && cot.cargo.monto) || 0);
    const sumaPartidas = validos.reduce((s, r) => s + r.total, 0);
    const subtotal = sumaPartidas + disenoPrecio;
    const d = cot.descuento || {};
    let descuento = d.tipo === '$' ? (parseFloat(d.valor) || 0) : subtotal * (parseFloat(d.valor) || 0) / 100;
    descuento = Math.min(Math.max(0, Math.round(descuento * 100) / 100), subtotal);
    const total = Math.round((subtotal - descuento + cargo) * 100) / 100;
    const anticipoPct = Math.min(100, Math.max(0, parseFloat(cot.anticipoPct) || 0));
    const anticipo = Math.round(total * anticipoPct) / 100;
    const saldo = Math.round((total - anticipo) * 100) / 100;
    const costoTotal = validos.reduce((s, r) => s + r.costoTotal, 0) + disenoCosto + cargo;
    const med = medirGanancia(total, costoTotal);
    if (validos.length && descuento > 0) {
        if (total < costoTotal - 0.005) avisos.push({ tipo: 'perdida', msg: `Con el descuento, el total (${fmt(total)}) no cubre tus costos (${fmt(costoTotal)}).` });
        else if (gananciaEnModo(total, costoTotal, modo) < A.margenMinimo - 0.05) avisos.push({ tipo: 'bajo', msg: `Con el descuento, la ganancia queda en ${Math.round(gananciaEnModo(total, costoTotal, modo))}%, debajo de tu mínimo (${A.margenMinimo}%).` });
    }
    return {
        partidas: res, sumaPartidas, disenoCosto, disenoPrecio, cargo, subtotal, descuento, total, anticipoPct, anticipo, saldo,
        costoTotal, ganancia: med.ganancia, margen: med.margen, recargo: med.recargo, avisos, modo,
        piezas: validos.reduce((s, r) => s + r.cantidad, 0)
    };
}

/* ---------- Calculadora láser / CNC ---------- */
function calcularCorteMaquina(p, A) {
    A = A || obtenerAjustes();
    const q = Math.max(1, parseInt(p.cantidad) || 1);
    const t = A.horaTrabajo / 60;
    const maqMin = parseFloat(p.costoMaquinaMin) || 0;
    const corte = (parseFloat(p.minCorte) || 0) * q;
    const prep = parseFloat(p.minPreparacion) || 0, dis = parseFloat(p.minDiseno) || 0;
    const mat = (parseFloat(p.costoMaterial) || 0) * q;
    const maquina = corte * maqMin;
    const minutosTrabajo = prep + dis + (p.atiendeCorte ? corte : 0);
    const mo = minutosTrabajo * t;
    const costoTotal = mat * (1 + (A.mermaPct || 0) / 100) + maquina + mo;
    const pct = p.ganancia !== undefined && p.ganancia !== '' ? parseFloat(p.ganancia) : A.ganancia;
    const modo = A.modoGanancia || 'recargo';
    const precioPieza = redondearPrecio(precioConGanancia(costoTotal / q, pct, modo), A.redondeo);
    const total = precioPieza * q;
    return { q, mat, maquina, mo, minutosTrabajo, costoTotal, costoPieza: costoTotal / q, precioPieza, total, ...medirGanancia(total, costoTotal) };
}

/* ---------- Utilidades ---------- */
function fmt(v) { return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(v || 0); }
function formatoMinutos(m) { return m >= 60 ? `${(m / 60).toFixed(1)} h` : `${Math.round(m)} min`; }

function combinaciones(prod) {
    let combos = [{}];
    prod.opciones.forEach(op => {
        if (op.tipo === 'numero') { combos.forEach(c => c[op.id] = op.def); return; }
        const ch = op.sinPrecio ? [op.choices[0]] : op.choices.filter(x => x !== 'Medida personalizada');
        combos = combos.flatMap(c => ch.map(x => ({ ...c, [op.id]: x })));
    });
    return combos;
}
function precioDesdeProducto(id, preset, A) {
    const prod = productoCot(id);
    if (!prod || prod.libre) return null;
    A = A || obtenerAjustes();
    let min = null;
    combinaciones(prod).forEach(o => {
        const r = cotizarItem({ tipo: 'catalogo', productoId: id, opciones: { ...o, ...(preset || {}) }, cantidad: 1 }, A);
        if (r && !r.error && !r.sinCosto) min = min === null ? r.escalas[0].precio : Math.min(min, r.escalas[0].precio);
    });
    return min;
}

if (typeof module !== 'undefined') {
    module.exports = { AJUSTES_BASE, AJUSTES_DEF, PRODUCTOS_COT, EXTRAS, cotizarItem, cotizarCotizacion, calcularCorteMaquina,
        acomodar, acomodarRollo, costoEnRollo, redondearPrecio, precioConGanancia, medirGanancia, precioDesdeProducto, combinaciones };
}
