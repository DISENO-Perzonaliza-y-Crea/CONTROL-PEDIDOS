/* =====================================================================
   Personaliza Studio — Cotización en PDF (jsPDF + AutoTable)
   El PDF NUNCA incluye costos, proveedores, margen ni utilidad.
   ===================================================================== */

// Colores de marca: morado = rosa intenso, lila = durazno, cian = verde agua
const MARCA = { rosa: [247, 175, 203], lila: [248, 184, 74], morado: [201, 69, 127], azul: [140, 203, 203], cian: [140, 203, 203], texto: [61, 44, 55], gris: [122, 104, 114], rosaClaro: [255, 240, 245], lilaClaro: [255, 248, 243] };

// Las fuentes estándar de PDF solo traen caracteres latinos básicos
function textoPDF(s) {
    return String(s === undefined || s === null ? '' : s)
        .replace(/[\u2212\u2013\u2014]/g, '-').replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/\u2026/g, '...').replace(/\u00B2/g, '2').replace(/\u00B3/g, '3')
        .replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, '').replace(/\s{2,}/g, ' ').trim();
}
function sumarDias(iso, dias) {
    const [y, m, d] = iso.split('-').map(Number);
    const f = new Date(y, m - 1, d); f.setDate(f.getDate() + (parseInt(dias) || 15));
    return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, '0')}-${String(f.getDate()).padStart(2, '0')}`;
}

function crearPDFCotizacion(cot, R, neg) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'letter' });
    const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), M = 16;
    const color = (c, tipo) => tipo === 'fill' ? doc.setFillColor(...c) : tipo === 'draw' ? doc.setDrawColor(...c) : doc.setTextColor(...c);

    // Franja superior
    color(MARCA.rosa, 'fill'); doc.rect(0, 0, W * 0.5, 3, 'F');
    color(MARCA.lila, 'fill'); doc.rect(W * 0.5, 0, W * 0.3, 3, 'F');
    color(MARCA.cian, 'fill'); doc.rect(W * 0.8, 0, W * 0.2, 3, 'F');

    // Logotipo o monograma
    let xNombre = M;
    if (neg.logo) {
        try {
            const p = doc.getImageProperties(neg.logo);
            const maxW = 34, maxH = 24, k = Math.min(maxW / p.width, maxH / p.height);
            doc.addImage(neg.logo, 'PNG', M, 10, p.width * k, p.height * k);
            xNombre = M + p.width * k + 5;
        } catch (e) { neg = { ...neg, logo: null }; }
    }
    if (!neg.logo) {
        color(MARCA.morado, 'fill'); doc.circle(M + 10, 21, 10, 'F');
        color(MARCA.rosa, 'fill'); doc.circle(M + 17, 13.5, 2.2, 'F');
        doc.setFont('times', 'bolditalic'); doc.setFontSize(20); color([255, 255, 255]);
        doc.text(textoPDF((neg.nombre || 'J').charAt(0)), M + 10, 24.5, { align: 'center' });
        xNombre = M + 25;
    }
    const partesNombre = textoPDF(neg.nombre).split('|').map(s => s.trim());
    doc.setFont('helvetica', 'bold'); doc.setFontSize(16); color(MARCA.morado);
    doc.text(partesNombre[0] || '', xNombre, 19);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5); color(MARCA.gris);
    if (partesNombre[1]) doc.text(partesNombre[1], xNombre, 24.5);
    if (neg.whatsapp) doc.text(textoPDF(`WhatsApp ${neg.whatsapp}`), xNombre, partesNombre[1] ? 29.5 : 24.5);

    // Datos de la cotización
    doc.setFont('helvetica', 'bold'); doc.setFontSize(20); color(MARCA.texto);
    doc.text('COTIZACIÓN', W - M, 18, { align: 'right' });
    doc.setFontSize(10); color(MARCA.morado);
    doc.text(textoPDF(cot.folio || ''), W - M, 24, { align: 'right' });
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); color(MARCA.gris);
    doc.text(textoPDF(`Fecha: ${fechaLarga(cot.fecha)}`), W - M, 29, { align: 'right' });
    doc.text(textoPDF(`Válida hasta: ${fechaLarga(sumarDias(cot.fecha, cot.vigenciaDias))}`), W - M, 33.5, { align: 'right' });

    // Cliente
    let y = 41;
    color(MARCA.rosaClaro, 'fill'); doc.roundedRect(M, y, W - 2 * M, 18, 3, 3, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(7.5); color(MARCA.morado);
    doc.text('CLIENTE', M + 5, y + 6);
    doc.text('ENTREGA ESTIMADA', W / 2 + 5, y + 6);
    doc.setFontSize(10.5); color(MARCA.texto);
    doc.text(textoPDF(cot.cliente.nombre || 'Cliente'), M + 5, y + 11.5);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); color(MARCA.gris);
    if (cot.cliente.telefono) doc.text(textoPDF(`Tel. ${cot.cliente.telefono}`), M + 5, y + 15.5);
    const entrega = doc.splitTextToSize(textoPDF(cot.entrega || 'Por confirmar'), W / 2 - M - 8);
    color(MARCA.texto); doc.text(entrega.slice(0, 2), W / 2 + 5, y + 11.5);
    y += 24;

    // Partidas
    const filas = [];
    R.partidas.forEach((r, i) => {
        if (!r || r.error || r.sinCosto) return;
        const it = cot.items[i];
        const extras = (r.extrasAplicados || []).filter(e => !/gasto adicional|Tiempo extra/i.test(e.nombre)).map(e => e.nombre);
        let desc = textoPDF(r.nombre);
        const sub = [r.detalle, ...extras].filter(Boolean).map(textoPDF).join(' · ');
        filas.push([filas.length + 1, { content: desc + (sub ? '\n' + sub : '') + (it.personalizacion ? '\nPersonalización: ' + textoPDF(it.personalizacion) : '') },
            textoPDF(`${r.cantidad} ${r.cantidad === 1 ? r.unidad : (r.unidad === 'pieza' ? 'pzs' : r.unidad + 's')}`), fmt(r.precioUnit), fmt(r.total)]);
    });
    if (R.disenoPrecio) filas.push([filas.length + 1, { content: 'Diseño y preparación\nElaboración y ajustes del diseño para producción' }, '1', fmt(R.disenoPrecio), fmt(R.disenoPrecio)]);

    doc.autoTable({
        startY: y, margin: { left: M, right: M, bottom: 22 },
        head: [['#', 'Descripción', 'Cantidad', 'P. unitario', 'Importe']],
        body: filas,
        theme: 'plain',
        styles: { font: 'helvetica', fontSize: 9, cellPadding: { top: 3, bottom: 3, left: 2.5, right: 2.5 }, textColor: MARCA.texto, valign: 'top', lineColor: [242, 227, 232], lineWidth: { bottom: 0.2 } },
        headStyles: { fillColor: MARCA.morado, textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 8.5 },
        alternateRowStyles: { fillColor: MARCA.lilaClaro },
        columnStyles: { 0: { cellWidth: 8, halign: 'center', textColor: MARCA.morado, fontStyle: 'bold' }, 1: { cellWidth: 'auto' }, 2: { cellWidth: 22, halign: 'center' }, 3: { cellWidth: 27, halign: 'right' }, 4: { cellWidth: 29, halign: 'right', fontStyle: 'bold' } },
        didParseCell: d => { if (d.section === 'head' && d.column.index >= 2) d.cell.styles.halign = d.column.index === 2 ? 'center' : 'right'; },
        willDrawCell: d => {
            // Primera línea de la descripción en negritas: se dibuja aparte
            if (d.section === 'body' && d.column.index === 1) { d.cell._lineas = d.cell.text; d.cell.text = []; }
        },
        didDrawCell: d => {
            if (d.section === 'body' && d.column.index === 1 && d.cell._lineas) {
                const x = d.cell.x + 2.5; let yy = d.cell.y + 3 + 3.2;
                d.cell._lineas.forEach((ln, k) => {
                    const esPers = /^Personalización:/.test(ln);
                    doc.setFont('helvetica', k === 0 ? 'bold' : (esPers ? 'italic' : 'normal'));
                    doc.setFontSize(k === 0 ? 9.5 : 8.3);
                    doc.setTextColor(...(k === 0 ? MARCA.texto : esPers ? MARCA.morado : MARCA.gris));
                    doc.text(ln, x, yy); yy += k === 0 ? 4.2 : 3.6;
                });
            }
        }
    });
    y = doc.lastAutoTable.finalY + 6;

    // Totales y condiciones
    const filasTot = [['Subtotal', fmt(R.sumaPartidas + R.disenoPrecio)]];
    if (R.descuento) filasTot.push(['Descuento', '-' + fmt(R.descuento)]);
    if (R.cargo) filasTot.push([textoPDF(cot.cargo.concepto || 'Cargo extra'), fmt(R.cargo)]);
    const altoTot = filasTot.length * 6 + 12 + 14;
    const condiciones = [
        `Anticipo de ${R.anticipoPct}% para iniciar el pedido.`,
        cot.entrega ? `Tiempo de entrega: ${cot.entrega}.` : null,
        `Cotización válida por ${cot.vigenciaDias || 15} días.`,
        cot.observaciones || null
    ].filter(Boolean).map(textoPDF);
    const anchoCond = W - 2 * M - 80;
    const lineasCond = condiciones.flatMap(c => doc.splitTextToSize('•  ' + c, anchoCond));
    const altoBloque = Math.max(altoTot, lineasCond.length * 4.2 + 12);
    if (y + altoBloque > H - 24) { doc.addPage(); y = 20; }

    const xT = W - M - 74;
    doc.setFontSize(9.5);
    let yt = y + 4;
    filasTot.forEach(([k, v]) => {
        doc.setFont('helvetica', 'normal'); color(MARCA.gris); doc.text(k, xT, yt);
        color(MARCA.texto); doc.text(v, W - M, yt, { align: 'right' }); yt += 6;
    });
    color(MARCA.morado, 'fill'); doc.roundedRect(xT - 4, yt - 3, 78, 11, 2, 2, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); color([255, 255, 255]); doc.text('TOTAL', xT, yt + 4.2);
    doc.setFontSize(13); color([255, 230, 168]); doc.text(fmt(R.total), W - M - 2, yt + 4.5, { align: 'right' });
    yt += 15;
    doc.setFontSize(9.5); doc.setFont('helvetica', 'normal'); color(MARCA.gris);
    doc.text(`Anticipo (${R.anticipoPct}%)`, xT, yt); doc.setFont('helvetica', 'bold'); color(MARCA.morado); doc.text(fmt(R.anticipo), W - M, yt, { align: 'right' });
    yt += 6;
    doc.setFont('helvetica', 'normal'); color(MARCA.gris); doc.text('Saldo a la entrega', xT, yt); doc.setFont('helvetica', 'bold'); color(MARCA.texto); doc.text(fmt(R.saldo), W - M, yt, { align: 'right' });

    doc.setFont('helvetica', 'bold'); doc.setFontSize(8); color(MARCA.morado); doc.text('CONDICIONES', M, y + 4);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); color(MARCA.texto);
    doc.text(lineasCond, M, y + 9.5, { lineHeightFactor: 1.4 });

    // Pie de página
    const paginas = doc.getNumberOfPages();
    for (let p = 1; p <= paginas; p++) {
        doc.setPage(p);
        color(MARCA.lila, 'draw'); doc.setLineWidth(0.3); doc.line(M, H - 16, W - M, H - 16);
        doc.setFont('helvetica', 'normal'); doc.setFontSize(8); color(MARCA.gris);
        doc.text(textoPDF(`Gracias por tu preferencia · ${neg.nombre}${neg.whatsapp ? ' · WhatsApp ' + neg.whatsapp : ''}`), M, H - 10.5);
        doc.text(`${textoPDF(cot.folio || '')} · Página ${p} de ${paginas}`, W - M, H - 10.5, { align: 'right' });
    }
    return doc;
}

function prepararPDF() {
    if (!window.jspdf || !window.jspdf.jsPDF || !window.jspdf.jsPDF.API.autoTable) {
        mostrarError('No se pudo cargar el generador de PDF. Revisa tu conexión a internet y recarga la página.');
        return null;
    }
    if (!COT.items.length) { mostrarError('Agrega productos a la cotización antes de generar el PDF.'); return null; }
    if (!guardarCotizacion(false)) return null;
    if (!RES.partidas.some(r => r && !r.error && !r.sinCosto)) { mostrarError('Ningún producto tiene precio calculado.'); return null; }
    try {
        const doc = crearPDFCotizacion(COT, RES, obtenerNegocio());
        const cliente = (COT.cliente.nombre || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '').slice(0, 30);
        return { doc, nombre: `${COT.folio}${cliente ? '-' + cliente : ''}.pdf` };
    } catch (e) {
        console.error(e);
        mostrarError('Hubo un problema al crear el PDF. Intenta de nuevo.');
        return null;
    }
}
function descargarPDF() {
    const p = prepararPDF(); if (!p) return;
    p.doc.save(p.nombre);
    toast(`PDF ${p.nombre} descargado`);
}
function imprimirPDF() {
    const p = prepararPDF(); if (!p) return;
    p.doc.autoPrint();
    const url = p.doc.output('bloburl');
    const w = window.open(url, '_blank');
    if (!w) { p.doc.save(p.nombre); toast('Se descargó el PDF: ábrelo para imprimir'); }
}
function telefonoWhatsApp(t) {
    const d = String(t || '').replace(/\D/g, '');
    if (d.length === 10) return '52' + d;
    if (d.length === 12 && d.startsWith('52')) return d;
    if (d.length === 13 && d.startsWith('521')) return '52' + d.slice(3);
    return '';
}
async function compartirWhatsApp() {
    const p = prepararPDF(); if (!p) return;
    const blob = p.doc.output('blob');
    const archivo = new File([blob], p.nombre, { type: 'application/pdf' });
    const neg = obtenerNegocio();
    const mensaje = `Hola${COT.cliente.nombre ? ' ' + COT.cliente.nombre.split(' ')[0] : ''}, te comparto tu cotización ${COT.folio} de ${neg.nombre}. Total: ${fmt(RES.total)}.`;
    try {
        if (navigator.canShare && navigator.canShare({ files: [archivo] })) {
            await navigator.share({ files: [archivo], title: `Cotización ${COT.folio}`, text: mensaje });
            return;
        }
    } catch (e) { if (e && e.name === 'AbortError') return; }
    // En computadora: se descarga el PDF y se abre WhatsApp con el resumen para adjuntarlo
    p.doc.save(p.nombre);
    const tel = telefonoWhatsApp(COT.cliente.telefono);
    const a = document.createElement('a');
    a.href = `https://wa.me/${tel}?text=${encodeURIComponent(textoCotizacion())}`;
    a.target = '_blank'; a.rel = 'noopener';
    document.body.appendChild(a); a.click(); a.remove();
    toast('PDF descargado. Adjúntalo en el chat de WhatsApp.');
}
