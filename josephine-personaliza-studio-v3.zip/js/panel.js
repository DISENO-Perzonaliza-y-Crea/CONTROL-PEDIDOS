/* =====================================================================
   Personaliza Studio — Panel de control (inicio) y gráficas
   ===================================================================== */

const COLOR_VENTAS = '#00A0A8', COLOR_GASTOS = '#E8603C', COLOR_BARRA = '#D4528A';

function renderizarPanel() {
    const r = rangoDe('panel');
    const pedidos = obtenerPedidos(), ventas = obtenerVentas(), gastos = obtenerGastos();
    const hoy = hoyISO();
    const res = resumenFinanciero(r, pedidos, ventas, gastos);
    const activos = pedidos.filter(p => ESTADOS_ACTIVOS.includes(p.estado));
    const pendientes = pedidos.filter(p => ['pendiente', 'diseno', 'aprobacion'].includes(p.estado));
    const hoyEntregas = activos.filter(p => p.entrega === hoy);
    const atrasados = activos.filter(p => p.entrega && p.entrega < hoy);
    const bajos = materialesBajos();

    document.getElementById('panel-kpis').innerHTML =
        tarjetaKPI('Pedidos activos', activos.length, `${pendientes.length} por arrancar (pendiente, diseño o aprobación)`, 'fa-clipboard-list', 'rosa', "filtroEstadoPedidos='activos'; navegarA('pedidos')") +
        tarjetaKPI('Entregas de hoy', hoyEntregas.length, hoyEntregas.length ? hoyEntregas.map(p => p.folio).slice(0, 3).join(', ') : 'Ninguna para hoy', 'fa-truck-fast', 'amarillo', "filtroEstadoPedidos='activos'; navegarA('pedidos')") +
        tarjetaKPI('Atrasados', atrasados.length, atrasados.length ? 'Revisa su fecha de entrega' : 'Todo a tiempo', 'fa-clock', atrasados.length ? 'rojo' : 'verde', "filtroEstadoPedidos='atrasados'; navegarA('pedidos')") +
        tarjetaKPI('Por cobrar', formatoMoneda(res.porCobrar), 'Saldos de pedidos', 'fa-hand-holding-dollar', 'coral', "navegarA('ventas')") +
        tarjetaKPI(`Ventas · ${r.etiqueta.toLowerCase()}`, formatoMoneda(res.ventas), `Cobrado ${formatoMoneda(res.cobrado)}`, 'fa-bag-shopping', 'azul', "navegarA('ventas')") +
        tarjetaKPI(`Gastos · ${r.etiqueta.toLowerCase()}`, formatoMoneda(res.gastos), '', 'fa-wallet', 'rosa', "navegarA('gastos')") +
        tarjetaKPI('Utilidad estimada', formatoMoneda(res.utilidad), 'Ventas − gastos del periodo', 'fa-chart-line', res.utilidad < 0 ? 'rojo' : 'cian') +
        tarjetaKPI('Por agotarse', bajos.length, bajos.length ? bajos.map(m => m.nombre).slice(0, 2).join(', ') : 'Inventario en orden', 'fa-boxes-stacked', bajos.length ? 'rojo' : 'gris', "navegarA('inventario')");

    const alertas = [];
    if (atrasados.length) alertas.push(['rojo', 'fa-clock', `${atrasados.length} pedido(s) atrasado(s): ${atrasados.map(p => `${p.folio} (${p.cliente})`).slice(0, 4).join(', ')}`, "filtroEstadoPedidos='atrasados'; navegarA('pedidos')", 'Ver']);
    if (bajos.length) alertas.push(['amarillo', 'fa-boxes-stacked', `Resurtir: ${bajos.map(m => `${m.nombre} (${num2(m.existencia)} ${m.unidad})`).slice(0, 4).join(', ')}`, "navegarA('inventario')", 'Inventario']);
    const clases = { rojo: 'bg-red-50 border-red-200 text-red-700', amarillo: 'bg-yellow-50 border-yellow-200 text-yellow-800' };
    document.getElementById('panel-alertas').innerHTML = alertas.map(([t, i, m, a, b]) =>
        `<div class="flex flex-wrap items-center gap-3 border rounded-2xl px-4 py-3 text-sm ${clases[t]}"><i class="fa-solid ${i}"></i><span class="flex-1 min-w-[200px]">${esc(m)}</span><button onclick="${a}" class="btn-mini bg-white/80">${b}</button></div>`).join('');

    // Próximas entregas
    const proximas = activos.slice().sort((a, b) => String(a.entrega).localeCompare(String(b.entrega))).slice(0, 6);
    document.getElementById('panel-entregas').innerHTML = proximas.length ? proximas.map(p => {
        const ei = entregaInfo(p, hoy), est = estadoInfo(p.estado);
        return `<button onclick="navegarA('pedidos'); abrirDetallePedido(${p.id})" class="w-full text-left flex items-center gap-3 rounded-xl border border-gray-100 hover:border-brand-pink hover:bg-brand-bg px-3 py-2 transition">
            <div class="w-12 text-center shrink-0"><p class="text-lg font-bold text-brand-purple leading-none font-display">${p.entrega ? parseISO(p.entrega).getDate() : '–'}</p><p class="text-[10px] uppercase text-gray-400">${p.entrega ? parseISO(p.entrega).toLocaleDateString('es-MX', { month: 'short' }).replace('.', '') : ''}</p></div>
            <div class="flex-1 min-w-0"><p class="font-semibold text-sm truncate">${esc(p.folio)} · ${esc(p.cliente)}</p><p class="text-xs text-gray-500 truncate">${esc(p.producto)}</p></div>
            <div class="flex flex-col items-end gap-1"><span class="pill ${est.clase}">${est.nombre}</span>${ei && ei.tipo !== 'futuro' ? `<span class="pill ${ei.clase}">${ei.texto}</span>` : ''}</div>
        </button>`;
    }).join('') : '<p class="text-sm text-gray-500 text-center py-8"><i class="fa-regular fa-face-smile text-[#F28DB4] mr-1"></i>No hay pedidos activos.</p>';

    // Gráficas
    graficaMensual(document.getElementById('graf-mensual'), serieMensual(6, ventas, gastos, hoy));
    const top = productosMasVendidos(r, pedidos, ventas).slice(0, 6);
    document.getElementById('panel-top-sub').textContent = `Piezas en pedidos y ventas · ${r.etiqueta.toLowerCase()}`;
    graficaBarrasH(document.getElementById('graf-productos'), top.map(t => ({ etiqueta: t.nombre, valor: t.cantidad, detalle: `${t.cantidad} piezas · ${formatoMoneda(t.total)}` })), 'Aún no hay ventas en este periodo.');
    graficaBarrasH(document.getElementById('graf-estados'), ESTADOS.map(e => {
        const n = pedidos.filter(p => p.estado === e.id).length;
        return { etiqueta: e.nombre, valor: n, detalle: `${n} pedido(s)` };
    }).filter(x => x.valor > 0), 'Aún no hay pedidos.');

    renderizarDestacados();
}

/* ---------- Tooltip compartido ---------- */
function mostrarTooltip(ev, html) {
    const t = document.getElementById('grafica-tooltip');
    t.innerHTML = html; t.classList.remove('hidden');
    const x = Math.min(ev.clientX + 14, window.innerWidth - t.offsetWidth - 8), y = Math.max(8, ev.clientY - t.offsetHeight - 12);
    t.style.left = x + 'px'; t.style.top = y + 'px';
}
function ocultarTooltip() { document.getElementById('grafica-tooltip').classList.add('hidden'); }
function escalaBonita(max) {
    if (max <= 0) return { tope: 1, pasos: [0, 1] };
    const p = Math.pow(10, Math.floor(Math.log10(max))), m = max / p;
    const paso = (m <= 1.5 ? 0.25 : m <= 3 ? 0.5 : m <= 7 ? 1 : 2) * p;
    const tope = Math.ceil(max / paso) * paso;
    const pasos = []; for (let v = 0; v <= tope + 1e-9; v += paso) pasos.push(v);
    return { tope, pasos };
}
const dineroCorto = v => v >= 1000 ? `$${(v / 1000).toLocaleString('es-MX', { maximumFractionDigits: 1 })}k` : `$${Math.round(v)}`;

// Barras agrupadas: ventas y gastos por mes (una sola escala en pesos)
function graficaMensual(cont, datos) {
    const W = 520, H = 220, mL = 44, mR = 8, mT = 10, mB = 26;
    const max = Math.max(...datos.flatMap(d => [d.ventas, d.gastos]), 0);
    if (max === 0) { cont.innerHTML = '<p class="text-sm text-gray-500 text-center py-12">Registra ventas o gastos para ver la gráfica.</p>'; return; }
    const { tope, pasos } = escalaBonita(max);
    const y = v => mT + (H - mT - mB) * (1 - v / tope);
    const grupo = (W - mL - mR) / datos.length, bw = Math.min(26, (grupo - 14) / 2);
    let s = `<svg viewBox="0 0 ${W} ${H}" class="w-full h-auto" role="img" aria-label="Ventas y gastos de los últimos 6 meses">`;
    pasos.forEach(v => s += `<line x1="${mL}" x2="${W - mR}" y1="${y(v)}" y2="${y(v)}" stroke="#F1E4E8" stroke-width="1"/><text x="${mL - 6}" y="${y(v) + 3.5}" text-anchor="end" font-size="10" fill="#8A7A84">${dineroCorto(v)}</text>`);
    datos.forEach((d, i) => {
        const cx = mL + grupo * i + grupo / 2;
        [[d.ventas, COLOR_VENTAS, cx - bw - 1, 'Ventas'], [d.gastos, COLOR_GASTOS, cx + 1, 'Gastos']].forEach(([v, c, x, n]) => {
            const h = Math.max(0, y(0) - y(v));
            if (h > 0) s += `<path d="M${x},${y(0)} v${-(h - 4)} a4,4 0 0 1 4,-4 h${bw - 8} a4,4 0 0 1 4,4 v${h - 4} z" fill="${c}"/>`;
        });
        s += `<rect x="${cx - grupo / 2}" y="${mT}" width="${grupo}" height="${H - mT - mB}" fill="transparent" data-i="${i}" class="hit"/>`;
        s += `<text x="${cx}" y="${H - 8}" text-anchor="middle" font-size="11" fill="#6B5B66">${d.etiqueta}</text>`;
    });
    s += `<line x1="${mL}" x2="${W - mR}" y1="${y(0)}" y2="${y(0)}" stroke="#D9C8CF" stroke-width="1"/></svg>`;
    s += `<details class="mt-2 text-xs"><summary class="cursor-pointer text-gray-500">Ver como tabla</summary><table class="w-full mt-2 tabular"><thead><tr class="text-gray-500"><th class="text-left p-1">Mes</th><th class="text-right p-1">Ventas</th><th class="text-right p-1">Gastos</th></tr></thead><tbody>${datos.map(d => `<tr><td class="p-1">${d.mes}</td><td class="text-right p-1">${formatoMoneda(d.ventas)}</td><td class="text-right p-1">${formatoMoneda(d.gastos)}</td></tr>`).join('')}</tbody></table></details>`;
    cont.innerHTML = s;
    cont.querySelectorAll('.hit').forEach(r => {
        const d = datos[+r.dataset.i];
        const html = `<p class="font-semibold mb-1 capitalize">${d.mes}</p><p><span style="color:${COLOR_VENTAS}">■</span> Ventas ${formatoMoneda(d.ventas)}</p><p><span style="color:${COLOR_GASTOS}">■</span> Gastos ${formatoMoneda(d.gastos)}</p><p class="mt-1 text-white/80">Diferencia ${formatoMoneda(d.ventas - d.gastos)}</p>`;
        r.addEventListener('mousemove', e => { r.setAttribute('fill', 'rgba(242,167,195,.12)'); mostrarTooltip(e, html); });
        r.addEventListener('mouseleave', () => { r.setAttribute('fill', 'transparent'); ocultarTooltip(); });
    });
}

// Barras horizontales de una sola serie con etiqueta directa
function graficaBarrasH(cont, datos, vacio) {
    if (!datos.length) { cont.innerHTML = `<p class="text-sm text-gray-500 text-center py-12">${vacio}</p>`; return; }
    const max = Math.max(...datos.map(d => d.valor), 1);
    cont.innerHTML = `<div class="space-y-2.5">${datos.map((d, i) => `
        <div class="barra-h group" data-i="${i}">
            <div class="flex justify-between text-xs mb-1 gap-2"><span class="text-gray-700 truncate">${esc(d.etiqueta)}</span><span class="font-semibold text-brand-textDark tabular">${d.valor}</span></div>
            <div class="h-3 rounded-full bg-[#FBEFF3]"><div class="h-3 rounded-full transition-all group-hover:opacity-80" style="width:${Math.max(3, d.valor / max * 100)}%; background:${COLOR_BARRA}"></div></div>
        </div>`).join('')}</div>`;
    cont.querySelectorAll('.barra-h').forEach(el => {
        const d = datos[+el.dataset.i];
        el.addEventListener('mousemove', e => mostrarTooltip(e, `<p class="font-semibold">${esc(d.etiqueta)}</p><p>${esc(d.detalle)}</p>`));
        el.addEventListener('mouseleave', ocultarTooltip);
    });
}

/* ---------- Productos destacados (inicio) ---------- */
const DESTACADOS = ['playera-infantil', 'vaso-chupon', 'gorra', 'carrito'];
function renderizarDestacados() {
    const cont = document.getElementById('inicio-destacados');
    if (!cont || typeof CATALOGO_PRODUCTOS === 'undefined') return;
    cont.innerHTML = DESTACADOS.map((id, i) => {
        const p = CATALOGO_PRODUCTOS.find(x => x.id === id); if (!p) return '';
        const desde = precioDesdeProducto(p.cotizador, p.preset);
        return `<button onclick="navegarA('catalogo'); abrirProducto('${p.id}')" class="polaroid relative text-left ${i % 2 ? 'rotate-[1.5deg]' : '-rotate-[1.5deg]'}">
            <span class="cinta" aria-hidden="true"></span>
            <div class="aspect-square bg-brand-bg flex items-center justify-center overflow-hidden rounded-md"><img src="${CATALOGO_FOTOS[p.id]}" alt="${esc(p.nombre)}" loading="lazy" class="max-h-full max-w-full object-contain"></div>
            <p class="font-display font-semibold text-brand-textDark mt-3 leading-tight">${esc(p.nombre)}</p>
            ${desde ? `<p class="text-sm text-brand-purple font-semibold">Desde ${formatoMoneda(desde)}</p>` : ''}
        </button>`;
    }).join('');
}
