/* Personaliza Studio — dibujos del acomodo en planillas y rollos (SVG) */

const COLOR_PIEZA = '#F7AFCB', BORDE_PIEZA = '#E3679C', COLOR_LINEA = '#2F9C9E';

// d = { plW, plH, uW, uH, cols, rows, etqW, etqH, sep, cantidad, rend, planillas }
function svgPlanilla(d, enEsta, titulo) {
    const mx = (d.plW - d.uW) / 2, my = (d.plH - d.uH) / 2, sep = d.sep || 0;
    let s = `<svg viewBox="-0.5 -0.5 ${d.plW + 1} ${d.plH + 1}" class="w-full h-auto" role="img" aria-label="${titulo}">
        <rect x="0" y="0" width="${d.plW}" height="${d.plH}" fill="#FFFFFF" stroke="${COLOR_LINEA}" stroke-width="0.3" rx="0.4"/>
        <rect x="${mx}" y="${my}" width="${d.uW}" height="${d.uH}" fill="#F3FAFA" stroke="${COLOR_LINEA}" stroke-width="0.2" stroke-dasharray="0.6 0.4"/>`;
    let n = 0;
    for (let r = 0; r < d.rows && n < enEsta; r++) {
        for (let c = 0; c < d.cols && n < enEsta; c++) {
            const x = mx + c * (d.etqW + sep), y = my + r * (d.etqH + sep);
            s += `<rect x="${x}" y="${y}" width="${d.etqW}" height="${d.etqH}" fill="${COLOR_PIEZA}" fill-opacity="0.85" stroke="${BORDE_PIEZA}" stroke-width="0.12" rx="${Math.min(d.etqW, d.etqH) * 0.06}"/>`;
            n++;
        }
    }
    return s + '</svg>';
}

function dibujarPlanillas(contenedor, d, cantidad, maximo) {
    maximo = maximo || 6;
    let restantes = cantidad, html = '';
    const total = Math.ceil(cantidad / d.rend);
    for (let p = 1; p <= Math.min(total, maximo); p++) {
        const enEsta = Math.min(restantes, d.rend);
        html += `<figure class="text-center"><figcaption class="text-xs font-semibold text-brand-purple mb-1">Planilla ${p} · ${enEsta} pzs</figcaption>${svgPlanilla(d, enEsta, `Planilla ${p}`)}</figure>`;
        restantes -= enEsta;
    }
    if (total > maximo) html += `<div class="flex items-center justify-center text-sm text-gray-500 font-semibold border border-dashed border-gray-300 rounded-lg">+ ${total - maximo} planillas más</div>`;
    contenedor.innerHTML = html;
}

// d = { anchoRollo, cols, filas, etqW, etqH, sep, largo }
function dibujarRollo(contenedor, d, cantidad) {
    const sep = d.sep || 0;
    const filasMostrar = Math.min(d.filas, 40);
    const largoMostrar = filasMostrar * d.etqH + Math.max(0, filasMostrar - 1) * sep;
    let s = `<svg viewBox="-0.5 -0.5 ${d.anchoRollo + 1} ${largoMostrar + 1}" class="w-full h-auto max-h-[55vh]" role="img" aria-label="Acomodo en rollo">
        <rect x="0" y="0" width="${d.anchoRollo}" height="${largoMostrar}" fill="#FFFFFF" stroke="${COLOR_LINEA}" stroke-width="0.3"/>`;
    let n = 0;
    for (let r = 0; r < filasMostrar; r++) {
        for (let c = 0; c < d.cols && n < cantidad; c++) {
            s += `<rect x="${c * (d.etqW + sep)}" y="${r * (d.etqH + sep)}" width="${d.etqW}" height="${d.etqH}" fill="${COLOR_PIEZA}" fill-opacity="0.85" stroke="${BORDE_PIEZA}" stroke-width="0.15"/>`;
            n++;
        }
    }
    s += '</svg>';
    const nota = d.filas > filasMostrar ? `<p class="text-xs text-gray-500 text-center mt-2">Se muestran ${filasMostrar} de ${d.filas} filas.</p>` : '';
    contenedor.innerHTML = `<p class="text-xs font-semibold text-brand-purple text-center mb-2">Rollo de ${d.anchoRollo} cm · ${(d.largo / 100).toFixed(2)} m</p><div class="max-w-xs mx-auto">${s}</div>${nota}`;
}

function toggleVistaPrevia() {
    const contenido = document.getElementById('contenido-vista-previa');
    const oculto = contenido.classList.toggle('hidden');
    document.getElementById('btn-toggle-vista').style.transform = oculto ? 'rotate(180deg)' : '';
}
