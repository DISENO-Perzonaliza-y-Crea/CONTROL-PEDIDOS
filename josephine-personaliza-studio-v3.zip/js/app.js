/* Personaliza Studio — navegación general y arranque */

function confirmar(texto, textoSi) {
    return new Promise(res => {
        const m = document.getElementById('modal-confirmar');
        document.getElementById('confirmar-texto').innerText = texto;
        document.getElementById('confirmar-si').innerText = textoSi || 'Sí, continuar';
        m.classList.remove('hidden');
        const fin = v => { m.classList.add('hidden'); res(v); };
        document.getElementById('confirmar-si').onclick = () => fin(true);
        document.getElementById('confirmar-no').onclick = () => fin(false);
    });
}

const VISTAS = ['inicio', 'catalogo', 'cotizador', 'pedidos', 'gastos', 'ventas', 'inventario'];
let vistaActual = 'inicio';
function navegarA(vista) {
    if (!VISTAS.includes(vista)) vista = 'inicio';
    vistaActual = vista;
    document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
    document.getElementById(`vista-${vista}`).classList.add('active');
    document.querySelectorAll('[data-nav]').forEach(b => {
        const activo = b.dataset.nav === vista || (b.dataset.nav === 'mas' && ['catalogo', 'gastos', 'inventario'].includes(vista));
        b.classList.toggle('nav-activo', activo);
        if (activo) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    cerrarMenuMas();
    window.scrollTo(0, 0);

    if (vista === 'inicio') renderizarPanel();
    else if (vista === 'catalogo') renderizarCatalogo();
    else if (vista === 'cotizador') iniciarCotizador();
    else if (vista === 'pedidos') renderizarPedidos();
    else if (vista === 'gastos') { if (!document.getElementById('gasto-edit-id').value) document.getElementById('gas-fecha').value = hoyISO(); renderizarGastos(); }
    else if (vista === 'ventas') { if (!document.getElementById('ven-fecha').value) document.getElementById('ven-fecha').value = hoyISO(); renderizarVentas(); actualizarDashboard(); }
    else if (vista === 'inventario') renderizarInventario();
}
function aplicarLogoCabecera() {
    const n = obtenerNegocio(), img = document.getElementById('logo-cabecera'), txt = document.getElementById('logo-texto');
    if (!img) return;
    if (n.logo) { img.src = n.logo; img.classList.remove('hidden'); txt.classList.add('hidden'); }
    else { img.classList.add('hidden'); txt.classList.remove('hidden'); }
}
function irANuevaCotizacion() { tabCotizadorActual = 'cotizar'; navegarA('cotizador'); }
function toggleMenuMas() { document.getElementById('menu-mas').classList.toggle('hidden'); }
function cerrarMenuMas() { const m = document.getElementById('menu-mas'); if (m) m.classList.add('hidden'); }

// Alertas del cotizador
function mostrarError(mensaje) {
    document.getElementById('alerta-mensaje').innerText = mensaje;
    document.getElementById('alerta-error').classList.remove('hidden');
}
function ocultarError() { const a = document.getElementById('alerta-error'); if (a) a.classList.add('hidden'); }

function cambioPeriodo(pref) {
    const sel = document.getElementById(pref === 'panel' ? 'panel-periodo' : 'filtro-tiempo');
    const rango = sel.value === 'rango';
    const d = document.getElementById(`${pref}-desde`), h = document.getElementById(`${pref}-hasta`);
    d.classList.toggle('hidden', !rango); h.classList.toggle('hidden', !rango);
    if (rango && !d.value) { d.value = sumarDiasISO(hoyISO(), -30); h.value = hoyISO(); }
}
function rangoDe(pref) {
    const sel = document.getElementById(pref === 'panel' ? 'panel-periodo' : 'filtro-tiempo').value;
    return rangoPeriodo(sel, document.getElementById(`${pref}-desde`).value, document.getElementById(`${pref}-hasta`).value);
}
function llenarSelect(id, opciones, valor) {
    const el = document.getElementById(id); if (!el) return;
    el.innerHTML = opciones.map(o => { const [v, t] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(v)}" ${v === valor ? 'selected' : ''}>${esc(t)}</option>`; }).join('');
}

document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    ['modal-pago', 'modal-mov'].forEach(id => document.getElementById(id).classList.add('hidden'));
    if (!document.getElementById('modal-pedido').classList.contains('hidden')) cerrarDetallePedido();
    cerrarMenuMas();
});

document.addEventListener('DOMContentLoaded', () => {
    const cambios = ejecutarMigracion();
    llenarSelect('ped-estado', ESTADOS.map(e => [e.id, e.nombre]));
    llenarSelect('ped-anticipo-metodo', METODOS_PAGO);
    llenarSelect('pago-metodo', METODOS_PAGO);
    llenarSelect('ven-pago', METODOS_PAGO);
    document.getElementById('panel-fecha').textContent = new Date().toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    document.getElementById('anio-pie').textContent = new Date().getFullYear();
    aplicarLogoCabecera();
    navegarA('inicio');
    if (cambios) toast('Tus pedidos y ventas se actualizaron a la versión nueva. Se guardó una copia de los originales.');
});
