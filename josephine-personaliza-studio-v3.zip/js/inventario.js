/* =====================================================================
   Personaliza Studio — Inventario de materiales
   ===================================================================== */

const esBajo = m => num2(m.minimo) > 0 && num2(m.existencia) <= num2(m.minimo);
function materialesBajos() { return obtenerInventario().filter(esBajo); }

function abrirFormMaterial() {
    document.getElementById('form-material').reset();
    document.getElementById('mat-edit-id').value = '';
    document.getElementById('mat-existencia').disabled = false;
    document.getElementById('form-material-titulo').textContent = 'Nuevo material';
    document.getElementById('form-material-card').classList.remove('hidden');
    document.getElementById('form-material-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => document.getElementById('mat-nombre').focus(), 300);
}
function cerrarFormMaterial() { document.getElementById('form-material-card').classList.add('hidden'); document.getElementById('mat-edit-id').value = ''; }

async function guardarMaterial(ev) {
    ev.preventDefault();
    if (guardarMaterial._ocupado) return; guardarMaterial._ocupado = true;
    try {
        const v = id => document.getElementById(id).value.trim();
        const editId = v('mat-edit-id');
        const datos = { nombre: v('mat-nombre').slice(0, 80), categoria: v('mat-categoria'), unidad: v('mat-unidad'), minimo: num2(v('mat-minimo')),
            costo: num2(v('mat-costo')), proveedor: v('mat-proveedor').slice(0, 80), notas: v('mat-notas').slice(0, 200) };
        if (!datos.nombre) return toast('Escribe el nombre del material.', 'error');
        if (datos.minimo < 0 || datos.costo < 0) return toast('Los números no pueden ser negativos.', 'error');
        const lista = obtenerInventario();
        if (editId) {
            const m = lista.find(x => String(x.id) === editId); if (!m) return;
            Object.assign(m, datos, { actualizado: new Date().toISOString() });
        } else {
            const ex = num2(v('mat-existencia'));
            if (v('mat-existencia') === '' || ex < 0) return toast('Escribe la existencia actual (0 o más).', 'error');
            const igual = lista.find(x => x.nombre.toLowerCase() === datos.nombre.toLowerCase());
            if (igual && !(await confirmar(`Ya tienes "${igual.nombre}" en el inventario. ¿Agregar otro material con el mismo nombre?`, 'Agregar'))) return;
            lista.unshift({ id: nuevoId(), ...datos, existencia: ex, movimientos: [{ id: nuevoId(), fecha: hoyISO(), tipo: 'inicial', cantidad: ex, nota: 'Existencia inicial' }], creado: new Date().toISOString() });
        }
        if (!guardarInventario(lista)) return;
        cerrarFormMaterial(); renderizarInventario(); toast(editId ? 'Material actualizado' : 'Material agregado');
    } finally { setTimeout(() => guardarMaterial._ocupado = false, 500); }
}
function editarMaterial(id) {
    const m = obtenerInventario().find(x => x.id === id); if (!m) return;
    abrirFormMaterial();
    document.getElementById('form-material-titulo').textContent = `Editar ${m.nombre}`;
    const set = (k, v) => document.getElementById(k).value = v === undefined || v === null ? '' : v;
    set('mat-edit-id', m.id); set('mat-nombre', m.nombre); set('mat-categoria', m.categoria); set('mat-unidad', m.unidad); set('mat-existencia', m.existencia);
    set('mat-minimo', m.minimo); set('mat-costo', m.costo); set('mat-proveedor', m.proveedor); set('mat-notas', m.notas);
    document.getElementById('mat-existencia').disabled = true; // la existencia cambia con entradas, salidas o ajustes
}
async function eliminarMaterial(id) {
    const m = obtenerInventario().find(x => x.id === id); if (!m) return;
    if (!(await confirmar(`¿Eliminar "${m.nombre}" y su historial de movimientos?`, 'Eliminar'))) return;
    guardarInventario(obtenerInventario().filter(x => x.id !== id)); renderizarInventario(); toast('Material eliminado');
}

function abrirMovimiento(id, tipo) {
    const m = obtenerInventario().find(x => x.id === id); if (!m) return;
    const titulos = { entrada: 'Entrada (compra)', salida: 'Salida (uso en producción)', ajuste: 'Ajuste de conteo' };
    document.getElementById('mov-id').value = id; document.getElementById('mov-tipo').value = tipo;
    document.getElementById('mov-titulo').textContent = titulos[tipo];
    document.getElementById('mov-sub').textContent = `${m.nombre} · hay ${num2(m.existencia)} ${m.unidad}`;
    document.getElementById('mov-cantidad').value = tipo === 'ajuste' ? num2(m.existencia) : '';
    document.querySelector('label[for=mov-cantidad]').textContent = tipo === 'ajuste' ? 'Existencia real contada' : 'Cantidad';
    document.getElementById('mov-fecha').value = hoyISO();
    document.getElementById('mov-costo').value = m.costo || '';
    document.getElementById('mov-nota').value = '';
    document.getElementById('mov-costo-wrap').classList.toggle('hidden', tipo !== 'entrada');
    document.getElementById('mov-gasto-wrap').classList.toggle('hidden', tipo !== 'entrada');
    document.getElementById('mov-error').classList.add('hidden');
    document.getElementById('modal-mov').classList.remove('hidden');
    setTimeout(() => document.getElementById('mov-cantidad').focus(), 50);
}
function cerrarMovimiento() { document.getElementById('modal-mov').classList.add('hidden'); }
function confirmarMovimiento() {
    unaVez('mov', () => {
        const id = parseInt(document.getElementById('mov-id').value), tipo = document.getElementById('mov-tipo').value;
        const lista = obtenerInventario(); const m = lista.find(x => x.id === id); if (!m) return;
        const cant = num2(document.getElementById('mov-cantidad').value), fecha = document.getElementById('mov-fecha').value;
        const nota = document.getElementById('mov-nota').value.trim().slice(0, 120);
        const err = t => { const e = document.getElementById('mov-error'); e.textContent = t; e.classList.remove('hidden'); };
        if (!fecha) return err('Escribe la fecha.');
        if (tipo === 'ajuste' ? cant < 0 : !(cant > 0)) return err('Escribe una cantidad válida.');
        if (tipo === 'salida' && cant > num2(m.existencia) + 0.001) return err(`Solo hay ${num2(m.existencia)} ${m.unidad}.`);
        const antes = num2(m.existencia);
        m.existencia = num2(tipo === 'entrada' ? antes + cant : tipo === 'salida' ? antes - cant : cant);
        m.movimientos = m.movimientos || [];
        const mov = { id: nuevoId(), fecha, tipo, cantidad: tipo === 'ajuste' ? num2(cant - antes) : (tipo === 'salida' ? -cant : cant), nota };
        if (tipo === 'entrada') {
            const costo = num2(document.getElementById('mov-costo').value);
            if (costo > 0) { m.costo = costo; mov.costo = costo; }
            if (document.getElementById('mov-gasto').checked && costo > 0) {
                const gastos = obtenerGastos();
                gastos.unshift({ id: nuevoId(), fecha, categoria: '🖨️ Materiales', descripcion: `Compra: ${cant} ${m.unidad} de ${m.nombre}${nota ? ' (' + nota + ')' : ''}`, monto: num2(cant * costo), proveedor: m.proveedor || '', creado: new Date().toISOString() });
                guardarGastos(gastos); mov.gasto = true;
            }
        }
        m.movimientos.unshift(mov);
        if (!guardarInventario(lista)) return;
        cerrarMovimiento(); renderizarInventario();
        toast(`${m.nombre}: ahora hay ${m.existencia} ${m.unidad}${mov.gasto ? ' · gasto registrado' : ''}`);
    });
}

function renderizarInventario() {
    const todos = obtenerInventario();
    const q = document.getElementById('filtro-inventario').value.toLowerCase().trim();
    const soloBajos = document.getElementById('filtro-bajos').checked;
    const lista = todos.filter(m => (!soloBajos || esBajo(m)) && (!q || `${m.nombre} ${m.proveedor} ${m.categoria}`.toLowerCase().includes(q)))
        .sort((a, b) => (esBajo(b) - esBajo(a)) || a.nombre.localeCompare(b.nombre));
    const valor = todos.reduce((s, m) => s + num2(m.existencia) * num2(m.costo), 0);
    document.getElementById('inv-resumen').innerHTML =
        tarjetaKPI('Materiales', todos.length, '', 'fa-boxes-stacked', 'morado') +
        tarjetaKPI('Por agotarse', todos.filter(esBajo).length, 'en o debajo del mínimo', 'fa-triangle-exclamation', todos.some(esBajo) ? 'rojo' : 'gris', "document.getElementById('filtro-bajos').checked=true; renderizarInventario()") +
        tarjetaKPI('Valor del inventario', formatoMoneda(valor), 'existencia × costo', 'fa-coins', 'cian');
    document.getElementById('lista-inventario').innerHTML = lista.length ? lista.map(m => {
        const bajo = esBajo(m);
        const pct = num2(m.minimo) > 0 ? Math.min(100, num2(m.existencia) / (num2(m.minimo) * 2) * 100) : 100;
        return `<article class="bg-white rounded-2xl border ${bajo ? 'border-red-200' : 'border-gray-100'} shadow-sm p-4">
            <div class="flex flex-wrap items-center gap-3">
                <div class="flex-1 min-w-[180px]">
                    <p class="font-semibold text-brand-textDark">${esc(m.nombre)} ${bajo ? '<span class="pill bg-red-100 text-red-700"><i class="fa-solid fa-triangle-exclamation mr-0.5"></i>Por agotarse</span>' : ''}</p>
                    <p class="text-xs text-gray-500">${esc(m.categoria)}${m.proveedor ? ' · ' + esc(m.proveedor) : ''}${m.costo ? ' · ' + formatoMoneda(m.costo) + '/' + esc(m.unidad) : ''}</p>
                </div>
                <div class="w-40 tabular">
                    <p class="text-right"><span class="text-xl font-bold ${bajo ? 'text-red-600' : 'text-brand-textDark'}">${num2(m.existencia)}</span> <span class="text-xs text-gray-500">${esc(m.unidad)}</span></p>
                    ${num2(m.minimo) > 0 ? `<div class="h-1.5 bg-gray-100 rounded-full overflow-hidden mt-1"><div class="h-full rounded-full ${bajo ? 'bg-red-400' : 'bg-brand-cyan'}" style="width:${pct}%"></div></div><p class="text-[10px] text-gray-400 text-right mt-0.5">mínimo ${num2(m.minimo)}</p>` : ''}
                </div>
            </div>
            <div class="flex flex-wrap gap-2 mt-3 pt-3 border-t border-gray-100">
                <button onclick="abrirMovimiento(${m.id}, 'entrada')" class="btn-mini bg-green-50 text-green-700"><i class="fa-solid fa-plus mr-1"></i>Entrada</button>
                <button onclick="abrirMovimiento(${m.id}, 'salida')" class="btn-mini bg-orange-50 text-orange-700"><i class="fa-solid fa-minus mr-1"></i>Salida</button>
                <button onclick="abrirMovimiento(${m.id}, 'ajuste')" class="btn-mini bg-gray-100 text-gray-700"><i class="fa-solid fa-scale-balanced mr-1"></i>Ajuste</button>
                <button onclick="editarMaterial(${m.id})" class="btn-mini bg-gray-100 text-gray-700"><i class="fa-solid fa-pen mr-1"></i>Editar</button>
                <button onclick="eliminarMaterial(${m.id})" class="btn-mini bg-gray-100 text-red-600 ml-auto" aria-label="Eliminar ${esc(m.nombre)}"><i class="fa-solid fa-trash-can"></i></button>
            </div>
            ${(m.movimientos || []).length ? `<details class="mt-2"><summary class="cursor-pointer text-xs font-semibold text-brand-purple">Movimientos (${m.movimientos.length})</summary>
                <ul class="mt-2 space-y-1 text-xs">${m.movimientos.slice(0, 15).map(x => `<li class="flex justify-between gap-2"><span class="text-gray-500">${fechaCorta(x.fecha)} · ${{ inicial: 'Inicial', entrada: 'Entrada', salida: 'Salida', ajuste: 'Ajuste' }[x.tipo]}${x.nota ? ' · ' + esc(x.nota) : ''}${x.gasto ? ' · en gastos' : ''}</span><span class="font-semibold tabular ${x.cantidad < 0 ? 'text-orange-700' : 'text-green-700'}">${x.cantidad > 0 ? '+' : ''}${num2(x.cantidad)}</span></li>`).join('')}</ul></details>` : ''}
        </article>`;
    }).join('') : `<div class="bg-white rounded-2xl border-2 border-dashed border-brand-lilac/50 text-center text-gray-500 py-10 px-4">
        <i class="fa-solid fa-boxes-stacked text-3xl text-brand-lilac mb-2"></i><p>${todos.length ? 'Ningún material coincide.' : 'Agrega tus materiales (playeras, tazas, rollos, papel) para saber cuándo resurtir.'}</p></div>`;
}
function exportarInventarioCSV() {
    const l = obtenerInventario(); if (!l.length) return toast('No hay materiales para exportar', 'error');
    exportarCSV(`inventario-${hoyISO()}.csv`, ['Material', 'Categoría', 'Unidad', 'Existencia', 'Mínimo', 'Costo por unidad', 'Valor', 'Proveedor', 'Por agotarse', 'Notas'],
        l.map(m => [m.nombre, m.categoria, m.unidad, num2(m.existencia), num2(m.minimo), num2(m.costo), num2(num2(m.existencia) * num2(m.costo)), m.proveedor || '', esBajo(m) ? 'Sí' : 'No', m.notas || '']));
}
