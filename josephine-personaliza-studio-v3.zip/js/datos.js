/* =====================================================================
   Personaliza Studio — Datos: pedidos, pagos, ventas, gastos, inventario
   - Migra los datos de la versión anterior SIN borrarlos (guarda una copia).
   - Las cuentas (cobrado, ventas, por cobrar) son funciones puras para
     poder probarlas (pruebas/pruebas-datos.js).
   ===================================================================== */

const STORAGE_KEY_PEDIDOS = 'personalizaStudio_pedidos';
const STORAGE_KEY_GASTOS = 'personalizaStudio_gastos';
const STORAGE_KEY_VENTAS = 'personalizaStudio_ventas';
const STORAGE_KEY_INVENTARIO = 'personalizaStudio_inventario';
const KEY_FOLIO_PEDIDO = 'personalizaStudio_folioPedido';
const KEY_MIGRACION = 'personalizaStudio_migracionV3';

function leerLista(k) { try { const v = JSON.parse(localStorage.getItem(k)); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
function guardarLista(k, lista) {
    try { localStorage.setItem(k, JSON.stringify(lista)); return true; }
    catch (e) { if (typeof toast === 'function') toast('No se pudo guardar: el almacenamiento está lleno. Descarga un respaldo y borra archivos pesados.', 'error'); return false; }
}
const obtenerPedidos = () => leerLista(STORAGE_KEY_PEDIDOS);
const guardarPedidos = l => guardarLista(STORAGE_KEY_PEDIDOS, l);
const obtenerGastos = () => leerLista(STORAGE_KEY_GASTOS);
const guardarGastos = l => guardarLista(STORAGE_KEY_GASTOS, l);
const obtenerVentas = () => leerLista(STORAGE_KEY_VENTAS);
const guardarVentas = l => guardarLista(STORAGE_KEY_VENTAS, l);
const obtenerInventario = () => leerLista(STORAGE_KEY_INVENTARIO);
const guardarInventario = l => guardarLista(STORAGE_KEY_INVENTARIO, l);

/* ---------- Estados ---------- */
const ESTADOS = [
    { id: 'pendiente', nombre: 'Pendiente', icono: 'fa-hourglass-half', clase: 'bg-yellow-100 text-yellow-800' },
    { id: 'diseno', nombre: 'Diseño', icono: 'fa-pen-ruler', clase: 'bg-pink-100 text-pink-700' },
    { id: 'aprobacion', nombre: 'Aprobación', icono: 'fa-user-check', clase: 'bg-orange-100 text-orange-800' },
    { id: 'produccion', nombre: 'Producción', icono: 'fa-gears', clase: 'bg-blue-100 text-blue-800' },
    { id: 'listo', nombre: 'Listo', icono: 'fa-box', clase: 'bg-purple-100 text-purple-800' },
    { id: 'entregado', nombre: 'Entregado', icono: 'fa-circle-check', clase: 'bg-green-100 text-green-800' },
    { id: 'cancelado', nombre: 'Cancelado', icono: 'fa-ban', clase: 'bg-gray-200 text-gray-600' },
];
const estadoInfo = id => ESTADOS.find(e => e.id === id) || ESTADOS[0];
const ESTADOS_ACTIVOS = ['pendiente', 'diseno', 'aprobacion', 'produccion', 'listo'];
const PRIORIDADES = { normal: { nombre: 'Normal', clase: 'bg-gray-100 text-gray-600' }, alta: { nombre: 'Alta', clase: 'bg-orange-100 text-orange-700' }, urgente: { nombre: 'Urgente', clase: 'bg-red-100 text-red-700' } };
const METODOS_PAGO = ['Efectivo', 'Transferencia', 'Tarjeta', 'Depósito', 'Otro'];

const ESTADO_V1 = { '🟡 Pendiente': 'pendiente', '🔵 En producción': 'produccion', '🟣 Listo': 'listo', '🟢 Entregado': 'entregado', '🔴 Cancelado': 'cancelado' };
const metodoDeTexto = t => { const s = String(t || ''); const m = METODOS_PAGO.find(x => s.toLowerCase().includes(x.toLowerCase())); return m || (s.replace(/[^\p{L}\s]/gu, '').trim() || 'Otro'); };

/* ---------- Cuentas de un pedido ---------- */
const totalPedido = p => num2(p.precio);
const pagadoPedido = p => num2((p.pagos || []).reduce((s, x) => s + (parseFloat(x.monto) || 0), 0));
const saldoPedido = p => p.estado === 'cancelado' ? 0 : num2(Math.max(0, totalPedido(p) - pagadoPedido(p)));
function estadoPago(p) {
    const t = totalPedido(p), pg = pagadoPedido(p);
    if (pg <= 0) return { id: 'sin', nombre: 'Sin pago', clase: 'bg-red-50 text-red-700' };
    if (pg + 0.005 < t) return { id: 'parcial', nombre: 'Abonado', clase: 'bg-yellow-50 text-yellow-800' };
    if (pg > t + 0.005) return { id: 'sobre', nombre: 'Pagó de más', clase: 'bg-blue-50 text-blue-700' };
    return { id: 'pagado', nombre: 'Pagado', clase: 'bg-green-50 text-green-700' };
}
function entregaInfo(p, hoy) {
    hoy = hoy || hoyISO();
    if (!p.entrega || !ESTADOS_ACTIVOS.includes(p.estado)) return null;
    const d = diasEntre(hoy, p.entrega);
    if (d < 0) return { tipo: 'atrasado', texto: `Atrasado ${-d} día${d === -1 ? '' : 's'}`, clase: 'bg-red-100 text-red-700' };
    if (d === 0) return { tipo: 'hoy', texto: 'Entrega hoy', clase: 'bg-orange-100 text-orange-800' };
    if (d === 1) return { tipo: 'manana', texto: 'Mañana', clase: 'bg-yellow-100 text-yellow-800' };
    return { tipo: 'futuro', texto: `En ${d} días`, clase: 'bg-gray-100 text-gray-600' };
}

/* ---------- Folios ---------- */
function siguienteFolioPedido(pedidos) {
    const usados = new Set(pedidos.map(p => p.folio));
    let n = parseInt(localStorage.getItem(KEY_FOLIO_PEDIDO)) || 0;
    const max = pedidos.reduce((m, p) => Math.max(m, parseInt(String(p.folio || '').replace(/\D/g, '')) || 0), 0);
    n = Math.max(n, max);
    let folio; do { n++; folio = `PED-${String(n).padStart(4, '0')}`; } while (usados.has(folio));
    try { localStorage.setItem(KEY_FOLIO_PEDIDO, String(n)); } catch (e) {}
    return folio;
}

/* ---------- Migración de la versión anterior (sin borrar nada) ----------
   - Copia los datos originales a *_v1_respaldo la primera vez.
   - Pedidos: folio, estado nuevo, anticipo → primer pago.
   - Ventas "Convertido desde pedido #ID": se ligan al pedido; si un pedido
     tenía varias ventas, solo la primera cuenta y las demás se marcan como
     duplicadas (no se borran). El saldo que se cobró al convertir se
     registra como pago para que no aparezca como deuda.                     */
function migrarDatos(pedidosRaw, ventasRaw) {
    const ahora = new Date().toISOString();
    let cambios = 0;
    const pedidos = pedidosRaw.map(p => ({ ...p }));
    const ventas = ventasRaw.map(v => ({ ...v }));

    // Folios en orden de creación
    const sinFolio = pedidos.filter(p => !p.folio).sort((a, b) => (a.id || 0) - (b.id || 0));
    let n = pedidos.reduce((m, p) => Math.max(m, parseInt(String(p.folio || '').replace(/\D/g, '')) || 0), 0);
    sinFolio.forEach(p => { n++; p.folio = `PED-${String(n).padStart(4, '0')}`; });

    pedidos.forEach(p => {
        if (p.v === 3) return;
        cambios++;
        const estadoViejo = p.estado;
        p.estado = ESTADO_V1[p.estado] || (ESTADOS.some(e => e.id === p.estado) ? p.estado : 'pendiente');
        p.precio = num2(p.precio);
        p.cantidad = parseInt(p.cantidad) || 1;
        p.prioridad = p.prioridad || 'normal';
        p.notasInternas = p.notasInternas || '';
        p.archivos = p.archivos || [];
        p.historial = p.historial || [];
        if (!Array.isArray(p.pagos)) {
            p.pagos = [];
            const ant = num2(p.anticipo);
            if (ant > 0) p.pagos.push({ id: nuevoId(), fecha: p.fecha || hoyISO(), monto: ant, metodo: 'No registrado', nota: 'Anticipo (de la versión anterior)' });
        }
        if (p.estado === 'entregado' && !p.fechaEntregado) p.fechaEntregado = p.entrega || p.fecha;
        p.historial.push({ fecha: ahora, texto: `Pedido actualizado a la versión nueva${estadoViejo && estadoViejo !== p.estado ? ` (estado "${estadoViejo}")` : ''}.` });
        p.v = 3;
    });

    // Ventas
    const vistos = new Set();
    ventas.slice().sort((a, b) => (a.id || 0) - (b.id || 0)).forEach(v => {
        if (v.v === 3) { if (v.pedidoId && !v.duplicada) vistos.add(v.pedidoId); return; }
        cambios++;
        v.precio = num2(v.precio);
        const m = String(v.observaciones || '').match(/Convertido desde pedido #(\d+)/);
        if (m) { v.pedidoId = parseInt(m[1]); v.origen = 'pedido'; }
        else v.origen = v.origen || 'manual';
        if (v.pedidoId) {
            if (vistos.has(v.pedidoId)) v.duplicada = true;
            else {
                vistos.add(v.pedidoId);
                const p = pedidos.find(x => x.id === v.pedidoId);
                if (p) {
                    p.ventaId = v.id;
                    const falta = num2(totalPedido(p) - pagadoPedido(p));
                    if (falta > 0) {
                        p.pagos.push({ id: nuevoId(), fecha: v.fecha || hoyISO(), monto: falta, metodo: metodoDeTexto(v.pago), nota: 'Saldo cobrado al registrar la venta (versión anterior)' });
                        p.historial.push({ fecha: ahora, texto: `Se registró como pago el saldo de ${formatoMoneda(falta)} cobrado en la venta del ${v.fecha}.` });
                    }
                    if (p.estado !== 'entregado' && p.estado !== 'cancelado') { /* se respeta el estado que tenía */ }
                }
            }
        }
        v.v = 3;
    });
    return { pedidos, ventas, cambios };
}
function ejecutarMigracion() {
    try {
        const pedidos = obtenerPedidos(), ventas = obtenerVentas();
        const pendiente = pedidos.some(p => p.v !== 3) || ventas.some(v => v.v !== 3);
        if (!pendiente) return 0;
        if (!localStorage.getItem('personalizaStudio_pedidos_v1_respaldo')) {
            localStorage.setItem('personalizaStudio_pedidos_v1_respaldo', localStorage.getItem(STORAGE_KEY_PEDIDOS) || '[]');
            localStorage.setItem('personalizaStudio_ventas_v1_respaldo', localStorage.getItem(STORAGE_KEY_VENTAS) || '[]');
        }
        const r = migrarDatos(pedidos, ventas);
        guardarPedidos(r.pedidos); guardarVentas(r.ventas);
        localStorage.setItem(KEY_MIGRACION, new Date().toISOString());
        return r.cambios;
    } catch (e) { console.error('Migración', e); return 0; }
}

/* ---------- Resumen financiero ----------
   Ventas     = lo vendido en el periodo (ventas manuales + pedidos entregados con venta). Las duplicadas no cuentan.
   Cobrado    = dinero que entró en el periodo (pagos de pedidos + ventas manuales).
   Por cobrar = lo que deben los clientes HOY (pedidos no cancelados con saldo).
   Utilidad   = ventas − gastos del periodo (estimada).                       */
function resumenFinanciero(rango, pedidos, ventas, gastos) {
    const ventasValidas = ventas.filter(v => !v.duplicada);
    const ventasPeriodo = ventasValidas.filter(v => enRango(v.fecha, rango));
    const totalVentas = num2(ventasPeriodo.reduce((s, v) => s + num2(v.precio), 0));
    const cobradoPedidos = num2(pedidos.reduce((s, p) => s + (p.pagos || []).filter(x => enRango(x.fecha, rango)).reduce((a, x) => a + num2(x.monto), 0), 0));
    const cobradoManual = num2(ventasPeriodo.filter(v => v.origen !== 'pedido').reduce((s, v) => s + num2(v.precio), 0));
    const totalGastos = num2(gastos.filter(g => enRango(g.fecha, rango)).reduce((s, g) => s + num2(g.monto), 0));
    const porCobrar = num2(pedidos.reduce((s, p) => s + saldoPedido(p), 0));
    return {
        ventas: totalVentas, numVentas: ventasPeriodo.length, cobrado: num2(cobradoPedidos + cobradoManual), gastos: totalGastos,
        utilidad: num2(totalVentas - totalGastos), flujo: num2(cobradoPedidos + cobradoManual - totalGastos), porCobrar,
        pedidosPeriodo: pedidos.filter(p => enRango(p.fecha, rango)).length
    };
}
function productosMasVendidos(rango, pedidos, ventas) {
    const conteo = {};
    const sumar = (nombre, cantidad, total) => {
        const k = String(nombre || 'Sin nombre').trim();
        if (!conteo[k]) conteo[k] = { nombre: k, cantidad: 0, total: 0 };
        conteo[k].cantidad += parseInt(cantidad) || 0; conteo[k].total += num2(total);
    };
    pedidos.filter(p => p.estado !== 'cancelado' && enRango(p.fecha, rango)).forEach(p => {
        if (Array.isArray(p.partidas) && p.partidas.length) p.partidas.forEach(x => sumar(x.nombre, x.cantidad, x.total));
        else sumar(p.producto, p.cantidad, p.precio);
    });
    ventas.filter(v => !v.duplicada && v.origen !== 'pedido' && enRango(v.fecha, rango)).forEach(v => sumar(v.producto, v.cantidad, v.precio));
    return Object.values(conteo).sort((a, b) => b.cantidad - a.cantidad || b.total - a.total);
}
function serieMensual(meses, ventas, gastos, hoy) {
    const base = parseISO(hoy || hoyISO());
    const salida = [];
    for (let i = meses - 1; i >= 0; i--) {
        const d = new Date(base.getFullYear(), base.getMonth() - i, 1);
        const r = { desde: fechaISO(d), hasta: fechaISO(new Date(d.getFullYear(), d.getMonth() + 1, 0)) };
        salida.push({
            etiqueta: d.toLocaleDateString('es-MX', { month: 'short' }).replace('.', ''),
            mes: d.toLocaleDateString('es-MX', { month: 'long', year: 'numeric' }),
            ventas: num2(ventas.filter(v => !v.duplicada && enRango(v.fecha, r)).reduce((s, v) => s + num2(v.precio), 0)),
            gastos: num2(gastos.filter(g => enRango(g.fecha, r)).reduce((s, g) => s + num2(g.monto), 0))
        });
    }
    return salida;
}

/* ---------- Archivos del diseño (IndexedDB: aguanta mucho más que localStorage) ---------- */
const IDB_NOMBRE = 'personalizaStudio', IDB_STORE = 'archivos';
function abrirIDB() {
    return new Promise((ok, mal) => {
        if (!window.indexedDB) return mal(new Error('Este navegador no permite guardar archivos.'));
        const req = indexedDB.open(IDB_NOMBRE, 1);
        req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(IDB_STORE)) req.result.createObjectStore(IDB_STORE, { keyPath: 'id' }); };
        req.onsuccess = () => ok(req.result);
        req.onerror = () => mal(req.error);
    });
}
async function idb(modo, fn) {
    const db = await abrirIDB();
    return new Promise((ok, mal) => {
        const tx = db.transaction(IDB_STORE, modo); const st = tx.objectStore(IDB_STORE);
        const r = fn(st);
        tx.oncomplete = () => ok(r && 'result' in r ? r.result : undefined);
        tx.onerror = () => mal(tx.error); tx.onabort = () => mal(tx.error);
    });
}
const guardarArchivoIDB = reg => idb('readwrite', st => st.put(reg));
const leerArchivoIDB = id => idb('readonly', st => st.get(id));
const borrarArchivoIDB = id => idb('readwrite', st => st.delete(id));
const todosArchivosIDB = () => idb('readonly', st => st.getAll());

if (typeof module !== 'undefined') module.exports = { migrarDatos, resumenFinanciero, productosMasVendidos, serieMensual, saldoPedido, pagadoPedido, estadoPago, entregaInfo, siguienteFolioPedido, ESTADOS };
