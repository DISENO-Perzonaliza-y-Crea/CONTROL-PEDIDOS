// Catálogo de productos (fotos en img/catalogo, fichas en img/fichas)
// Para mostrar un precio en el catálogo, escribe el número en "precio" (ej: precio: 25).
const CATALOGO_PRODUCTOS = [
{
"id": "lonas",
"nombre": "Lonas",
"categoria": "Fiestas y eventos",
"descripcion": "Lonas impresas a todo color para cumpleaños, XV años, bautizos y graduaciones, con foto, nombre y el tema de tu fiesta.",
"ficha": null,
"cotizador": "lonas",
"preset": null
},
{
"id": "vaso-mini",
"nombre": "Vaso mini",
"categoria": "Vasos y tazas",
"descripcion": "Vaso de plástico con tapa a presión y popote, ideal como recuerdo para XV años, bodas, bautizos y cumpleaños. Diseño impreso en blanco sobre colores metálicos (dorado y plata).",
"ficha": "1",
"cotizador": "vaso_mini",
"preset": null
},
{
"id": "vaso-chupon",
"nombre": "Vaso chupón",
"categoria": "Vasos y tazas",
"descripcion": "Vaso transparente con tapa tipo chupón y diseño a color con el nombre de cada niño. Ideal como recuerdo de fiestas infantiles.",
"ficha": null,
"cotizador": "vaso_chupon",
"preset": null
},
{
"id": "gorra",
"nombre": "Gorras trucker",
"categoria": "Textiles",
"descripcion": "Gorra estilo trucker con frente blanco estampado, malla trasera y visera curva. Combínala con playeras del mismo diseño.",
"ficha": "4",
"cotizador": "gorra",
"preset": null
},
{
"id": "playera",
"nombre": "Playeras",
"categoria": "Textiles",
"descripcion": "Playera de manga corta, cuello redondo, con frase y diseño a todo color al frente. Un regalo divertido para papá, el abuelo o toda la familia.",
"ficha": "5",
"cotizador": "playera",
"preset": {
"talla": "Adulto"
}
},
{
"id": "playera-infantil",
"nombre": "Playeras infantiles",
"categoria": "Textiles",
"descripcion": "Playera blanca para niñas y niños con diseño a color y nombre personalizado. Ideal para fiestas, cumpleaños y grupos.",
"ficha": "3",
"cotizador": "playera",
"preset": {
"talla": "Infantil"
}
},
{
"id": "sudadera",
"nombre": "Sudaderas",
"categoria": "Textiles",
"descripcion": "Sudadera con capucha y estampado DTF a todo color, en el frente, la espalda o ambos lados. Ideal para parejas y regalos.",
"ficha": "7",
"cotizador": "sudadera",
"preset": null
},
{
"id": "set-tazas",
"nombre": "Set de tazas",
"categoria": "Vasos y tazas",
"descripcion": "Juego de dos tazas en caja de regalo con mensaje personalizado. Perfecto para San Valentín, aniversarios y parejas.",
"ficha": "2",
"cotizador": "set_tazas",
"preset": null
},
{
"id": "taza",
"nombre": "Tazas",
"categoria": "Vasos y tazas",
"descripcion": "Taza de cerámica blanca de 11 oz con diseño a todo color. Perfecta para bautizos, aniversarios o San Valentín.",
"ficha": "2",
"cotizador": "taza",
"preset": null
},
{
"id": "coroplast",
"nombre": "Figuras de coroplast",
"categoria": "Fiestas y eventos",
"descripcion": "Figuras recortadas en coroplast con el personaje o tema de tu fiesta. Decoración resistente para mesas, entradas y backdrops.",
"ficha": null,
"cotizador": "coroplast",
"preset": null
},
{
"id": "cabezones",
"nombre": "Cabezones",
"categoria": "Fiestas y eventos",
"descripcion": "Cabezas gigantes recortadas con la foto del festejado. Divertidas para graduaciones, cumpleaños y despedidas.",
"ficha": null,
"cotizador": "cabezones",
"preset": null
},
{
"id": "carrito",
"nombre": "Carrito personalizado",
"categoria": "Regalos",
"descripcion": "Auto coleccionable en empaque tipo blíster personalizado con tu foto, nombre y fecha. Un recuerdo original para XV años, bodas y cumpleaños.",
"ficha": "11",
"cotizador": "carrito",
"preset": null
},
{
"id": "forrado",
"nombre": "Forrado de cuadernos",
"categoria": "Escolares",
"descripcion": "Forrado con portada personalizada: nombre del alumno, materia, maestra y grado. Temáticos con brillo holográfico o por materia.",
"ficha": "8",
"cotizador": "forrado",
"preset": null
},
{
"id": "etiquetas",
"nombre": "Etiquetas escolares",
"categoria": "Escolares",
"descripcion": "Etiquetas adhesivas con nombre y personaje para cuadernos y libros, con protector transparente. Opción de frase divertida y estampitas.",
"ficha": "9",
"cotizador": "etiquetas",
"preset": null
},
{
"id": "cake-toppers",
"nombre": "Cake toppers de caras",
"categoria": "Fiestas y eventos",
"descripcion": "Toppers para pastel con la carita del festejado y gorrito de fiesta, recortados a la silueta.",
"ficha": null,
"cotizador": "cake_toppers",
"preset": null
},
{
"id": "gorros",
"nombre": "Gorros de fiesta con cara",
"categoria": "Fiestas y eventos",
"descripcion": "Gorros de fiesta con la foto del festejado. Un detalle divertido para todos los invitados.",
"ficha": null,
"cotizador": "gorros_fiesta",
"preset": null
},
{
"id": "tatuajes",
"nombre": "Tatuajes",
"categoria": "Stickers y tatuajes",
"descripcion": "Tatuajes temporales con foto o diseño personalizado, recortados en silueta. Ideales para graduaciones y fiestas.",
"ficha": null,
"cotizador": "tatuajes",
"preset": null
},
{
"id": "stickers-nombre",
"nombre": "Stickers con nombre",
"categoria": "Escolares",
"descripcion": "Stickers recortados con el nombre del niño para marcar lápices, colores y útiles. En kit con etiqueta grande o en hoja de nombres multicolor.",
"ficha": "10",
"cotizador": "stickers_nombre",
"preset": null
},
{
"id": "stickers-silueta",
"nombre": "Stickers de silueta",
"categoria": "Stickers y tatuajes",
"descripcion": "Stickers recortados al contorno con la foto o diseño que quieras. Para recuerdos, bolsitas y regalos.",
"ficha": null,
"cotizador": "stickers",
"preset": {
"forma": "Silueta"
}
},
{
"id": "stickers-circulares",
"nombre": "Stickers circulares",
"categoria": "Stickers y tatuajes",
"descripcion": "Stickers redondos personalizados para baby shower, bautizos y bodas; para cerrar bolsitas, frascos y cajitas de recuerdo.",
"ficha": null,
"cotizador": "stickers",
"preset": {
"forma": "Circular"
}
}
];
const CATALOGO_FOTOS = new Proxy({}, { get: (_, id) => `img/catalogo/${id}.jpg` });
const CATALOGO_FICHAS = new Proxy({}, { get: (_, n) => `img/fichas/ficha-${n}.jpg` });
const WHATSAPP_NEGOCIO = '524423520267';
let catalogoCategoria = 'Todos';

function renderizarCatalogo() {
    CATALOGO_PRODUCTOS.forEach(p => p.precio = precioDesdeProducto(p.cotizador, p.preset));
    const cats = ['Todos', ...new Set(CATALOGO_PRODUCTOS.map(p => p.categoria))];
    document.getElementById('cat-filtros').innerHTML = cats.map(c => {
        const activo = c === catalogoCategoria;
        const iconos = { 'Todos': 'fa-heart', 'Textiles': 'fa-shirt', 'Vasos y tazas': 'fa-mug-hot', 'Fiestas y eventos': 'fa-cake-candles', 'Regalos': 'fa-gift', 'Escolares': 'fa-pencil', 'Stickers y tatuajes': 'fa-star' };
        return `<button onclick="filtrarCategoriaCatalogo('${c}')" class="chip-categoria ${activo ? 'activo' : ''}" aria-pressed="${activo}"><i class="fa-solid ${iconos[c] || 'fa-tag'} mr-1"></i>${c}</button>`;
    }).join('');

    const q = (document.getElementById('cat-buscar').value || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const lista = CATALOGO_PRODUCTOS.filter(p => {
        if (catalogoCategoria !== 'Todos' && p.categoria !== catalogoCategoria) return false;
        const texto = (p.nombre + ' ' + p.categoria + ' ' + p.descripcion).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        return texto.includes(q);
    });

    document.getElementById('cat-vacio').classList.toggle('hidden', lista.length > 0);
    const fondos = ['#FDE4EE', '#FEF0D4', '#DDF1F0', '#FDE2D4'];
    document.getElementById('cat-grid').innerHTML = lista.map((p, i) => `
        <button onclick="abrirProducto('${p.id}')" class="tarjeta-producto">
            <div class="foto" style="background:${fondos[i % 4]}"><img src="${CATALOGO_FOTOS[p.id]}" alt="${esc(p.nombre)}" loading="lazy"></div>
            ${p.precio ? `<span class="etiqueta-precio">Desde ${formatoMoneda(p.precio)}</span>` : ''}
            <div class="px-1.5 pt-3 pb-1">
                <p class="text-[10px] font-semibold text-[#2F9C9E] uppercase tracking-wider">${esc(p.categoria)}</p>
                <h4 class="font-display font-semibold text-brand-textDark text-base md:text-lg leading-tight mt-0.5">${esc(p.nombre)}</h4>
                <div class="flex justify-between items-center mt-2 gap-2">
                    <span class="text-xs font-semibold text-[#C9457F]"><i class="fa-solid fa-calculator mr-1"></i>Cotizar</span>
                    ${p.ficha ? '<span class="text-[10px] bg-[#FEF0D4] text-[#B7791F] px-2 py-0.5 rounded-full font-semibold">Ver ficha</span>' : ''}
                </div>
            </div>
        </button>`).join('');
}

function filtrarCategoriaCatalogo(c) { catalogoCategoria = c; renderizarCatalogo(); }

function abrirProducto(id) {
    const p = CATALOGO_PRODUCTOS.find(x => x.id === id);
    if (!p) return;
    document.getElementById('mp-categoria').innerText = p.categoria;
    document.getElementById('mp-nombre').innerText = p.nombre;
    document.getElementById('mp-descripcion').innerText = p.descripcion;
    const img = document.getElementById('mp-imagen');
    img.src = p.ficha ? CATALOGO_FICHAS[p.ficha] : CATALOGO_FOTOS[p.id];
    img.alt = p.nombre;
    img.className = p.ficha ? 'w-full h-auto block' : 'max-w-full max-h-[60vh] mx-auto block p-4';
    const precio = document.getElementById('mp-precio');
    precio.classList.toggle('hidden', !p.precio);
    if (p.precio) precio.innerText = 'Desde ' + formatoMoneda(p.precio);

    const btnCot = document.getElementById('mp-btn-cotizar');
    btnCot.classList.toggle('hidden', !p.cotizador);
    btnCot.onclick = () => cotizarDesdeCatalogo(p.id);
    document.getElementById('mp-btn-pedido').onclick = () => pedidoDesdeCatalogo(p.id);
    const msg = `Hola, me interesa el producto "${p.nombre}" del catálogo de Personaliza Studio. ¿Me pueden dar informes?`;
    document.getElementById('mp-btn-wa').href = `https://wa.me/${WHATSAPP_NEGOCIO}?text=${encodeURIComponent(msg)}`;

    document.getElementById('modal-producto').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function cerrarProducto() {
    document.getElementById('modal-producto').classList.add('hidden');
    document.body.style.overflow = '';
}

function cotizarDesdeCatalogo(id) {
    const p = CATALOGO_PRODUCTOS.find(x => x.id === id);
    cerrarProducto();
    if (p && p.cotizador) seleccionarProductoCotizador(p.cotizador, p.preset);
    else navegarA('cotizador');
}

function pedidoDesdeCatalogo(id) {
    const p = CATALOGO_PRODUCTOS.find(x => x.id === id);
    cerrarProducto();
    navegarA('pedidos');
    if (p) document.getElementById('ped-producto').value = p.nombre;
    document.getElementById('ped-cliente').focus();
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarProducto(); });
