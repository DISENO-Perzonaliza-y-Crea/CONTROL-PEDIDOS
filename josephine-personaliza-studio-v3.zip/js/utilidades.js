/* Personaliza Studio — utilidades compartidas (fechas locales, texto, avisos, CSV) */

// Fechas SIEMPRE en hora local (antes se usaba UTC y después de las 6 pm cambiaba el día)
function fechaISO(d) { d = d || new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
function hoyISO() { return fechaISO(new Date()); }
function parseISO(iso) { if (!iso) return null; const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number); return y ? new Date(y, (m || 1) - 1, d || 1) : null; }
function sumarDiasISO(iso, dias) { const d = parseISO(iso) || new Date(); d.setDate(d.getDate() + dias); return fechaISO(d); }
function diasEntre(desdeISO, hastaISO) { return Math.round((parseISO(hastaISO) - parseISO(desdeISO)) / 86400000); }
function fechaLarga(iso) { const d = parseISO(iso); return d ? d.toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' }) : ''; }
function fechaCorta(iso) { const d = parseISO(iso); return d ? d.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' }) : '—'; }
function fechaHora(isoCompleto) { const d = new Date(isoCompleto); return isNaN(d) ? '' : d.toLocaleString('es-MX', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }

// Rangos de fechas para filtros. La semana empieza el lunes.
function rangoPeriodo(periodo, desde, hasta) {
    const hoy = new Date(); const h = hoyISO();
    const ini = (y, m, d) => fechaISO(new Date(y, m, d));
    switch (periodo) {
        case 'hoy': return { desde: h, hasta: h, etiqueta: 'Hoy' };
        case 'semana': { const dia = (hoy.getDay() + 6) % 7; return { desde: sumarDiasISO(h, -dia), hasta: h, etiqueta: 'Esta semana' }; }
        case 'mes': return { desde: ini(hoy.getFullYear(), hoy.getMonth(), 1), hasta: h, etiqueta: 'Este mes' };
        case 'mes_pasado': return { desde: ini(hoy.getFullYear(), hoy.getMonth() - 1, 1), hasta: ini(hoy.getFullYear(), hoy.getMonth(), 0), etiqueta: 'Mes pasado' };
        case '30': return { desde: sumarDiasISO(h, -29), hasta: h, etiqueta: 'Últimos 30 días' };
        case 'anio': return { desde: ini(hoy.getFullYear(), 0, 1), hasta: h, etiqueta: 'Este año' };
        case 'rango': return { desde: desde || '0000-01-01', hasta: hasta || '9999-12-31', etiqueta: 'Rango' };
        default: return { desde: '0000-01-01', hasta: '9999-12-31', etiqueta: 'Todo' };
    }
}
const enRango = (iso, r) => !!iso && iso.slice(0, 10) >= r.desde && iso.slice(0, 10) <= r.hasta;

function esc(s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
function num2(v) { const n = parseFloat(v); return isNaN(n) ? 0 : Math.round(n * 100) / 100; }
function formatoMoneda(valor) { return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(valor || 0); }
function nuevoId() { return Date.now() * 1000 + Math.floor(Math.random() * 1000); }

function toast(msg, tipo) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = `fixed left-1/2 -translate-x-1/2 bottom-24 md:bottom-8 z-[90] text-white text-sm font-semibold px-5 py-3 rounded-full shadow-xl max-w-[90vw] text-center ${tipo === 'error' ? 'bg-red-600' : 'bg-brand-textDark'}`;
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.add('hidden'), tipo === 'error' ? 4000 : 2400);
}

// Descarga un CSV que Excel abre con acentos correctos
function exportarCSV(nombreArchivo, columnas, filas) {
    const celda = v => { const s = v === undefined || v === null ? '' : String(v); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const csv = '﻿' + [columnas.map(celda).join(','), ...filas.map(f => f.map(celda).join(','))].join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = nombreArchivo;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast(`Se descargó ${nombreArchivo}`);
}

// Evita que un doble clic registre dos veces lo mismo
const _enCurso = new Set();
function unaVez(clave, fn) {
    if (_enCurso.has(clave)) return;
    _enCurso.add(clave);
    try { return fn(); } finally { setTimeout(() => _enCurso.delete(clave), 350); }
}

if (typeof module !== 'undefined') module.exports = { fechaISO, hoyISO, parseISO, sumarDiasISO, diasEntre, rangoPeriodo, enRango, num2 };
