/* =====================================================================
   Personaliza Studio — Gastos, ventas y cobranza
   ===================================================================== */

/* ---------------- Gastos ---------------- */
async function guardarGasto(ev) {
    ev.preventDefault();
    if (guardarGasto._ocupado) return; guardarGasto._ocupado = true;
    try {
        const v = id => document.getElementById(id).value.trim();
        const editId = v('gasto-edit-id');
        const g = { fecha: v('gas-fecha'), categoria: v('gas-categoria'), descripcion: v('gas-descripcion').slice(0, 200), monto: num2(v('gas-monto')), proveedor: v('gas-proveedor').slice(0, 80) };
        if (!g.fecha) return toast('Escribe la fecha del gasto.', 'error');
        if (!(g.monto > 0)) return toast('El monto debe ser mayor a 0.', 'error');
        if (!g.descripcion) return toast('Escribe una descripción del gasto.', 'error');
        const gastos = obtenerGastos();
        if (editId) {
            const i = gastos.findIndex(x => String(x.id) === editId);
            if (i < 0) return toast('No se encontró el gasto.', 'error');
            gastos[i] = { ...gastos[i], ...g, actualizado: new Date().toISOString() };
        } else {
            const igual = gastos.find(x => x.fecha === g.fecha && num2(x.monto) === g.monto && String(x.descripcion).toLowerCase() === g.descripcion.toLowerCase());
            if (igual && !(await confirmar(`Ya registraste "${igual.descripcion}" por ${formatoMoneda(igual.monto)} ese mismo día. ¿Registrar otro igual?`, 'Registrar otro'))) return;
            gastos.unshift({ id: nuevoId(), ...g, creado: new Date().toISOString() });
        }
        if (!guardarGastos(gastos)) return;
        toast(editId ? 'Gasto actualizado' : 'Gasto registrado');
        resetFormGasto(); renderizarGastos();
    } finally { setTimeout(() => guardarGasto._ocupado = false, 500); }
}
function resetFormGasto() {
    document.getElementById('form-gasto').reset();
    document.getElementById('gasto-edit-id').value = '';
    document.getElementById('gas-fecha').value = hoyISO();
    document.getElementById('form-gasto-titulo').textContent = 'Registrar gasto';
    document.getElementById('btn-gasto').innerHTML = '<i class="fa-solid fa-floppy-disk mr-1"></i> Registrar gasto';
}
function editarGasto(id) {
    const g = obtenerGastos().find(x => x.id === id); if (!g) return;
    const set = (k, v) => document.getElementById(k).value = v === undefined || v === null ? '' : v;
    set('gasto-edit-id', g.id); set('gas-fecha', g.fecha); set('gas-categoria', g.categoria); set('gas-monto', g.monto); set('gas-descripcion', g.descripcion); set('gas-proveedor', g.proveedor);
    document.getElementById('form-gasto-titulo').textContent = 'Editar gasto';
    document.getElementById('btn-gasto').innerHTML = '<i class="fa-solid fa-floppy-disk mr-1"></i> Guardar cambios';
    document.getElementById('form-gasto').scrollIntoView({ behavior: 'smooth', block: 'center' });
}
function renderizarGastos() {
    const cat = document.getElementById('filtro-gasto-cat').value;
    const r = rangoPeriodo(document.getElementById('filtro-gasto-periodo').value);
    const lista = obtenerGastos().filter(g => (!cat || g.categoria === cat) && enRango(g.fecha, r)).sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    document.getElementById('lbl-gastos-totales').textContent = formatoMoneda(lista.reduce((s, g) => s + num2(g.monto), 0));
    document.getElementById('tabla-gastos-body').innerHTML = lista.length ? lista.map(g => `
        <tr class="hover:bg-gray-50">
            <td class="p-3 text-xs font-semibold whitespace-nowrap">${fechaCorta(g.fecha)}</td>
            <td class="p-3"><span class="bg-brand-blue/20 text-brand-textDark px-2 py-1 rounded text-xs font-semibold whitespace-nowrap">${esc(g.categoria)}</span></td>
            <td class="p-3">${esc(g.descripcion)}${g.proveedor ? `<p class="text-xs text-gray-400">${esc(g.proveedor)}</p>` : ''}</td>
            <td class="p-3 font-bold text-red-500 text-right whitespace-nowrap">−${formatoMoneda(g.monto)}</td>
            <td class="p-3 text-center whitespace-nowrap">
                <button onclick="editarGasto(${g.id})" class="icon-btn text-gray-500" aria-label="Editar gasto"><i class="fa-solid fa-pen"></i></button>
                <button onclick="eliminarGasto(${g.id})" class="icon-btn text-gray-400 hover:text-red-500" aria-label="Eliminar gasto"><i class="fa-solid fa-trash-can"></i></button>
            </td>
        </tr>`).join('') : '<tr><td colspan="5" class="p-6 text-center text-gray-400">No hay gastos en este filtro.</td></tr>';
}
async function eliminarGasto(id) {
    const g = obtenerGastos().find(x => x.id === id); if (!g) return;
    if (!(await confirmar(`¿Eliminar el gasto "${g.descripcion}" por ${formatoMoneda(g.monto)}?`, 'Eliminar'))) return;
    guardarGastos(obtenerGastos().filter(x => x.id !== id)); renderizarGastos(); toast('Gasto eliminado');
}
function exportarGastosCSV() {
    const gs = obtenerGastos(); if (!gs.length) return toast('No hay gastos para exportar', 'error');
    exportarCSV(`gastos-${hoyISO()}.csv`, ['Fecha', 'Categoría', 'Descripción', 'Proveedor', 'Monto'], gs.map(g => [g.fecha, String(g.categoria).replace(/^\S+\s/, ''), g.descripcion, g.proveedor || '', num2(g.monto)]));
}

/* ---------------- Ventas ---------------- */
async function guardarVenta(ev) {
    ev.preventDefault();
    if (guardarVenta._ocupado) return; guardarVenta._ocupado = true;
    try {
        const v = id => document.getElementById(id).value.trim();
        const venta = { id: nuevoId(), v: 3, origen: 'manual', fecha: v('ven-fecha'), cliente: v('ven-cliente').slice(0, 80) || 'Mostrador', producto: v('ven-producto').slice(0, 120),
            cantidad: parseInt(v('ven-cantidad')) || 0, precio: num2(v('ven-precio')), pago: v('ven-pago'), observaciones: v('ven-obs').slice(0, 200) };
        if (!venta.fecha) return toast('Escribe la fecha de la venta.', 'error');
        if (!venta.producto) return toast('Escribe el producto.', 'error');
        if (!(venta.cantidad >= 1)) return toast('La cantidad debe ser 1 o más.', 'error');
        if (!(venta.precio > 0)) return toast('El total debe ser mayor a 0.', 'error');
        const ventas = obtenerVentas();
        const igual = ventas.find(x => !x.duplicada && x.fecha === venta.fecha && x.producto === venta.producto && num2(x.precio) === venta.precio && x.cliente === venta.cliente);
        if (igual && !(await confirmar('Ya existe una venta igual ese mismo día. ¿Registrar otra?', 'Registrar otra'))) return;
        ventas.unshift(venta);
        if (!guardarVentas(ventas)) return;
        toast('Venta registrada'); resetFormVenta(); renderizarVentas(); actualizarDashboard();
    } finally { setTimeout(() => guardarVenta._ocupado = false, 500); }
}
function resetFormVenta() {
    document.getElementById('form-venta').reset();
    document.getElementById('ven-fecha').value = hoyISO();
    document.getElementById('ven-cliente').value = 'Mostrador';
}
function renderizarVentas() {
    const r = rangoDe('fin');
    const pedidos = obtenerPedidos();
    const lista = obtenerVentas().filter(v => enRango(v.fecha, r)).sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
    document.getElementById('tabla-ventas-body').innerHTML = lista.length ? lista.map(v => {
        const p = v.pedidoId ? pedidos.find(x => x.id === v.pedidoId) : null;
        const origen = v.origen === 'pedido' ? `<button ${p ? `onclick="navegarA('pedidos'); abrirDetallePedido(${p.id})"` : ''} class="pill bg-brand-lilac/30 text-brand-purple">${p ? esc(p.folio) : 'Pedido'}</button>` : `<span class="pill bg-brand-cyan/30 text-brand-textDark">Mostrador${v.pago ? ' · ' + esc(String(v.pago).replace(/^[^\p{L}]+/u, '')) : ''}</span>`;
        return `<tr class="hover:bg-gray-50 ${v.duplicada ? 'opacity-60' : ''}">
            <td class="p-3 text-xs whitespace-nowrap">${fechaCorta(v.fecha)}</td>
            <td class="p-3 font-semibold text-brand-textDark">${esc(v.cliente)}</td>
            <td class="p-3">${esc(v.producto)} <span class="text-gray-400">(${esc(v.cantidad)} pz)</span></td>
            <td class="p-3 font-bold text-right whitespace-nowrap ${v.duplicada ? 'line-through text-gray-400' : 'text-green-600'}">${formatoMoneda(v.precio)}</td>
            <td class="p-3">${origen}${v.duplicada ? ' <span class="pill bg-red-100 text-red-700">Duplicada · no cuenta</span>' : ''}</td>
            <td class="p-3 text-center"><button onclick="eliminarVenta(${v.id})" class="icon-btn text-gray-400 hover:text-red-500" aria-label="Eliminar venta"><i class="fa-solid fa-trash-can"></i></button></td>
        </tr>`;
    }).join('') : '<tr><td colspan="6" class="p-6 text-center text-gray-400">No hay ventas en este periodo.</td></tr>';
}
async function eliminarVenta(id) {
    const ventas = obtenerVentas(); const v = ventas.find(x => x.id === id); if (!v) return;
    const msg = v.origen === 'pedido' && !v.duplicada
        ? `Esta venta viene de un pedido entregado. Si la eliminas, el pedido seguirá como entregado pero no contará en ventas. ¿Eliminarla?`
        : `¿Eliminar la venta de ${formatoMoneda(v.precio)} (${v.producto})?`;
    if (!(await confirmar(msg, 'Eliminar'))) return;
    guardarVentas(ventas.filter(x => x.id !== id));
    if (v.pedidoId && !v.duplicada) {
        const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === v.pedidoId);
        if (p) { p.ventaId = null; p.historial.push({ fecha: new Date().toISOString(), texto: 'Se eliminó su venta desde Ventas.' }); guardarPedidos(pedidos); }
    }
    renderizarVentas(); actualizarDashboard(); toast('Venta eliminada');
}
function registrarVentasFaltantes() {
    const pedidos = obtenerPedidos(), ventas = obtenerVentas();
    let n = 0;
    pedidos.filter(p => p.estado === 'entregado' && !ventas.some(v => v.pedidoId === p.id && !v.duplicada)).forEach(p => {
        const v = { id: nuevoId(), v: 3, origen: 'pedido', pedidoId: p.id, fecha: p.fechaEntregado || p.entrega || hoyISO(), cliente: p.cliente, producto: p.producto, cantidad: p.cantidad, precio: num2(p.precio), pago: (p.pagos.slice(-1)[0] || {}).metodo || '', observaciones: `Pedido ${p.folio}` };
        ventas.unshift(v); p.ventaId = v.id; p.historial.push({ fecha: new Date().toISOString(), texto: `Venta registrada con fecha ${v.fecha}.` }); n++;
    });
    if (guardarVentas(ventas) && guardarPedidos(pedidos)) toast(`${n} venta(s) registrada(s)`);
    renderizarVentas(); actualizarDashboard();
}

/* ---------------- Resumen y cobranza ---------------- */
function tarjetaKPI(titulo, valor, sub, icono, tono, accion) {
    const tonos = { rosa: ['#FFF0F5', '#E3679C'], morado: ['#FFF0F5', '#C9457F'], amarillo: ['#FFF6E3', '#E39A2B'], coral: ['#FFEEE8', '#E8603C'], azul: ['#EAF7F6', '#1F9A9C'],
        cian: ['#EAF7F6', '#1F9A9C'], verde: ['#EEF8EF', '#3E9E58'], rojo: ['#FFECEC', '#D64545'], gris: ['#F7F2F4', '#8A7A84'] };
    const [fondo, color] = tonos[tono] || tonos.rosa;
    return `<div ${accion ? `onclick="${accion}" onkeydown="if(event.key==='Enter'){${accion}}" role="button" tabindex="0"` : ''} class="relative overflow-hidden rounded-[1.4rem] p-4 border ${accion ? 'cursor-pointer hover:-translate-y-0.5 hover:shadow-md transition' : ''}" style="background:${fondo}; border-color:${color}22">
        <svg class="deco w-14 -right-4 -bottom-4 opacity-[.13]" viewBox="0 0 100 100" aria-hidden="true" style="color:${color}; --centro:${color}"><use href="#flor"/></svg>
        <div class="flex items-center justify-between gap-2 mb-2"><p class="text-xs font-semibold text-[#5E4B57]">${titulo}</p><span class="w-8 h-8 shrink-0 rounded-full flex items-center justify-center text-white shadow-sm" style="background:${color}"><i class="fa-solid ${icono} text-xs"></i></span></div>
        <p class="font-display text-2xl md:text-[1.7rem] font-bold text-brand-textDark tabular leading-tight">${valor}</p>
        ${sub ? `<p class="text-[11px] text-[#7A6872] mt-0.5 leading-snug">${esc(sub)}</p>` : ''}</div>`;
}
function actualizarDashboard() {
    const r = rangoDe('fin');
    const pedidos = obtenerPedidos(), ventas = obtenerVentas(), gastos = obtenerGastos();
    const res = resumenFinanciero(r, pedidos, ventas, gastos);
    const deudores = pedidos.filter(p => saldoPedido(p) > 0);
    document.getElementById('fin-kpis').innerHTML =
        tarjetaKPI('Ventas', formatoMoneda(res.ventas), `${res.numVentas} venta(s)`, 'fa-bag-shopping', 'morado') +
        tarjetaKPI('Cobrado', formatoMoneda(res.cobrado), 'Dinero que entró', 'fa-money-bill-wave', 'verde') +
        tarjetaKPI('Por cobrar', formatoMoneda(res.porCobrar), `${deudores.length} pedido(s) con saldo`, 'fa-hand-holding-dollar', 'rojo') +
        tarjetaKPI('Gastos', formatoMoneda(res.gastos), '', 'fa-wallet', 'rosa') +
        tarjetaKPI('Utilidad estimada', formatoMoneda(res.utilidad), `Flujo de caja ${formatoMoneda(res.flujo)}`, 'fa-chart-line', res.utilidad < 0 ? 'rojo' : 'cian');

    const sinVenta = pedidos.filter(p => p.estado === 'entregado' && !ventas.some(v => v.pedidoId === p.id && !v.duplicada));
    const dup = ventas.filter(v => v.duplicada);
    document.getElementById('fin-alertas').innerHTML =
        (sinVenta.length ? `<div class="flex flex-wrap items-center gap-3 bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-xl px-4 py-3 text-sm"><i class="fa-solid fa-triangle-exclamation"></i><span class="flex-1">${sinVenta.length} pedido(s) entregado(s) no tienen venta registrada (${sinVenta.map(p => esc(p.folio)).join(', ')}).</span><button onclick="registrarVentasFaltantes()" class="btn-mini bg-yellow-600 text-white">Registrarlas</button></div>` : '') +
        (dup.length ? `<div class="flex items-center gap-3 bg-blue-50 border border-blue-200 text-blue-800 rounded-xl px-4 py-3 text-sm"><i class="fa-solid fa-circle-info"></i><span>${dup.length} venta(s) estaban registradas dos veces desde el mismo pedido. Se marcaron como duplicadas y ya no suman; puedes eliminarlas.</span></div>` : '');

    document.getElementById('lbl-por-cobrar').textContent = formatoMoneda(res.porCobrar);
    const hoy = hoyISO();
    document.getElementById('lista-por-cobrar').innerHTML = deudores.length ? deudores.sort((a, b) => String(a.entrega).localeCompare(String(b.entrega))).map(p => {
        const ei = entregaInfo(p, hoy);
        return `<div class="flex items-center gap-3 border border-gray-100 rounded-xl p-3">
            <div class="flex-1 min-w-0"><p class="font-semibold text-sm truncate"><button onclick="abrirDetallePedido(${p.id})" class="text-brand-purple hover:underline">${esc(p.folio)}</button> · ${esc(p.cliente)}</p>
                <p class="text-xs text-gray-500">${estadoInfo(p.estado).nombre} · entrega ${fechaCorta(p.entrega)} ${ei && ei.tipo === 'atrasado' ? `<span class="pill ${ei.clase}">${ei.texto}</span>` : ''}</p></div>
            <div class="text-right tabular"><p class="font-bold text-red-600">${formatoMoneda(saldoPedido(p))}</p><p class="text-[11px] text-gray-400">de ${formatoMoneda(totalPedido(p))}</p></div>
            <button onclick="abrirModalPago(${p.id})" class="btn-mini bg-green-50 text-green-700" aria-label="Registrar pago de ${esc(p.folio)}"><i class="fa-solid fa-plus"></i></button>
        </div>`;
    }).join('') : '<p class="text-sm text-gray-500 text-center py-6"><i class="fa-solid fa-circle-check text-green-500 mr-1"></i>Nadie te debe. ¡Todo cobrado!</p>';
}
function exportarVentasCSV() {
    const pedidos = obtenerPedidos();
    const vs = obtenerVentas(); if (!vs.length) return toast('No hay ventas para exportar', 'error');
    exportarCSV(`ventas-${hoyISO()}.csv`, ['Fecha', 'Cliente', 'Producto', 'Cantidad', 'Total', 'Origen', 'Pedido', 'Forma de pago', 'Cuenta', 'Observaciones'],
        vs.map(v => [v.fecha, v.cliente, v.producto, v.cantidad, num2(v.precio), v.origen === 'pedido' ? 'Pedido' : 'Mostrador', ((pedidos.find(p => p.id === v.pedidoId) || {}).folio) || '', String(v.pago || '').replace(/^[^\p{L}]+/u, ''), v.duplicada ? 'No (duplicada)' : 'Sí', v.observaciones || '']));
}
function exportarPagosCSV() {
    const filas = [];
    obtenerPedidos().forEach(p => (p.pagos || []).forEach(x => filas.push([x.fecha, p.folio, p.cliente, num2(x.monto), x.metodo, x.nota || ''])));
    obtenerVentas().filter(v => v.origen !== 'pedido' && !v.duplicada).forEach(v => filas.push([v.fecha, 'Mostrador', v.cliente, num2(v.precio), String(v.pago || '').replace(/^[^\p{L}]+/u, ''), v.producto]));
    if (!filas.length) return toast('No hay pagos para exportar', 'error');
    filas.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    exportarCSV(`cobros-${hoyISO()}.csv`, ['Fecha', 'Pedido', 'Cliente', 'Monto', 'Método', 'Nota'], filas);
}
