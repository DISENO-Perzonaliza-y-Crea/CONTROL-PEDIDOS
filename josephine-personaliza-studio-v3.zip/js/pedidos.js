/* =====================================================================
   Personaliza Studio — Pedidos, pagos, archivos e historial
   ===================================================================== */

let formPedidoExtra = null;   // partidas y cotización de origen cuando el pedido viene del cotizador
let filtroEstadoPedidos = 'activos';
let pagoAlEntregar = false;

/* ---------------- Formulario ---------------- */
function abrirFormPedido() {
    const card = document.getElementById('form-pedido-card');
    document.getElementById('form-pedido').reset();
    document.getElementById('pedido-edit-id').value = '';
    formPedidoExtra = null;
    document.getElementById('ped-origen').classList.add('hidden');
    document.getElementById('form-pedido-titulo').textContent = 'Nuevo pedido';
    document.getElementById('bloque-anticipo').classList.remove('hidden');
    document.getElementById('ped-fecha').value = hoyISO();
    document.getElementById('ped-entrega').value = sumarDiasISO(hoyISO(), 3);
    document.getElementById('ped-estado').value = 'pendiente';
    document.getElementById('ped-anticipo').value = 0;
    document.getElementById('ped-anticipo').placeholder = '';
    document.getElementById('ped-error').classList.add('hidden');
    card.classList.remove('hidden');
    card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => document.getElementById('ped-cliente').focus(), 300);
}
function cerrarFormPedido() {
    document.getElementById('form-pedido-card').classList.add('hidden');
    document.getElementById('pedido-edit-id').value = '';
    formPedidoExtra = null;
}

// Desde el cotizador
async function nuevoPedidoDesdeCotizacion(cot, R) {
    const existente = obtenerPedidos().find(p => p.cotizacionId === cot.id && p.estado !== 'cancelado');
    if (existente) {
        const otro = await confirmar(`Ya existe el pedido ${existente.folio} para la cotización ${cot.folio}. ¿Quieres crear otro pedido de todos modos?`, 'Crear otro');
        if (!otro) { navegarA('pedidos'); abrirDetallePedido(existente.id); return; }
    }
    navegarA('pedidos');
    abrirFormPedido();
    const validas = R.partidas.map((r, i) => ({ r, it: cot.items[i] })).filter(x => x.r && !x.r.error && !x.r.sinCosto);
    formPedidoExtra = {
        cotizacionId: cot.id, cotizacionFolio: cot.folio,
        partidas: validas.map(({ r, it }) => ({ nombre: r.nombre, detalle: r.detalle, cantidad: r.cantidad, total: r.total, personalizacion: it.personalizacion || '' }))
            .concat(R.disenoPrecio ? [{ nombre: 'Diseño y preparación', detalle: '', cantidad: 1, total: R.disenoPrecio, personalizacion: '' }] : [])
    };
    const set = (id, v) => document.getElementById(id).value = v;
    set('ped-cliente', cot.cliente.nombre); set('ped-telefono', cot.cliente.telefono);
    set('ped-producto', resumenPartidas(R).slice(0, 200));
    set('ped-cantidad', R.piezas || 1);
    set('ped-detalles', validas.map(x => x.r.detalle).join(' · ').slice(0, 200));
    set('ped-precio', R.total.toFixed(2));
    set('ped-descripcion', validas.map(({ r, it }, i) => `${i + 1}. ${r.cantidad} ${r.nombre} (${r.detalle})${it.personalizacion ? ': ' + it.personalizacion : ''}`).join('\n').slice(0, 1500));
    document.getElementById('ped-anticipo').placeholder = `Acordado: ${R.anticipo.toFixed(2)}`;
    const o = document.getElementById('ped-origen');
    o.textContent = `De la cotización ${cot.folio} · anticipo acordado ${formatoMoneda(R.anticipo)}`;
    o.classList.remove('hidden');
    toast('Escribe el anticipo cuando lo recibas y guarda el pedido');
}

function errorPedido(msg) { const e = document.getElementById('ped-error'); e.textContent = msg; e.classList.remove('hidden'); toast(msg, 'error'); return false; }

async function guardarPedido(ev) {
    ev.preventDefault();
    if (guardarPedido._ocupado) return;
    guardarPedido._ocupado = true;
    try { await _guardarPedido(); } finally { setTimeout(() => guardarPedido._ocupado = false, 500); }
}
async function _guardarPedido() {
    const v = id => document.getElementById(id).value.trim();
    const editId = v('pedido-edit-id');
    const datos = {
        cliente: v('ped-cliente').slice(0, 80), telefono: v('ped-telefono').slice(0, 20), producto: v('ped-producto').slice(0, 200),
        cantidad: parseInt(v('ped-cantidad')), detalles: v('ped-detalles').slice(0, 200), fecha: v('ped-fecha'), entrega: v('ped-entrega'),
        prioridad: v('ped-prioridad'), precio: num2(v('ped-precio')), descripcion: v('ped-descripcion').slice(0, 1500), notasInternas: v('ped-notas').slice(0, 1500)
    };
    const estadoNuevo = v('ped-estado');
    if (!datos.cliente) return errorPedido('Escribe el nombre del cliente.');
    if (!datos.producto) return errorPedido('Escribe el producto.');
    if (!(datos.cantidad >= 1)) return errorPedido('La cantidad debe ser 1 o más.');
    if (!datos.fecha || !datos.entrega) return errorPedido('Completa las fechas del pedido y de entrega.');
    if (datos.entrega < datos.fecha) return errorPedido('La fecha de entrega no puede ser antes de la fecha del pedido.');
    if (!(datos.precio >= 0) || v('ped-precio') === '') return errorPedido('Escribe el total del pedido.');
    const tel = datos.telefono.replace(/\D/g, '');
    if (datos.telefono && tel.length < 10) return errorPedido('El teléfono debe tener al menos 10 dígitos.');
    document.getElementById('ped-error').classList.add('hidden');

    const pedidos = obtenerPedidos();
    const ventas = obtenerVentas();
    const ahora = new Date().toISOString();
    let p;
    if (editId) {
        p = pedidos.find(x => String(x.id) === editId);
        if (!p) return errorPedido('No se encontró el pedido.');
        if (datos.precio + 0.005 < pagadoPedido(p) && !(await confirmar(`El nuevo total (${formatoMoneda(datos.precio)}) es menor a lo que ya pagó el cliente (${formatoMoneda(pagadoPedido(p))}). ¿Guardar de todos modos?`))) return;
        const etiquetas = { cliente: 'Cliente', telefono: 'Teléfono', producto: 'Producto', cantidad: 'Cantidad', detalles: 'Medidas', fecha: 'Fecha', entrega: 'Entrega', prioridad: 'Prioridad', precio: 'Total', descripcion: 'Descripción', notasInternas: 'Notas internas' };
        const cambios = Object.keys(etiquetas).filter(k => String(p[k] ?? '') !== String(datos[k] ?? '')).map(k =>
            ['descripcion', 'notasInternas'].includes(k) ? `${etiquetas[k]} actualizada` : `${etiquetas[k]}: ${k === 'precio' ? formatoMoneda(p[k]) : (p[k] || '—')} → ${k === 'precio' ? formatoMoneda(datos[k]) : (datos[k] || '—')}`);
        Object.assign(p, datos);
        if (cambios.length) p.historial.push({ fecha: ahora, texto: 'Editado: ' + cambios.join('; ') });
    } else {
        const anticipo = num2(v('ped-anticipo'));
        if (anticipo < 0) return errorPedido('El anticipo no puede ser negativo.');
        if (anticipo > datos.precio + 0.005) return errorPedido('El anticipo no puede ser mayor al total.');
        const parecido = pedidos.find(x => x.cliente.toLowerCase() === datos.cliente.toLowerCase() && x.producto === datos.producto && x.fecha === datos.fecha && num2(x.precio) === datos.precio);
        if (parecido && !(await confirmar(`Ya existe un pedido igual (${parecido.folio}) de ${parecido.cliente} con la misma fecha y total. ¿Registrar otro?`, 'Registrar otro'))) return;
        p = {
            id: nuevoId(), folio: siguienteFolioPedido(pedidos), v: 3, ...datos, estado: 'pendiente', pagos: [], archivos: [], historial: [],
            partidas: formPedidoExtra ? formPedidoExtra.partidas : null, cotizacionId: formPedidoExtra ? formPedidoExtra.cotizacionId : null,
            cotizacionFolio: formPedidoExtra ? formPedidoExtra.cotizacionFolio : null, creado: ahora
        };
        p.historial.push({ fecha: ahora, texto: `Pedido creado${p.cotizacionFolio ? ' desde la cotización ' + p.cotizacionFolio : ''} por ${formatoMoneda(p.precio)}.` });
        if (anticipo > 0) {
            p.pagos.push({ id: nuevoId(), fecha: datos.fecha, monto: anticipo, metodo: v('ped-anticipo-metodo'), nota: 'Anticipo' });
            p.historial.push({ fecha: ahora, texto: `Anticipo de ${formatoMoneda(anticipo)} (${v('ped-anticipo-metodo')}).` });
        }
        pedidos.unshift(p);
    }
    const pideSaldo = aplicarCambioEstado(p, estadoNuevo, ventas);
    p.actualizado = ahora;
    if (!guardarPedidos(pedidos) || !guardarVentas(ventas)) return;
    cerrarFormPedido();
    renderizarPedidos();
    toast(editId ? `Pedido ${p.folio} actualizado` : `Pedido ${p.folio} creado`);
    if (pideSaldo) abrirModalPago(p.id, true);
}

/* Cambia el estado y mantiene la venta ligada al pedido (sin duplicar).
   Regresa true si el pedido se entregó con saldo pendiente. */
function aplicarCambioEstado(p, nuevo, ventas) {
    const antes = p.estado;
    if (!nuevo || antes === nuevo) return false;
    const ahora = new Date().toISOString();
    p.estado = nuevo;
    p.historial.push({ fecha: ahora, texto: `Estado: ${estadoInfo(antes).nombre} → ${estadoInfo(nuevo).nombre}` });
    if (nuevo === 'entregado') {
        p.fechaEntregado = hoyISO();
        let venta = ventas.find(v => v.pedidoId === p.id && !v.duplicada);
        if (!venta) {
            venta = { id: nuevoId(), v: 3, origen: 'pedido', pedidoId: p.id, fecha: hoyISO(), cliente: p.cliente, producto: p.producto, cantidad: p.cantidad, precio: num2(p.precio), pago: (p.pagos.slice(-1)[0] || {}).metodo || '', observaciones: `Pedido ${p.folio}` };
            ventas.unshift(venta);
            p.historial.push({ fecha: ahora, texto: `Venta registrada por ${formatoMoneda(venta.precio)}.` });
        }
        p.ventaId = venta.id;
        return saldoPedido(p) > 0;
    }
    if (antes === 'entregado') {
        const i = ventas.findIndex(v => v.pedidoId === p.id && v.origen === 'pedido' && !v.duplicada);
        if (i >= 0) { ventas.splice(i, 1); p.historial.push({ fecha: ahora, texto: 'Se quitó la venta porque el pedido ya no está entregado.' }); }
        p.ventaId = null; p.fechaEntregado = null;
    }
    if (nuevo === 'cancelado' && pagadoPedido(p) > 0) p.historial.push({ fecha: ahora, texto: `Cancelado con ${formatoMoneda(pagadoPedido(p))} pagados. Si devuelves dinero, regístralo en Gastos.` });
    return false;
}
function cambiarEstadoPedido(id, nuevo) {
    const pedidos = obtenerPedidos(), ventas = obtenerVentas();
    const p = pedidos.find(x => x.id === id);
    if (!p) return;
    const pide = aplicarCambioEstado(p, nuevo, ventas);
    p.actualizado = new Date().toISOString();
    if (!guardarPedidos(pedidos) || !guardarVentas(ventas)) return;
    toast(`${p.folio}: ${estadoInfo(nuevo).nombre}`);
    renderizarPedidos();
    if (!document.getElementById('modal-pedido').classList.contains('hidden')) abrirDetallePedido(id);
    if (pide) abrirModalPago(id, true);
}

function editarPedido(id) {
    const p = obtenerPedidos().find(x => x.id === id);
    if (!p) return;
    cerrarDetallePedido();
    navegarA('pedidos');
    abrirFormPedido();
    document.getElementById('form-pedido-titulo').textContent = `Editar ${p.folio}`;
    document.getElementById('bloque-anticipo').classList.add('hidden');
    const set = (k, v) => document.getElementById(k).value = v === undefined || v === null ? '' : v;
    set('pedido-edit-id', p.id); set('ped-cliente', p.cliente); set('ped-telefono', p.telefono); set('ped-producto', p.producto); set('ped-cantidad', p.cantidad);
    set('ped-detalles', p.detalles); set('ped-fecha', p.fecha); set('ped-entrega', p.entrega); set('ped-prioridad', p.prioridad || 'normal'); set('ped-estado', p.estado);
    set('ped-precio', p.precio); set('ped-descripcion', p.descripcion); set('ped-notas', p.notasInternas);
}

async function eliminarPedido(id) {
    const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === id);
    if (!p) return;
    const venta = obtenerVentas().find(v => v.pedidoId === id && v.origen === 'pedido');
    if (!(await confirmar(`¿Eliminar el pedido ${p.folio} de ${p.cliente}?${venta ? ' También se quitará su venta registrada.' : ''}${pagadoPedido(p) ? ` Sus pagos (${formatoMoneda(pagadoPedido(p))}) dejarán de contar.` : ''} No se puede deshacer.`, 'Eliminar'))) return;
    guardarPedidos(pedidos.filter(x => x.id !== id));
    if (venta) guardarVentas(obtenerVentas().filter(v => v.id !== venta.id));
    for (const a of (p.archivos || [])) { try { await borrarArchivoIDB(a.id); } catch (e) {} }
    cerrarDetallePedido();
    renderizarPedidos();
    toast(`Pedido ${p.folio} eliminado`);
}

/* ---------------- Lista ---------------- */
function renderizarPedidos() {
    const pedidos = obtenerPedidos();
    const hoy = hoyISO();
    const conteo = { activos: 0, atrasados: 0, todos: pedidos.length };
    ESTADOS.forEach(e => conteo[e.id] = 0);
    pedidos.forEach(p => {
        conteo[p.estado] = (conteo[p.estado] || 0) + 1;
        if (ESTADOS_ACTIVOS.includes(p.estado)) conteo.activos++;
        const ei = entregaInfo(p, hoy); if (ei && ei.tipo === 'atrasado') conteo.atrasados++;
    });
    const chips = [['activos', 'Activos'], ['atrasados', 'Atrasados'], ...ESTADOS.map(e => [e.id, e.nombre]), ['todos', 'Todos']];
    document.getElementById('filtro-estados').innerHTML = chips.map(([id, n]) =>
        `<button onclick="filtroEstadoPedidos='${id}'; renderizarPedidos()" class="whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-semibold border transition ${filtroEstadoPedidos === id ? 'bg-brand-purple text-white border-brand-purple' : 'bg-white text-brand-purple border-brand-lilac hover:bg-brand-lilac/20'} ${id === 'atrasados' && conteo.atrasados ? 'ring-1 ring-red-300' : ''}">${n} <span class="opacity-70">${conteo[id] || 0}</span></button>`).join('');

    const q = document.getElementById('filtro-pedido').value.toLowerCase().trim();
    const pri = document.getElementById('filtro-prioridad').value;
    let lista = pedidos.filter(p => {
        if (filtroEstadoPedidos === 'activos' && !ESTADOS_ACTIVOS.includes(p.estado)) return false;
        if (filtroEstadoPedidos === 'atrasados' && !((entregaInfo(p, hoy) || {}).tipo === 'atrasado')) return false;
        if (!['activos', 'atrasados', 'todos'].includes(filtroEstadoPedidos) && p.estado !== filtroEstadoPedidos) return false;
        if (pri && (p.prioridad || 'normal') !== pri) return false;
        return !q || `${p.folio} ${p.cliente} ${p.producto} ${p.telefono}`.toLowerCase().includes(q);
    });
    const orden = document.getElementById('orden-pedidos').value;
    const peso = { urgente: 0, alta: 1, normal: 2 };
    if (orden === 'entrega') lista.sort((a, b) => (a.entrega || '9').localeCompare(b.entrega || '9') || (peso[a.prioridad || 'normal'] - peso[b.prioridad || 'normal']));
    if (orden === 'recientes') lista.sort((a, b) => (b.id || 0) - (a.id || 0));
    if (orden === 'saldo') lista.sort((a, b) => saldoPedido(b) - saldoPedido(a));

    const cont = document.getElementById('lista-pedidos');
    if (!lista.length) {
        cont.innerHTML = `<div class="bg-white rounded-2xl border-2 border-dashed border-brand-lilac/50 text-center text-gray-500 py-10 px-4">
            <i class="fa-solid fa-clipboard-list text-3xl text-brand-lilac mb-2"></i>
            <p>${pedidos.length ? 'Ningún pedido coincide con el filtro.' : 'Aún no hay pedidos. Crea uno con <b>Nuevo pedido</b> o desde una cotización.'}</p></div>`;
        return;
    }
    cont.innerHTML = lista.map(p => {
        const est = estadoInfo(p.estado), ei = entregaInfo(p, hoy), ep = estadoPago(p), pr = PRIORIDADES[p.prioridad || 'normal'];
        const total = totalPedido(p), pagado = pagadoPedido(p), pct = total > 0 ? Math.min(100, pagado / total * 100) : 0;
        return `<article class="bg-white rounded-2xl shadow-sm hover:shadow-md transition border ${ei && ei.tipo === 'atrasado' ? 'border-red-200' : 'border-gray-100'} p-4">
            <div class="flex flex-wrap gap-3 items-start">
                <div class="flex-1 min-w-[200px]">
                    <div class="flex flex-wrap items-center gap-1.5 mb-1">
                        <button onclick="abrirDetallePedido(${p.id})" class="font-bold text-brand-purple hover:underline">${esc(p.folio)}</button>
                        <span class="pill ${est.clase}"><i class="fa-solid ${est.icono} mr-0.5"></i>${est.nombre}</span>
                        ${p.prioridad && p.prioridad !== 'normal' ? `<span class="pill ${pr.clase}">${pr.nombre}</span>` : ''}
                        ${ei ? `<span class="pill ${ei.clase}">${ei.texto}</span>` : ''}
                        ${(p.archivos || []).length ? `<span class="pill bg-gray-100 text-gray-600"><i class="fa-solid fa-paperclip mr-0.5"></i>${p.archivos.length}</span>` : ''}
                    </div>
                    <p class="font-semibold text-brand-textDark">${esc(p.cliente)} <span class="font-normal text-xs text-gray-400">${esc(p.telefono || '')}</span></p>
                    <p class="text-sm text-gray-600">${esc(p.producto)} <span class="text-gray-400">· ${p.cantidad} pzs</span></p>
                    <p class="text-xs text-gray-400 mt-0.5">Pedido ${fechaCorta(p.fecha)} · Entrega <b class="text-gray-600">${fechaCorta(p.entrega)}</b></p>
                </div>
                <div class="w-full sm:w-56 tabular">
                    <div class="flex justify-between text-xs text-gray-500"><span>Pagado ${formatoMoneda(pagado)}</span><span class="pill ${ep.clase}">${ep.nombre}</span></div>
                    <div class="h-2 bg-gray-100 rounded-full overflow-hidden my-1.5" role="progressbar" aria-valuenow="${Math.round(pct)}" aria-valuemin="0" aria-valuemax="100" aria-label="Porcentaje pagado"><div class="h-full bg-brand-purple rounded-full" style="width:${pct}%"></div></div>
                    <div class="flex justify-between text-sm"><span class="text-gray-500">Total ${formatoMoneda(total)}</span><b class="${saldoPedido(p) > 0 ? 'text-red-600' : 'text-green-700'}">Saldo ${formatoMoneda(saldoPedido(p))}</b></div>
                </div>
            </div>
            <div class="flex flex-wrap gap-2 mt-3 pt-3 border-t border-gray-100 items-center">
                <select onchange="cambiarEstadoPedido(${p.id}, this.value)" class="campo w-auto py-1.5 text-xs" aria-label="Cambiar estado de ${esc(p.folio)}">${ESTADOS.map(e => `<option value="${e.id}" ${e.id === p.estado ? 'selected' : ''}>${e.nombre}</option>`).join('')}</select>
                ${saldoPedido(p) > 0 ? `<button onclick="abrirModalPago(${p.id})" class="btn-mini bg-green-50 text-green-700"><i class="fa-solid fa-hand-holding-dollar mr-1"></i>Abono</button>` : ''}
                <button onclick="abrirDetallePedido(${p.id})" class="btn-mini bg-brand-lilac/20 text-brand-purple"><i class="fa-regular fa-eye mr-1"></i>Detalle</button>
                <button onclick="editarPedido(${p.id})" class="btn-mini bg-gray-100 text-gray-700"><i class="fa-solid fa-pen mr-1"></i>Editar</button>
                <button onclick="eliminarPedido(${p.id})" class="btn-mini bg-gray-100 text-red-600 ml-auto" aria-label="Eliminar ${esc(p.folio)}"><i class="fa-solid fa-trash-can"></i></button>
            </div>
        </article>`;
    }).join('');
}

/* ---------------- Detalle ---------------- */
async function abrirDetallePedido(id) {
    const p = obtenerPedidos().find(x => x.id === id);
    if (!p) return;
    const est = estadoInfo(p.estado), ep = estadoPago(p), ei = entregaInfo(p), pr = PRIORIDADES[p.prioridad || 'normal'];
    const idxEst = ESTADOS.findIndex(e => e.id === p.estado);
    const tel = telefonoWhatsApp(p.telefono);
    const msgWA = `Hola ${p.cliente.split(' ')[0]}, te escribo de ${obtenerNegocio().nombre}. Tu pedido ${p.folio} está en: ${est.nombre}.${saldoPedido(p) > 0 ? ` Saldo pendiente: ${formatoMoneda(saldoPedido(p))}.` : ''}`;
    const pasos = ESTADOS.filter(e => e.id !== 'cancelado');
    document.getElementById('modal-pedido-contenido').innerHTML = `
        <div class="bg-gradient-to-r from-brand-pink/30 via-brand-lilac/25 to-brand-cyan/30 px-5 py-4 rounded-t-2xl flex justify-between gap-3">
            <div>
                <p class="text-[11px] font-bold tracking-[0.2em] text-brand-purple uppercase">Pedido</p>
                <h3 id="mp-folio" class="text-xl font-bold text-brand-textDark">${esc(p.folio)} · ${esc(p.cliente)}</h3>
                <div class="flex flex-wrap gap-1.5 mt-1"><span class="pill ${est.clase}">${est.nombre}</span><span class="pill ${pr.clase}">Prioridad ${pr.nombre.toLowerCase()}</span><span class="pill ${ep.clase}">${ep.nombre}</span>${ei ? `<span class="pill ${ei.clase}">${ei.texto}</span>` : ''}</div>
            </div>
            <button onclick="cerrarDetallePedido()" class="w-9 h-9 shrink-0 rounded-full bg-white/70 hover:bg-white text-gray-600" aria-label="Cerrar"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="p-5 space-y-6">
            <div>
                <p class="lbl">Avance</p>
                <ol class="grid grid-cols-3 sm:grid-cols-6 gap-1.5">${pasos.map((e, i) => {
                    const hecho = p.estado !== 'cancelado' && i <= idxEst;
                    return `<li><button onclick="cambiarEstadoPedido(${p.id}, '${e.id}')" class="w-full text-[11px] font-semibold rounded-lg px-1 py-2 border transition ${e.id === p.estado ? 'bg-brand-purple text-white border-brand-purple' : hecho ? 'bg-brand-lilac/25 text-brand-purple border-brand-lilac/40' : 'bg-white text-gray-500 border-gray-200 hover:border-brand-lilac'}"><i class="fa-solid ${e.icono} block mb-0.5"></i>${e.nombre}</button></li>`;
                }).join('')}</ol>
                ${p.estado !== 'cancelado' ? `<button onclick="cambiarEstadoPedido(${p.id}, 'cancelado')" class="text-xs text-gray-400 hover:text-red-600 mt-2">Marcar como cancelado</button>` : `<p class="text-xs text-red-600 mt-2 font-semibold">Pedido cancelado. Toca un estado para reactivarlo.</p>`}
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div><p class="text-xs text-gray-500">Teléfono</p><p class="font-semibold">${esc(p.telefono || '—')}</p></div>
                <div><p class="text-xs text-gray-500">Fecha del pedido</p><p class="font-semibold">${fechaLarga(p.fecha)}</p></div>
                <div><p class="text-xs text-gray-500">Entrega</p><p class="font-semibold">${fechaLarga(p.entrega)}</p></div>
                <div><p class="text-xs text-gray-500">${p.fechaEntregado ? 'Entregado' : 'Cantidad'}</p><p class="font-semibold">${p.fechaEntregado ? fechaLarga(p.fechaEntregado) : p.cantidad + ' pzs'}</p></div>
                <div class="col-span-2 md:col-span-4"><p class="text-xs text-gray-500">Producto</p><p class="font-semibold">${esc(p.producto)}</p>${p.detalles ? `<p class="text-xs text-gray-500">${esc(p.detalles)}</p>` : ''}</div>
            </div>

            ${Array.isArray(p.partidas) && p.partidas.length ? `<div><p class="lbl">Productos ${p.cotizacionFolio ? `<span class="font-normal text-gray-400">· de la cotización ${esc(p.cotizacionFolio)}</span>` : ''}</p>
                <div class="rounded-xl border border-gray-100 divide-y divide-gray-100 text-sm">${p.partidas.map(x => `<div class="flex justify-between gap-3 px-3 py-2"><div><p class="font-semibold">${x.cantidad} × ${esc(x.nombre)}</p><p class="text-xs text-gray-500">${esc(x.detalle)}${x.personalizacion ? ' · ' + esc(x.personalizacion) : ''}</p></div><p class="font-semibold tabular">${formatoMoneda(x.total)}</p></div>`).join('')}</div></div>` : ''}

            ${p.descripcion ? `<div><p class="lbl">Descripción / personalización</p><p class="text-sm whitespace-pre-line bg-gray-50 rounded-xl p-3">${esc(p.descripcion)}</p></div>` : ''}

            <div>
                <div class="flex justify-between items-center mb-2"><p class="lbl mb-0">Pagos</p>${saldoPedido(p) > 0 ? `<button onclick="abrirModalPago(${p.id})" class="btn-mini bg-green-50 text-green-700"><i class="fa-solid fa-plus mr-1"></i>Registrar abono</button>` : ''}</div>
                <div class="grid grid-cols-3 gap-2 text-center mb-2 tabular">
                    <div class="bg-brand-bg rounded-xl p-2"><p class="text-[11px] text-gray-500">Total</p><p class="font-bold">${formatoMoneda(totalPedido(p))}</p></div>
                    <div class="bg-green-50 rounded-xl p-2"><p class="text-[11px] text-gray-500">Pagado</p><p class="font-bold text-green-700">${formatoMoneda(pagadoPedido(p))}</p></div>
                    <div class="bg-red-50 rounded-xl p-2"><p class="text-[11px] text-gray-500">Saldo</p><p class="font-bold text-red-600">${formatoMoneda(saldoPedido(p))}</p></div>
                </div>
                ${(p.pagos || []).length ? `<div class="rounded-xl border border-gray-100 divide-y divide-gray-100 text-sm">${p.pagos.map(x => `<div class="flex items-center justify-between gap-2 px-3 py-2"><div><p class="font-semibold tabular">${formatoMoneda(x.monto)} <span class="font-normal text-gray-500">· ${esc(x.metodo)}</span></p><p class="text-xs text-gray-500">${fechaLarga(x.fecha)}${x.nota ? ' · ' + esc(x.nota) : ''}</p></div><button onclick="eliminarPago(${p.id}, ${x.id})" class="icon-btn text-gray-400 hover:text-red-500" aria-label="Eliminar pago"><i class="fa-solid fa-trash-can"></i></button></div>`).join('')}</div>` : '<p class="text-sm text-gray-500">Sin pagos registrados.</p>'}
            </div>

            <div>
                <p class="lbl">Fotos y archivos del diseño</p>
                <div id="archivos-pedido" class="grid grid-cols-3 sm:grid-cols-5 gap-2 mb-2"></div>
                <label class="inline-flex items-center gap-2 cursor-pointer btn-mini bg-brand-lilac/20 text-brand-purple"><i class="fa-solid fa-upload"></i> Subir archivos
                    <input type="file" multiple class="sr-only" onchange="subirArchivosPedido(${p.id}, this)"></label>
                <span class="text-xs text-gray-400 ml-2">Imágenes, PDF, AI, PSD… hasta 15 MB cada uno. Se guardan en este dispositivo.</span>
            </div>

            <div>
                <label for="mp-notas" class="lbl"><i class="fa-solid fa-lock mr-1 text-gray-400"></i>Notas internas</label>
                <textarea id="mp-notas" rows="2" class="campo" maxlength="1500">${esc(p.notasInternas || '')}</textarea>
                <button onclick="guardarNotasPedido(${p.id})" class="btn-mini bg-gray-100 text-gray-700 mt-2">Guardar notas</button>
            </div>

            <details class="rounded-xl border border-gray-200">
                <summary class="cursor-pointer px-4 py-3 text-sm font-semibold text-brand-purple">Historial de cambios (${(p.historial || []).length})</summary>
                <ol class="px-4 pb-4 space-y-2 text-xs">${(p.historial || []).slice().reverse().map(h => `<li class="flex gap-3"><span class="text-gray-400 whitespace-nowrap">${fechaHora(h.fecha)}</span><span class="text-gray-700">${esc(h.texto)}</span></li>`).join('')}</ol>
            </details>

            <div class="flex flex-wrap gap-2 pt-2 border-t border-gray-100">
                <a href="https://wa.me/${tel}?text=${encodeURIComponent(msgWA)}" target="_blank" rel="noopener" class="btn-acc bg-green-500 text-white px-4"><i class="fa-brands fa-whatsapp"></i> Avisar al cliente</a>
                ${p.cotizacionId && leerJSON(KEY_COTIZACIONES, []).some(c => c.id === p.cotizacionId) ? `<button onclick="cerrarDetallePedido(); abrirCotizacion('${p.cotizacionId}'); navegarA('cotizador')" class="btn-acc bg-white border border-brand-purple text-brand-purple px-4"><i class="fa-regular fa-file-lines"></i> Ver cotización</button>` : ''}
                <button onclick="editarPedido(${p.id})" class="btn-acc bg-gray-100 text-gray-700 px-4"><i class="fa-solid fa-pen"></i> Editar</button>
                <button onclick="eliminarPedido(${p.id})" class="btn-acc bg-white border border-red-200 text-red-600 px-4 ml-auto"><i class="fa-solid fa-trash-can"></i> Eliminar</button>
            </div>
        </div>`;
    document.getElementById('modal-pedido').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    renderizarArchivosPedido(p);
}
function cerrarDetallePedido() {
    document.getElementById('modal-pedido').classList.add('hidden');
    document.body.style.overflow = '';
    (cerrarDetallePedido._urls || []).forEach(u => URL.revokeObjectURL(u)); cerrarDetallePedido._urls = [];
}
function guardarNotasPedido(id) {
    const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === id); if (!p) return;
    const nueva = document.getElementById('mp-notas').value.slice(0, 1500);
    if (nueva === (p.notasInternas || '')) return toast('Sin cambios');
    p.notasInternas = nueva; p.historial.push({ fecha: new Date().toISOString(), texto: 'Notas internas actualizadas' });
    if (guardarPedidos(pedidos)) toast('Notas guardadas');
}

/* ---------------- Pagos ---------------- */
function abrirModalPago(id, alEntregar) {
    const p = obtenerPedidos().find(x => x.id === id); if (!p) return;
    pagoAlEntregar = !!alEntregar;
    document.getElementById('pago-pedido-id').value = id;
    document.getElementById('pago-titulo').textContent = alEntregar ? '¿Cobraste el saldo?' : 'Registrar abono';
    document.getElementById('pago-sub').textContent = `${p.folio} · ${p.cliente} · Saldo ${formatoMoneda(saldoPedido(p))}`;
    document.getElementById('pago-monto').value = saldoPedido(p).toFixed(2);
    document.getElementById('pago-fecha').value = hoyISO();
    document.getElementById('pago-metodo').value = 'Efectivo';
    document.getElementById('pago-nota').value = alEntregar ? 'Saldo al entregar' : `Abono ${(p.pagos || []).length + 1}`;
    document.getElementById('pago-cancelar').textContent = alEntregar ? 'Queda pendiente' : 'Cancelar';
    document.getElementById('pago-error').classList.add('hidden');
    document.getElementById('modal-pago').classList.remove('hidden');
    setTimeout(() => document.getElementById('pago-monto').select(), 50);
}
function cerrarModalPago() { document.getElementById('modal-pago').classList.add('hidden'); if (pagoAlEntregar) toast('El saldo queda en cuentas por cobrar'); pagoAlEntregar = false; }
function confirmarPago() {
    unaVez('pago', () => {
        const id = parseInt(document.getElementById('pago-pedido-id').value);
        const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === id); if (!p) return;
        const monto = num2(document.getElementById('pago-monto').value), fecha = document.getElementById('pago-fecha').value;
        const err = m => { const e = document.getElementById('pago-error'); e.textContent = m; e.classList.remove('hidden'); };
        if (!(monto > 0)) return err('Escribe un monto mayor a 0.');
        if (!fecha) return err('Escribe la fecha del pago.');
        if (monto > saldoPedido(p) + 0.005) return err(`El pago es mayor al saldo (${formatoMoneda(saldoPedido(p))}). Si cambió el total, edita el pedido primero.`);
        const metodo = document.getElementById('pago-metodo').value, nota = document.getElementById('pago-nota').value.trim().slice(0, 120);
        p.pagos.push({ id: nuevoId(), fecha, monto, metodo, nota });
        p.historial.push({ fecha: new Date().toISOString(), texto: `Pago de ${formatoMoneda(monto)} (${metodo}). Saldo: ${formatoMoneda(saldoPedido(p))}.` });
        if (!guardarPedidos(pedidos)) return;
        pagoAlEntregar = false;
        document.getElementById('modal-pago').classList.add('hidden');
        toast(`Pago registrado. Saldo ${formatoMoneda(saldoPedido(p))}`);
        refrescarVistaActual();
        if (!document.getElementById('modal-pedido').classList.contains('hidden')) abrirDetallePedido(id);
    });
}
async function eliminarPago(pedidoId, pagoId) {
    const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === pedidoId); if (!p) return;
    const pg = p.pagos.find(x => x.id === pagoId); if (!pg) return;
    if (!(await confirmar(`¿Eliminar el pago de ${formatoMoneda(pg.monto)} del ${fechaLarga(pg.fecha)}?`, 'Eliminar'))) return;
    p.pagos = p.pagos.filter(x => x.id !== pagoId);
    p.historial.push({ fecha: new Date().toISOString(), texto: `Se eliminó un pago de ${formatoMoneda(pg.monto)} (${pg.metodo}, ${pg.fecha}).` });
    guardarPedidos(pedidos); refrescarVistaActual(); abrirDetallePedido(pedidoId);
}
function refrescarVistaActual() {
    if (vistaActual === 'pedidos') renderizarPedidos();
    if (vistaActual === 'ventas') { renderizarVentas(); actualizarDashboard(); }
    if (vistaActual === 'inicio') renderizarPanel();
}

/* ---------------- Archivos ---------------- */
async function subirArchivosPedido(id, input) {
    const files = Array.from(input.files || []); input.value = '';
    if (!files.length) return;
    const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === id); if (!p) return;
    let ok = 0;
    for (const f of files) {
        if (f.size > 15 * 1024 * 1024) { toast(`"${f.name}" pesa más de 15 MB`, 'error'); continue; }
        const reg = { id: nuevoId(), pedidoId: id, nombre: f.name.slice(0, 120), tipo: f.type || 'application/octet-stream', tamano: f.size, fecha: new Date().toISOString(), blob: f };
        try { await guardarArchivoIDB(reg); } catch (e) { toast('No se pudo guardar el archivo en este navegador.', 'error'); continue; }
        p.archivos.push({ id: reg.id, nombre: reg.nombre, tipo: reg.tipo, tamano: reg.tamano, fecha: reg.fecha });
        ok++;
    }
    if (ok) { p.historial.push({ fecha: new Date().toISOString(), texto: `Se subieron ${ok} archivo(s).` }); guardarPedidos(pedidos); toast(`${ok} archivo(s) guardado(s)`); }
    abrirDetallePedido(id);
}
async function renderizarArchivosPedido(p) {
    const cont = document.getElementById('archivos-pedido'); if (!cont) return;
    if (!(p.archivos || []).length) { cont.innerHTML = '<p class="col-span-full text-sm text-gray-500">Sin archivos.</p>'; return; }
    cerrarDetallePedido._urls = cerrarDetallePedido._urls || [];
    const tarjetas = await Promise.all(p.archivos.map(async a => {
        let url = null;
        try { const reg = await leerArchivoIDB(a.id); if (reg && reg.blob) { url = URL.createObjectURL(reg.blob); cerrarDetallePedido._urls.push(url); } } catch (e) {}
        const esImg = /^image\//.test(a.tipo);
        const kb = a.tamano > 1048576 ? (a.tamano / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(a.tamano / 1024)) + ' KB';
        return `<div class="relative group rounded-xl border border-gray-200 overflow-hidden bg-gray-50">
            ${url ? `<a href="${url}" download="${esc(a.nombre)}" class="block" title="Descargar ${esc(a.nombre)}">` : '<div>'}
                <div class="aspect-square flex items-center justify-center">${esImg && url ? `<img src="${url}" alt="${esc(a.nombre)}" class="w-full h-full object-cover">` : `<i class="fa-regular ${/pdf/.test(a.tipo) ? 'fa-file-pdf' : 'fa-file'} text-3xl text-brand-lilac"></i>`}</div>
                <p class="text-[10px] px-1.5 py-1 truncate">${esc(a.nombre)}</p><p class="text-[10px] px-1.5 pb-1 text-gray-400">${url ? kb : 'No está en este dispositivo'}</p>
            ${url ? '</a>' : '</div>'}
            <button onclick="eliminarArchivoPedido(${p.id}, ${a.id})" class="absolute top-1 right-1 w-6 h-6 rounded-full bg-white/90 text-red-500 text-xs shadow" aria-label="Eliminar ${esc(a.nombre)}"><i class="fa-solid fa-xmark"></i></button>
        </div>`;
    }));
    cont.innerHTML = tarjetas.join('');
}
async function eliminarArchivoPedido(pedidoId, archivoId) {
    const pedidos = obtenerPedidos(); const p = pedidos.find(x => x.id === pedidoId); if (!p) return;
    const a = p.archivos.find(x => x.id === archivoId); if (!a) return;
    if (!(await confirmar(`¿Eliminar el archivo "${a.nombre}"?`, 'Eliminar'))) return;
    try { await borrarArchivoIDB(archivoId); } catch (e) {}
    p.archivos = p.archivos.filter(x => x.id !== archivoId);
    p.historial.push({ fecha: new Date().toISOString(), texto: `Se eliminó el archivo "${a.nombre}".` });
    guardarPedidos(pedidos); abrirDetallePedido(pedidoId);
}

/* ---------------- Exportar ---------------- */
function exportarPedidosCSV() {
    const ps = obtenerPedidos();
    if (!ps.length) return toast('No hay pedidos para exportar', 'error');
    exportarCSV(`pedidos-${hoyISO()}.csv`, ['Folio', 'Cliente', 'Teléfono', 'Producto', 'Cantidad', 'Medidas', 'Fecha', 'Entrega', 'Prioridad', 'Estado', 'Total', 'Pagado', 'Saldo', 'Cotización', 'Descripción'],
        ps.map(p => [p.folio, p.cliente, p.telefono, p.producto, p.cantidad, p.detalles, p.fecha, p.entrega, PRIORIDADES[p.prioridad || 'normal'].nombre, estadoInfo(p.estado).nombre, totalPedido(p), pagadoPedido(p), saldoPedido(p), p.cotizacionFolio || '', p.descripcion]));
}
