/* =====================================================================
   Personaliza Studio — Cotizador (pantalla)
   Varios productos por cotización, historial con folio, lista de
   precios, calculadoras de material y configuración de costos.
   ===================================================================== */

const KEY_COT_BORRADOR = 'personalizaStudio_cotizacionActual';
const KEY_COTIZACIONES = 'personalizaStudio_cotizaciones';
const KEY_FOLIO = 'personalizaStudio_folio';
const KEY_NEGOCIO = 'personalizaStudio_negocio';

const NEGOCIO_BASE = {
    nombre: 'Josephine | Personaliza y Crea',
    whatsapp: '442 352 0267',
    logo: null,
    anticipoPct: 50,
    vigenciaDias: 15,
    entrega: '5 a 7 días hábiles después de aprobar el diseño y recibir el anticipo',
    observaciones: 'Diseño incluido. Precios en pesos mexicanos (MXN). El pedido se inicia al recibir el anticipo.'
};
function obtenerNegocio() { return { ...NEGOCIO_BASE, ...leerJSON(KEY_NEGOCIO) }; }


function cotNueva() {
    const n = obtenerNegocio();
    return {
        id: 'c' + Date.now(), folio: null, fecha: hoyISO(), cliente: { nombre: '', telefono: '' }, items: [],
        diseno: { on: false, min: obtenerAjustes().minDiseno }, cargo: { concepto: '', monto: '' },
        descuento: { tipo: '%', valor: '' }, anticipoPct: n.anticipoPct, entrega: n.entrega,
        vigenciaDias: n.vigenciaDias, observaciones: n.observaciones
    };
}
let COT = leerJSON(KEY_COT_BORRADOR, null) || cotNueva();
let RES = null;              // último resultado calculado
let editIndex = null;        // partida que se está editando
let tabCotizadorActual = 'cotizar';
let calculadoraActual = 'planilla';

/* ---------------- Pestañas ---------------- */
function cambiarTabCotizador(tab) {
    tabCotizadorActual = tab;
    ['cotizar', 'historial', 'precios', 'calculadoras', 'costos'].forEach(t => {
        document.getElementById('tab-' + t).classList.toggle('hidden', t !== tab);
        const b = document.getElementById('tab-btn-' + t);
        b.classList.toggle('bg-brand-purple', t === tab);
        b.classList.toggle('text-white', t === tab);
        b.classList.toggle('text-brand-purple', t !== tab);
        b.setAttribute('aria-selected', t === tab);
    });
    ocultarError();
    if (tab === 'historial') renderizarHistorial();
    if (tab === 'precios') renderizarListaPrecios();
    if (tab === 'calculadoras') cambiarCalculadora(calculadoraActual);
    if (tab === 'costos') { cargarFormularioNegocio(); renderizarAjustes(); }
    if (tab === 'cotizar') { previsualizarItem(); actualizarCotizacion(); }
}

function iniciarCotizador() {
    const sel = document.getElementById('producto');
    if (!sel.options.length) {
        const cats = [...new Set(PRODUCTOS_COT.map(p => p.cat))];
        sel.innerHTML = '<option value="" disabled selected>Selecciona un producto...</option>' + cats.map(c =>
            `<optgroup label="${c}">` + PRODUCTOS_COT.filter(p => p.cat === c).map(p => `<option value="${p.id}">${p.nombre}</option>`).join('') + '</optgroup>'
        ).join('');
        poblarFormularioCot();
    }
    cambiarTabCotizador(tabCotizadorActual);
}

function seleccionarProductoCotizador(id, preset) {
    tabCotizadorActual = 'cotizar';
    navegarA('cotizador');
    cancelarEdicionItem(true);
    document.getElementById('producto').value = id;
    alCambiarProducto(preset);
    document.getElementById('cantidad').focus();
}

/* ---------------- Formulario de producto ---------------- */
function alCambiarProducto(preset, item) {
    const prod = productoCot(document.getElementById('producto').value);
    const cont = document.getElementById('cot-opciones');
    document.getElementById('item-extras').dataset.firma = '';
    if (!prod) { cont.innerHTML = ''; previsualizarItem(); return; }
    const libres = leerJSON(KEY_COSTOS_LIBRES);
    const valores = item ? item.opciones : (preset || {});
    cont.innerHTML = prod.opciones.map(op => {
        if (op.tipo === 'numero') {
            let val = valores[op.id] !== undefined ? valores[op.id] : op.def;
            if (op.id === 'costoLibre' && (val === '' || val === undefined)) val = libres[prod.id] ?? '';
            return `<div data-wrap="${op.id}"><label for="opt-${op.id}" class="lbl">${op.label}</label>
                <input type="number" step="0.01" min="0" id="opt-${op.id}" value="${esc(val)}" oninput="previsualizarItem()" class="campo"></div>`;
        }
        const def = valores[op.id] || op.def || op.choices[0];
        return `<fieldset data-wrap="${op.id}"><legend class="lbl">${op.label}</legend>
            <div class="flex flex-wrap gap-2">${op.choices.map((ch, i) => `
                <label class="cursor-pointer"><input type="radio" name="opt-${op.id}" value="${esc(ch)}" ${ch === def ? 'checked' : ''} onchange="previsualizarItem()" class="peer sr-only">
                <span class="chip-opcion">${esc(ch)}</span></label>`).join('')}
            </div></fieldset>`;
    }).join('');
    document.getElementById('item-extras').dataset.estado = JSON.stringify(item ? (item.extras || {}) : {});
    previsualizarItem();
}

function leerOpciones(prod) {
    const o = {};
    prod.opciones.forEach(op => {
        if (op.tipo === 'numero') { const el = document.getElementById('opt-' + op.id); o[op.id] = el ? el.value : op.def; }
        else { const el = document.querySelector(`input[name="opt-${op.id}"]:checked`); o[op.id] = el ? el.value : op.choices[0]; }
    });
    prod.opciones.forEach(op => {
        const w = document.querySelector(`[data-wrap="${op.id}"]`);
        if (w && op.si) w.classList.toggle('hidden', !op.si(o));
    });
    return o;
}

function leerExtrasDelFormulario() {
    const ext = {};
    document.querySelectorAll('#item-extras [data-extra]').forEach(row => {
        const id = row.dataset.extra;
        const on = row.querySelector('input[type=checkbox]').checked;
        const p = row.querySelector('[data-param]');
        ext[id] = { on, valor: p ? p.value : undefined };
    });
    return ext;
}

function renderizarProcesos(prod, c) {
    const bloque = document.getElementById('bloque-procesos');
    if (!prod || !c) { bloque.classList.add('hidden'); return; }
    bloque.classList.remove('hidden');
    document.getElementById('item-incluidos').innerHTML = '<span class="text-xs text-gray-500 mr-1 self-center">Ya incluye:</span>' +
        (c.incluidos || []).map(p => `<span class="text-[11px] font-semibold bg-brand-cyan/30 text-brand-textDark px-2 py-0.5 rounded-full"><i class="fa-solid fa-check mr-0.5"></i>${PROCESOS[p] || p}</span>`).join('');
    const disp = extrasDisponibles(prod, c);
    const cont = document.getElementById('item-extras');
    const firma = prod.id + '|' + disp.map(e => e.id).join(',');
    if (cont.dataset.firma === firma) return;
    const previo = cont.dataset.firma ? leerExtrasDelFormulario() : JSON.parse(cont.dataset.estado || '{}');
    cont.dataset.firma = firma;
    cont.innerHTML = '<p class="text-xs text-gray-500">Agregar al costo:</p>' + disp.map(e => {
        const st = previo[e.id] || {};
        let param = '';
        if (e.param && e.param.tipo === 'select') {
            const v = st.valor || e.param.def;
            param = `<select data-param class="campo py-1.5 text-xs w-auto" onchange="previsualizarItem()" aria-label="${esc(e.nombre)}">${e.param.choices.map(ch => `<option ${ch === v ? 'selected' : ''}>${esc(ch)}</option>`).join('')}</select>`;
        } else if (e.param && e.param.tipo === 'numero') {
            param = `<input data-param type="number" min="0" step="0.01" value="${esc(st.valor !== undefined ? st.valor : e.param.def)}" oninput="previsualizarItem()" class="campo py-1.5 text-xs w-20 text-right" aria-label="${esc(e.nombre)}">`;
        }
        return `<div data-extra="${e.id}" class="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
            <input type="checkbox" id="ex-${e.id}" ${st.on ? 'checked' : ''} onchange="previsualizarItem()" class="w-4 h-4 accent-[#C9457F] shrink-0">
            <label for="ex-${e.id}" class="text-sm flex-1 min-w-0">${esc(e.nombre)}</label>${param}</div>`;
    }).join('');
}

function leerItemDeFormulario() {
    const prod = productoCot(document.getElementById('producto').value);
    if (!prod) return null;
    const opciones = leerOpciones(prod);
    return {
        tipo: 'catalogo', productoId: prod.id, opciones,
        cantidad: parseInt(document.getElementById('cantidad').value) || 0,
        extras: leerExtrasDelFormulario(),
        precioManual: document.getElementById('precio-manual').value,
        personalizacion: document.getElementById('item-personalizacion').value.trim().slice(0, 300)
    };
}

function previsualizarItem() {
    const prod = productoCot(document.getElementById('producto').value);
    const prev = document.getElementById('item-preview');
    const btn = document.getElementById('btn-agregar-item');
    if (!prod) { prev.classList.add('hidden'); btn.disabled = true; renderizarProcesos(null); document.getElementById('seccion-vista-previa').classList.add('hidden'); return; }
    const A = obtenerAjustes();
    const opciones = leerOpciones(prod);
    const c = prod.calc(opciones, A);
    renderizarProcesos(prod, c);
    const item = leerItemDeFormulario();
    if (prod.libre && opciones.costoLibre !== '') {
        const libres = leerJSON(KEY_COSTOS_LIBRES); libres[prod.id] = parseFloat(opciones.costoLibre); escribirJSON(KEY_COSTOS_LIBRES, libres);
    }
    const r = cotizarItem(item, A);
    btn.disabled = !(r && !r.error && !r.sinCosto && item.cantidad > 0);
    if (!r || r.sinCosto) { prev.classList.add('hidden'); document.getElementById('seccion-vista-previa').classList.add('hidden'); return; }
    if (r.error) { prev.classList.remove('hidden'); prev.innerHTML = `<p class="text-red-600 font-semibold">${esc(r.error)}</p>`; return; }
    prev.classList.remove('hidden');
    const q = item.cantidad;
    const u = r.unidad;
    const escHTML = `<div class="grid grid-cols-3 gap-2 text-center text-xs">` + r.escalas.map((e, i) =>
        `<div class="rounded-lg py-1.5 ${q > 0 && i === r.idx && !r.manual ? 'bg-brand-purple text-white' : 'bg-white border border-brand-lilac/40'}"><div class="opacity-80">${e.label}</div><div class="font-bold text-sm">${fmt(e.precio)}</div></div>`).join('') + '</div>';
    const avisos = r.avisos.map(a => `<p class="text-xs rounded-md px-2 py-1 ${a.tipo === 'perdida' ? 'bg-red-50 text-red-700' : 'bg-yellow-50 text-yellow-800'}"><i class="fa-solid fa-triangle-exclamation mr-1"></i>${esc(a.msg)}</p>`).join('');
    prev.innerHTML = `
        <p class="font-semibold text-brand-purple">Precio por ${u}${r.info && r.info.modo === 'planilla' && r.escalas[0].precioLote ? ` <span class="font-normal text-gray-500 text-xs">· planilla completa ${fmt(r.escalas[0].precioLote)} (${r.info.rend} pzs)</span>` : ''}</p>
        ${escHTML}
        ${q > 0 ? `<div class="flex justify-between items-end border-t border-brand-lilac/30 pt-3">
            <div><p class="text-xs text-gray-500">${q} × ${fmt(r.precioUnit)}${r.manual ? ' <span class="text-pink-600 font-semibold">(precio especial)</span>' : ''}</p>
                 <p class="text-2xl font-bold text-brand-textDark tabular">${fmt(r.total)}</p></div>
            <div class="text-right text-xs tabular"><p class="text-gray-500">Costo ${fmt(r.costoTotal)}</p>
                 <p class="font-semibold ${r.ganancia < 0 ? 'text-red-600' : 'text-green-700'}">Ganas ${fmt(r.ganancia)}</p>
                 <p class="text-gray-500">${Math.round(r.recargo)}% sobre costo · ${Math.round(r.margen)}% del precio</p></div>
        </div>` : '<p class="text-xs text-gray-500">Escribe la cantidad para ver el total.</p>'}
        ${r.nota ? `<p class="text-xs bg-yellow-50 border border-yellow-200 text-yellow-800 rounded p-2">${esc(r.nota)}</p>` : ''}
        ${avisos}
        ${q > 0 ? `<details class="text-xs"><summary class="cursor-pointer text-brand-purple font-semibold">Ver desglose de costos</summary>
            <div class="mt-2 space-y-1 tabular">${r.desglose.map(l => `<div class="flex justify-between gap-2"><span class="text-gray-600">${esc(l.c)}</span><span>${fmt(l.m)}</span></div>`).join('')}
            <div class="flex justify-between gap-2 border-t pt-1 font-semibold"><span>Costo total</span><span>${fmt(r.costoTotal)}</span></div></div></details>` : ''}`;

    // Acomodo
    const sec = document.getElementById('seccion-vista-previa');
    if (r.info && (r.info.modo === 'planilla' || r.info.modo === 'rollo') && q > 0) {
        const d = r.info;
        const info = document.getElementById('info-acomodo');
        const cont = document.getElementById('contenedor-planillas');
        if (d.modo === 'planilla') {
            const util = d.rend * d.w * d.h, area = d.uW * d.uH;
            info.innerHTML = `<div><b class="text-brand-purple">Soporte:</b> ${esc(d.soporte)}</div><div><b class="text-brand-purple">Área útil:</b> ${d.uW} × ${d.uH} cm</div>
                <div><b class="text-brand-purple">Por planilla:</b> ${d.rend} (${d.rows} × ${d.cols}${d.rot ? ', girada' : ''})</div><div><b class="text-brand-purple">Planillas:</b> ${d.planillas}</div>
                <div class="col-span-2"><b class="text-brand-purple">Sobrante por planilla:</b> ${Math.round((1 - util / area) * 100)}% del área útil</div>`;
            cont.className = 'grid grid-cols-2 gap-4 max-h-[50vh] overflow-y-auto p-1';
            dibujarPlanillas(cont, { plW: d.plW, plH: d.plH, uW: d.uW, uH: d.uH, cols: d.cols, rows: d.rows, etqW: d.etqW, etqH: d.etqH, sep: d.sep, rend: d.rend }, q);
        } else {
            info.innerHTML = `<div><b class="text-brand-purple">Rollo:</b> ${esc(d.soporte)} ${d.anchoRollo} cm</div><div><b class="text-brand-purple">Por fila:</b> ${d.cols}${d.rot ? ' (girado)' : ''}</div>
                <div><b class="text-brand-purple">Largo:</b> ${(d.largo / 100).toFixed(2)} m</div><div><b class="text-brand-purple">Desperdicio:</b> ${Math.round(d.desperdicio * 100)}%</div>`;
            cont.className = 'p-1';
            dibujarRollo(cont, { anchoRollo: d.anchoRollo, cols: d.cols, filas: d.filas, etqW: d.etqW, etqH: d.etqH, sep: d.sep, largo: d.largo }, q);
        }
        sec.classList.remove('hidden');
    } else sec.classList.add('hidden');
}

function agregarOActualizarItem() {
    const item = leerItemDeFormulario();
    if (!item) return mostrarError('Elige un producto.');
    if (!(item.cantidad > 0)) return mostrarError('Escribe una cantidad mayor a 0.');
    const r = cotizarItem(item, obtenerAjustes());
    if (!r || r.error || r.sinCosto) return mostrarError(r && r.error ? r.error : 'Faltan datos para calcular este producto.');
    ocultarError();
    if (editIndex !== null) { COT.items[editIndex] = item; toast('Partida actualizada'); }
    else { COT.items.push(item); toast('Producto agregado a la cotización'); }
    cancelarEdicionItem(true);
    actualizarCotizacion();
}

function editarItem(i) {
    const it = COT.items[i];
    if (!it || it.tipo !== 'catalogo') return;
    editIndex = i;
    document.getElementById('producto').value = it.productoId;
    alCambiarProducto(null, it);
    document.getElementById('cantidad').value = it.cantidad;
    document.getElementById('precio-manual').value = it.precioManual || '';
    document.getElementById('item-personalizacion').value = it.personalizacion || '';
    document.getElementById('item-titulo').innerHTML = `<i class="fa-solid fa-pen mr-1"></i> Editando partida ${i + 1}`;
    document.getElementById('btn-agregar-item').innerHTML = '<i class="fa-solid fa-check mr-1"></i> Guardar cambios';
    document.getElementById('btn-cancelar-edicion').classList.remove('hidden');
    previsualizarItem();
    document.getElementById('item-titulo').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function cancelarEdicionItem(limpiar) {
    editIndex = null;
    document.getElementById('item-titulo').innerHTML = '<i class="fa-solid fa-circle-plus mr-1"></i> Agregar producto';
    document.getElementById('btn-agregar-item').innerHTML = '<i class="fa-solid fa-plus mr-1"></i> Agregar a la cotización';
    document.getElementById('btn-cancelar-edicion').classList.add('hidden');
    document.getElementById('cantidad').value = '';
    document.getElementById('precio-manual').value = '';
    document.getElementById('item-personalizacion').value = '';
    document.getElementById('item-extras').dataset.firma = '';
    document.getElementById('item-extras').dataset.estado = '{}';
    if (limpiar !== true) { document.getElementById('producto').value = ''; alCambiarProducto(); }
    else previsualizarItem();
}
function duplicarItem(i) { COT.items.splice(i + 1, 0, JSON.parse(JSON.stringify(COT.items[i]))); actualizarCotizacion(); toast('Partida duplicada'); }
function eliminarItem(i) { COT.items.splice(i, 1); if (editIndex === i) cancelarEdicionItem(); actualizarCotizacion(); toast('Partida eliminada'); }
function moverItem(i, d) {
    const j = i + d; if (j < 0 || j >= COT.items.length) return;
    [COT.items[i], COT.items[j]] = [COT.items[j], COT.items[i]]; actualizarCotizacion();
}

/* ---------------- Cotización ---------------- */
function poblarFormularioCot() {
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v === undefined || v === null ? '' : v; };
    set('cli-nombre', COT.cliente.nombre); set('cli-telefono', COT.cliente.telefono);
    document.getElementById('cot-diseno-on').checked = !!COT.diseno.on; set('cot-diseno-min', COT.diseno.min);
    set('cot-cargo-concepto', COT.cargo.concepto); set('cot-cargo-monto', COT.cargo.monto);
    set('cot-desc-tipo', COT.descuento.tipo); set('cot-desc-valor', COT.descuento.valor);
    set('anticipo_pct', COT.anticipoPct); set('cot-entrega', COT.entrega); set('cot-vigencia', COT.vigenciaDias); set('cot-obs', COT.observaciones);
}
function leerFormularioCot() {
    const v = id => document.getElementById(id).value;
    COT.cliente = { nombre: v('cli-nombre').trim().slice(0, 80), telefono: v('cli-telefono').trim().slice(0, 20) };
    COT.diseno = { on: document.getElementById('cot-diseno-on').checked, min: v('cot-diseno-min') };
    COT.cargo = { concepto: v('cot-cargo-concepto').trim().slice(0, 60), monto: v('cot-cargo-monto') };
    COT.descuento = { tipo: v('cot-desc-tipo'), valor: v('cot-desc-valor') };
    COT.anticipoPct = v('anticipo_pct');
    COT.entrega = v('cot-entrega').slice(0, 120); COT.vigenciaDias = v('cot-vigencia'); COT.observaciones = v('cot-obs').slice(0, 600);
}

function actualizarCotizacion() {
    if (!document.getElementById('cot-partidas')) return;
    leerFormularioCot();
    RES = cotizarCotizacion(COT, obtenerAjustes());
    escribirJSON(KEY_COT_BORRADOR, COT);
    if (COT.folio) guardarEnHistorial(false);

    document.getElementById('cot-folio').textContent = COT.folio || 'Sin guardar';
    document.getElementById('cot-fecha').textContent = fechaLarga(COT.fecha);
    document.getElementById('cot-num-piezas').textContent = COT.items.length ? `${COT.items.length} producto(s) · ${RES.piezas} piezas` : '';

    const cont = document.getElementById('cot-partidas');
    if (!COT.items.length) {
        cont.innerHTML = `<div class="text-center text-sm text-gray-500 border-2 border-dashed border-brand-lilac/50 rounded-xl py-8 px-4">
            <i class="fa-solid fa-basket-shopping text-2xl text-brand-lilac mb-2"></i><p>Todavía no hay productos.<br>Elige uno a la izquierda y toca <b>Agregar a la cotización</b>.</p></div>`;
    } else {
        cont.innerHTML = COT.items.map((it, i) => {
            const r = RES.partidas[i];
            const ok = r && !r.error && !r.sinCosto;
            const aviso = ok && r.avisos.some(a => a.tipo === 'perdida') ? '<span class="pill bg-red-100 text-red-700">Pierdes dinero</span>'
                : ok && r.avisos.some(a => a.tipo === 'bajo') ? '<span class="pill bg-yellow-100 text-yellow-800">Ganancia baja</span>' : '';
            const extras = ok && r.extrasAplicados.length ? `<p class="text-[11px] text-gray-500">+ ${r.extrasAplicados.map(e => esc(e.nombre)).join(', ')}</p>` : '';
            return `<div class="partida flex gap-3 items-start rounded-xl border ${editIndex === i ? 'border-brand-purple bg-brand-lilac/10' : 'border-gray-200'} p-3">
                <div class="w-7 h-7 shrink-0 rounded-full bg-brand-pink/30 text-brand-purple text-xs font-bold flex items-center justify-center">${i + 1}</div>
                <div class="flex-1 min-w-0">
                    <p class="font-semibold text-brand-textDark leading-tight">${esc(ok ? r.nombre : (it.nombre || 'Partida'))} ${it.tipo === 'libre' ? '<span class="pill bg-brand-cyan/30 text-brand-textDark">Calculadora</span>' : ''} ${ok && r.manual && it.tipo !== 'libre' ? '<span class="pill bg-pink-100 text-pink-700">Precio especial</span>' : ''} ${aviso}</p>
                    <p class="text-xs text-gray-500">${esc(ok ? r.detalle : (r && r.error) || 'Faltan datos')}</p>
                    ${extras}
                    ${it.personalizacion ? `<p class="text-xs text-brand-purple mt-0.5"><i class="fa-solid fa-pen-nib mr-1"></i>${esc(it.personalizacion)}</p>` : ''}
                </div>
                <div class="text-right shrink-0 tabular">
                    <p class="text-xs text-gray-500">${ok ? `${r.cantidad} × ${fmt(r.precioUnit)}` : ''}</p>
                    <p class="font-bold text-brand-textDark">${ok ? fmt(r.total) : '—'}</p>
                    <div class="flex gap-1 justify-end mt-1 text-gray-400">
                        ${it.tipo === 'catalogo' ? `<button onclick="editarItem(${i})" class="icon-btn" title="Editar" aria-label="Editar partida ${i + 1}"><i class="fa-solid fa-pen"></i></button>` : ''}
                        <button onclick="duplicarItem(${i})" class="icon-btn" title="Duplicar" aria-label="Duplicar partida ${i + 1}"><i class="fa-regular fa-copy"></i></button>
                        <button onclick="moverItem(${i},-1)" class="icon-btn" title="Subir" aria-label="Subir partida ${i + 1}"><i class="fa-solid fa-arrow-up"></i></button>
                        <button onclick="eliminarItem(${i})" class="icon-btn hover:text-red-500" title="Eliminar" aria-label="Eliminar partida ${i + 1}"><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div></div>`;
        }).join('');
    }

    const set = (id, v) => document.getElementById(id).textContent = v;
    set('tot-subtotal', fmt(RES.sumaPartidas));
    document.getElementById('fila-diseno').classList.toggle('hidden', !RES.disenoPrecio); set('tot-diseno', fmt(RES.disenoPrecio));
    document.getElementById('fila-descuento').classList.toggle('hidden', !RES.descuento); set('tot-descuento', '−' + fmt(RES.descuento));
    document.getElementById('fila-cargo').classList.toggle('hidden', !RES.cargo); set('tot-cargo', fmt(RES.cargo)); set('tot-cargo-label', COT.cargo.concepto || 'Cargo extra');
    set('tot-total', fmt(RES.total)); set('tot-anticipo-pct', RES.anticipoPct); set('tot-anticipo', fmt(RES.anticipo)); set('tot-saldo', fmt(RES.saldo));

    document.getElementById('cot-avisos').innerHTML = RES.avisos.filter((a, i, arr) => arr.findIndex(b => b.msg === a.msg) === i).map(a =>
        `<div class="flex gap-2 items-start text-sm rounded-lg px-3 py-2 ${a.tipo === 'perdida' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-yellow-50 text-yellow-800 border border-yellow-200'}">
            <i class="fa-solid fa-triangle-exclamation mt-0.5"></i><span>${esc(a.msg)}</span></div>`).join('');

    const validos = RES.partidas.map((r, i) => ({ r, i })).filter(x => x.r && !x.r.error && !x.r.sinCosto);
    document.getElementById('cot-internos').innerHTML = `
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div class="bg-white rounded-lg p-2 border border-green-100"><p class="text-gray-500">Costo total</p><p class="font-bold text-sm">${fmt(RES.costoTotal)}</p></div>
            <div class="bg-white rounded-lg p-2 border border-green-100"><p class="text-gray-500">Ganancia</p><p class="font-bold text-sm ${RES.ganancia < 0 ? 'text-red-600' : 'text-green-700'}">${fmt(RES.ganancia)}</p></div>
            <div class="bg-white rounded-lg p-2 border border-green-100"><p class="text-gray-500">Margen (del precio)</p><p class="font-bold text-sm">${Math.round(RES.margen)}%</p></div>
            <div class="bg-white rounded-lg p-2 border border-green-100"><p class="text-gray-500">Recargo (sobre costo)</p><p class="font-bold text-sm">${Math.round(RES.recargo)}%</p></div>
        </div>
        ${validos.map(({ r, i }) => `<div class="flex justify-between gap-2 border-b border-green-100 py-1"><span class="text-gray-600">${i + 1}. ${esc(r.nombre)} · ${formatoMinutos(r.minutos)} de trabajo</span><span>costo ${fmt(r.costoTotal)} · gana ${fmt(r.ganancia)}</span></div>`).join('')}
        ${RES.disenoCosto ? `<div class="flex justify-between gap-2 py-1"><span class="text-gray-600">Diseño y preparación</span><span>costo ${fmt(RES.disenoCosto)}</span></div>` : ''}`;
}

/* ---------------- Folio e historial ---------------- */
function generarFolio() {
    const hoy = hoyISO().replace(/-/g, '');
    const f = leerJSON(KEY_FOLIO, { fecha: '', n: 0 });
    const usados = new Set(leerJSON(KEY_COTIZACIONES, []).map(c => c.folio));
    let n = f.fecha === hoy ? f.n : 0, folio;
    do { n++; folio = `COT-${hoy}-${String(n).padStart(3, '0')}`; } while (usados.has(folio));
    escribirJSON(KEY_FOLIO, { fecha: hoy, n });
    return folio;
}
function guardarEnHistorial(conToast) {
    const lista = leerJSON(KEY_COTIZACIONES, []);
    const res = RES || cotizarCotizacion(COT, obtenerAjustes());
    const registro = { ...JSON.parse(JSON.stringify(COT)), total: res.total, actualizada: new Date().toISOString() };
    const i = lista.findIndex(c => c.id === COT.id);
    if (i >= 0) lista[i] = registro; else lista.unshift(registro);
    if (!escribirJSON(KEY_COTIZACIONES, lista)) { mostrarError('No se pudo guardar: el almacenamiento del navegador está lleno o bloqueado. Descarga un respaldo.'); return false; }
    if (conToast) toast(`Cotización ${COT.folio} guardada`);
    return true;
}
function guardarCotizacion(conToast) {
    leerFormularioCot();
    if (!COT.items.length) { mostrarError('Agrega al menos un producto antes de guardar.'); return false; }
    if (!COT.folio) COT.folio = generarFolio();
    RES = cotizarCotizacion(COT, obtenerAjustes());
    const ok = guardarEnHistorial(conToast);
    actualizarCotizacion();
    return ok;
}
async function nuevaCotizacion() {
    if (COT.items.length && !COT.folio && !(await confirmar('Esta cotización no está guardada. ¿Empezar una nueva de todos modos?'))) return;
    COT = cotNueva();
    cancelarEdicionItem();
    poblarFormularioCot();
    actualizarCotizacion();
    toast('Cotización nueva');
}
function renderizarHistorial() {
    const q = (document.getElementById('buscar-historial').value || '').toLowerCase();
    const lista = leerJSON(KEY_COTIZACIONES, []).filter(c => `${c.folio} ${c.cliente && c.cliente.nombre}`.toLowerCase().includes(q));
    document.getElementById('lista-historial').innerHTML = lista.length ? lista.map(c => `
        <div class="flex flex-wrap items-center gap-3 border border-gray-200 rounded-xl p-3 ${c.id === COT.id ? 'bg-brand-lilac/10 border-brand-lilac' : ''}">
            <div class="flex-1 min-w-[180px]">
                <p class="font-bold text-brand-textDark">${esc(c.folio)} ${c.id === COT.id ? '<span class="pill bg-brand-purple text-white">Abierta</span>' : ''}</p>
                <p class="text-xs text-gray-500">${fechaLarga(c.fecha)} · ${esc((c.cliente && c.cliente.nombre) || 'Sin nombre')} · ${(c.items || []).length} producto(s)</p>
            </div>
            <p class="font-bold text-brand-purple tabular">${fmt(c.total)}</p>
            <div class="flex gap-1">
                <button onclick="abrirCotizacion('${c.id}')" class="btn-mini bg-brand-purple text-white">Abrir</button>
                <button onclick="duplicarCotizacion('${c.id}')" class="btn-mini bg-gray-100 text-gray-700">Duplicar</button>
                <button onclick="eliminarCotizacion('${c.id}')" class="btn-mini bg-gray-100 text-red-600" aria-label="Eliminar ${esc(c.folio)}"><i class="fa-solid fa-trash-can"></i></button>
            </div>
        </div>`).join('') : '<p class="text-center text-gray-500 py-8 text-sm">Aún no hay cotizaciones guardadas. Se guardan al tocar Guardar, Descargar PDF o WhatsApp.</p>';
}
function abrirCotizacion(id) {
    const c = leerJSON(KEY_COTIZACIONES, []).find(x => x.id === id);
    if (!c) return;
    COT = JSON.parse(JSON.stringify(c)); delete COT.total; delete COT.actualizada;
    cancelarEdicionItem(); poblarFormularioCot(); cambiarTabCotizador('cotizar');
    toast(`Cotización ${COT.folio} abierta`);
}
function duplicarCotizacion(id) {
    const c = leerJSON(KEY_COTIZACIONES, []).find(x => x.id === id);
    if (!c) return;
    COT = { ...JSON.parse(JSON.stringify(c)), id: 'c' + Date.now(), folio: null, fecha: hoyISO() };
    delete COT.total; delete COT.actualizada;
    cancelarEdicionItem(); poblarFormularioCot(); cambiarTabCotizador('cotizar');
    toast('Copia lista. Guárdala para darle folio nuevo.');
}
async function eliminarCotizacion(id) {
    const lista = leerJSON(KEY_COTIZACIONES, []);
    const c = lista.find(x => x.id === id);
    if (!c || !(await confirmar(`¿Eliminar la cotización ${c.folio}? No se puede deshacer.`))) return;
    escribirJSON(KEY_COTIZACIONES, lista.filter(x => x.id !== id));
    if (COT.id === id) COT.folio = null;
    renderizarHistorial();
}

/* ---------------- Pedido y texto ---------------- */
function resumenPartidas(R) {
    return R.partidas.filter(r => r && !r.error && !r.sinCosto).map(r => `${r.nombre} ×${r.cantidad}`).join(', ');
}
function registrarCotizacionComoPedido() {
    if (!COT.items.length) return mostrarError('Agrega productos a la cotización primero.');
    if (!guardarCotizacion(false)) return;
    nuevoPedidoDesdeCotizacion(COT, RES);
}
function textoCotizacion() {
    const R = RES, n = obtenerNegocio();
    let t = `*Cotización ${COT.folio || ''} — ${n.nombre}*\n`;
    if (COT.cliente.nombre) t += `Cliente: ${COT.cliente.nombre}\n`;
    t += '\n';
    R.partidas.forEach((r, i) => { if (r && !r.error && !r.sinCosto) t += `• ${r.cantidad} ${r.nombre} (${r.detalle}) — ${fmt(r.precioUnit)} c/u = ${fmt(r.total)}\n${COT.items[i].personalizacion ? '   ' + COT.items[i].personalizacion + '\n' : ''}`; });
    if (R.disenoPrecio) t += `• Diseño y preparación — ${fmt(R.disenoPrecio)}\n`;
    if (R.descuento) t += `Descuento: −${fmt(R.descuento)}\n`;
    if (R.cargo) t += `${COT.cargo.concepto || 'Cargo extra'}: ${fmt(R.cargo)}\n`;
    t += `\n*Total: ${fmt(R.total)}*\nAnticipo (${R.anticipoPct}%): ${fmt(R.anticipo)}\nSaldo: ${fmt(R.saldo)}\n`;
    if (COT.entrega) t += `Entrega: ${COT.entrega}\n`;
    t += `Vigencia: ${COT.vigenciaDias || 15} días\nWhatsApp ${n.whatsapp}`;
    return t;
}
function copiarCotizacion() {
    if (!COT.items.length) return mostrarError('Agrega productos a la cotización primero.');
    const texto = textoCotizacion();
    const ok = () => { const t = document.getElementById('txt-copiar'); t.textContent = '¡Copiado!'; setTimeout(() => t.textContent = 'Copiar texto', 1800); };
    try {
        navigator.clipboard.writeText(texto).then(ok).catch(() => fallbackCopiar(texto, ok));
    } catch (e) { fallbackCopiar(texto, ok); }
}
function fallbackCopiar(texto, ok) {
    const ta = document.createElement('textarea'); ta.value = texto; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); ok(); } catch (e) { mostrarError('No se pudo copiar automáticamente.'); }
    document.body.removeChild(ta);
}

/* ---------------- Lista de precios ---------------- */
function renderizarListaPrecios() {
    const A = obtenerAjustes();
    const q = (document.getElementById('buscar-precios').value || '').toLowerCase();
    const html = PRODUCTOS_COT.filter(p => p.id !== 'medida' && p.nombre.toLowerCase().includes(q)).map(prod => {
        const unidad = prod.unidad || 'pieza';
        if (prod.libre) return `<div><h4 class="font-bold text-brand-purple mb-1">${prod.nombre}</h4><p class="text-sm text-gray-500">Precio según tu costo por ${unidad}: escríbelo en la pestaña Cotizar.</p></div>`;
        let cab = null;
        const filas = combinaciones(prod).map(o => {
            const r = cotizarItem({ tipo: 'catalogo', productoId: prod.id, opciones: o, cantidad: 1 }, A);
            if (!r || r.error || r.sinCosto) return '';
            cab = r.escalas.map(e => e.label);
            const extra = r.info && r.info.modo === 'planilla' ? `<div class="text-[11px] text-gray-400">${r.info.rend} por planilla · planilla ${fmt(r.escalas[0].precioLote)}</div>` : '';
            return `<tr class="border-b border-gray-100"><td class="p-2">${esc(r.detalle.replace(/^(Adulto|Infantil), /, '').replace('estampado ', ''))}${extra}</td>
                <td class="p-1.5 md:p-2 text-right whitespace-nowrap text-gray-500">${fmt(r.costoUnit)}</td>
                ${r.escalas.map((e, i) => `<td class="p-1.5 md:p-2 text-right whitespace-nowrap font-semibold ${i === 0 ? 'text-brand-purple' : 'text-gray-700'}">${fmt(e.precio)}</td>`).join('')}</tr>`;
        }).join('');
        return `<div><h4 class="font-bold text-brand-purple mb-2">${prod.nombre} <span class="text-xs font-normal text-gray-400">· precio por ${unidad}</span></h4>
            <div class="overflow-x-auto"><table class="w-full text-xs md:text-sm tabular">
            <thead class="bg-brand-lilac/20 text-brand-purple text-xs uppercase"><tr><th class="p-2 text-left">Variante</th><th class="p-2 text-right">Costo</th>${(cab || []).map(l => `<th class="p-2 text-right whitespace-nowrap">${l}</th>`).join('')}</tr></thead>
            <tbody>${filas}</tbody></table></div></div>`;
    }).join('');
    document.getElementById('lista-precios').innerHTML = html || '<p class="text-center text-gray-500 py-6">Sin resultados.</p>';
}

/* ---------------- Mis costos ---------------- */
function renderizarAjustes() {
    const A = obtenerAjustes();
    const grupos = [...new Set(AJUSTES_DEF.map(d => d[0]))];
    document.getElementById('form-ajustes').innerHTML = grupos.map(g => `
        <div class="border border-brand-lilac/40 rounded-xl p-4 ${g === 'Precio y ganancia' ? 'bg-brand-pink/10 md:col-span-2' : 'bg-gray-50/50'}">
            <h4 class="font-bold text-brand-purple mb-3">${g}</h4>
            ${g === 'Precio y ganancia' ? `<p class="text-xs text-gray-600 mb-3">Con <b>recargo</b>, 75% significa costo × 1.75 (de cada $100 de venta ganas $42.86). Con <b>margen</b>, 40% significa que de cada $100 de venta ganas $40.</p>` : ''}
            ${g === 'Procesos extra' || g === 'Costos indirectos' ? `<p class="text-xs text-gray-600 mb-3">Solo se suman cuando los activas en un producto (o, los indirectos, cuando son mayores a 0).</p>` : ''}
            <div class="grid grid-cols-1 ${g === 'Precio y ganancia' ? 'md:grid-cols-2 gap-x-8' : ''} gap-y-2">${AJUSTES_DEF.filter(d => d[0] === g).map(d => {
                const cambiado = A[d[1]] !== d[3];
                if (d[4] === 'select') return `<div class="flex items-center justify-between gap-3">
                    <label for="aj-${d[1]}" class="text-sm text-gray-700 flex-1">${d[2]}${cambiado ? ' <span class="text-[10px] text-pink-500 font-semibold">(cambiado)</span>' : ''}</label>
                    <select id="aj-${d[1]}" onchange="guardarAjuste('${d[1]}', this.value)" class="campo py-1.5 w-48 text-sm">${d[5].map(([v, t]) => `<option value="${v}" ${String(A[d[1]]) === v ? 'selected' : ''}>${t}</option>`).join('')}</select></div>`;
                return `<div class="flex items-center justify-between gap-3">
                    <label for="aj-${d[1]}" class="text-sm text-gray-700 flex-1">${d[2]}${cambiado ? ' <span class="text-[10px] text-pink-500 font-semibold">(cambiado)</span>' : ''}${d[3] === 0 && A[d[1]] === 0 ? ' <span class="text-[10px] text-gray-400">(sin capturar)</span>' : ''}</label>
                    <div class="relative w-28 shrink-0">
                        ${d[4] === '$' ? '<span class="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 text-sm">$</span>' : ''}
                        <input type="number" step="0.01" min="0" id="aj-${d[1]}" value="${A[d[1]]}" onchange="guardarAjuste('${d[1]}', this.value)"
                            class="w-full bg-white border border-gray-300 rounded-lg py-1.5 ${d[4] === '$' ? 'pl-5' : 'pl-2'} pr-10 text-sm text-right">
                        ${d[4] !== '$' ? `<span class="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 text-[11px]">${d[4]}</span>` : ''}
                    </div></div>`;
            }).join('')}</div>
        </div>`).join('');
}
function guardarAjuste(clave, valor) {
    const def = AJUSTES_DEF.find(d => d[1] === clave);
    const guardados = leerJSON(KEY_AJUSTES);
    if (def && def[4] === 'select') {
        if (valor === def[3]) delete guardados[clave]; else guardados[clave] = valor;
    } else {
        const v = parseFloat(valor);
        if (isNaN(v) || v < 0) { mostrarError(`"${def ? def[2] : clave}" debe ser un número igual o mayor a 0.`); renderizarAjustes(); return; }
        if (clave === 'ganancia' || clave === 'margenMinimo') {
            const modo = (guardados.modoGanancia || AJUSTES_BASE.modoGanancia);
            if (modo === 'margen' && v >= 100) { mostrarError('En modo margen la ganancia debe ser menor a 100%.'); renderizarAjustes(); return; }
        }
        if (v === AJUSTES_BASE[clave]) delete guardados[clave]; else guardados[clave] = v;
    }
    ocultarError();
    escribirJSON(KEY_AJUSTES, guardados);
    renderizarAjustes();
    toast('Guardado');
}
async function restaurarAjustes() {
    if (!(await confirmar('¿Regresar todos los costos a los valores originales?'))) return;
    escribirJSON(KEY_AJUSTES, {});
    renderizarAjustes();
}

/* Datos del negocio y logotipo */
function cargarFormularioNegocio() {
    const n = obtenerNegocio();
    const set = (id, v) => document.getElementById(id).value = v === undefined || v === null ? '' : v;
    set('neg-nombre', n.nombre); set('neg-whatsapp', n.whatsapp); set('neg-anticipo', n.anticipoPct); set('neg-vigencia', n.vigenciaDias);
    set('neg-entrega', n.entrega); set('neg-obs', n.observaciones);
    const img = document.getElementById('neg-logo-img');
    img.classList.toggle('hidden', !n.logo); if (n.logo) img.src = n.logo;
    document.getElementById('neg-logo-vacio').classList.toggle('hidden', !!n.logo);
    document.getElementById('neg-logo-quitar').classList.toggle('hidden', !n.logo);
}
function guardarNegocio() {
    const n = obtenerNegocio();
    const v = id => document.getElementById(id).value.trim();
    n.nombre = v('neg-nombre').slice(0, 80) || NEGOCIO_BASE.nombre;
    n.whatsapp = v('neg-whatsapp').slice(0, 20);
    n.anticipoPct = Math.min(100, Math.max(0, parseFloat(v('neg-anticipo')) || 0));
    n.vigenciaDias = Math.max(1, parseInt(v('neg-vigencia')) || 15);
    n.entrega = v('neg-entrega').slice(0, 120); n.observaciones = v('neg-obs').slice(0, 600);
    if (!escribirJSON(KEY_NEGOCIO, n)) return mostrarError('No se pudo guardar.');
    toast('Datos del negocio guardados');
}
function subirLogo(input) {
    const f = input.files && input.files[0];
    if (!f) return;
    if (!/^image\/(png|jpeg|webp)$/.test(f.type)) return mostrarError('El logotipo debe ser PNG, JPG o WEBP.');
    const rd = new FileReader();
    rd.onload = () => {
        const img = new Image();
        img.onload = () => {
            const max = 500, k = Math.min(1, max / Math.max(img.width, img.height));
            const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
            cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
            const n = obtenerNegocio(); n.logo = cv.toDataURL('image/png');
            if (!escribirJSON(KEY_NEGOCIO, n)) return mostrarError('La imagen es muy pesada para guardarla. Prueba con una más pequeña.');
            cargarFormularioNegocio(); aplicarLogoCabecera(); toast('Logotipo guardado');
        };
        img.onerror = () => mostrarError('No se pudo leer la imagen.');
        img.src = rd.result;
    };
    rd.readAsDataURL(f);
    input.value = '';
}
function quitarLogo() { const n = obtenerNegocio(); n.logo = null; escribirJSON(KEY_NEGOCIO, n); cargarFormularioNegocio(); aplicarLogoCabecera(); }

/* Respaldo */
const blobADataURL = b => new Promise((ok, mal) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = mal; r.readAsDataURL(b); });
async function dataURLABlob(u) { return (await fetch(u)).blob(); }
function clavesApp() {
    const k = [];
    for (let i = 0; i < localStorage.length; i++) { const x = localStorage.key(i); if (x && x.startsWith('personalizaStudio_') && x !== 'personalizaStudio_respaldoPrevio') k.push(x); }
    return k;
}
async function descargarRespaldo() {
    const datos = {};
    try { clavesApp().forEach(k => datos[k] = localStorage.getItem(k)); }
    catch (e) { return mostrarError('El navegador no permite leer los datos guardados.'); }
    let archivos = [];
    try {
        const regs = await todosArchivosIDB();
        archivos = await Promise.all((regs || []).map(async r => ({ id: r.id, pedidoId: r.pedidoId, nombre: r.nombre, tipo: r.tipo, tamano: r.tamano, fecha: r.fecha, datos: await blobADataURL(r.blob) })));
    } catch (e) { /* sin archivos o navegador sin IndexedDB */ }
    const archivo = { app: 'personaliza-studio', version: 3, fecha: new Date().toISOString(), datos, archivos };
    const blob = new Blob([JSON.stringify(archivo)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = `respaldo-personaliza-studio-${hoyISO()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    document.getElementById('respaldo-info').textContent = `Respaldo descargado: ${Object.keys(datos).length} secciones y ${archivos.length} archivo(s) de pedidos (${(blob.size / 1048576).toFixed(1)} MB).`;
}
function restaurarRespaldo(input) {
    const f = input.files && input.files[0];
    input.value = '';
    if (!f) return;
    const rd = new FileReader();
    rd.onload = async () => {
        let arch;
        try { arch = JSON.parse(rd.result); } catch (e) { return mostrarError('El archivo no es un respaldo válido.'); }
        if (!arch || arch.app !== 'personaliza-studio' || typeof arch.datos !== 'object') return mostrarError('El archivo no es un respaldo de Personaliza Studio.');
        const claves = Object.keys(arch.datos).filter(k => k.startsWith('personalizaStudio_') && typeof arch.datos[k] === 'string');
        const nArch = Array.isArray(arch.archivos) ? arch.archivos.length : 0;
        if (!(await confirmar(`¿Restaurar el respaldo del ${new Date(arch.fecha).toLocaleDateString('es-MX')}? Se reemplazarán ${claves.length} secciones${nArch ? ` y se agregarán ${nArch} archivo(s)` : ''}. Tus datos actuales se guardan como copia de seguridad.`, 'Restaurar'))) return;
        try {
            const previo = {}; clavesApp().forEach(k => previo[k] = localStorage.getItem(k));
            localStorage.setItem('personalizaStudio_respaldoPrevio', JSON.stringify({ fecha: new Date().toISOString(), datos: previo }));
            claves.forEach(k => localStorage.setItem(k, arch.datos[k]));
        } catch (e) { return mostrarError('No se pudo restaurar: el almacenamiento del navegador está lleno o bloqueado.'); }
        for (const a of (arch.archivos || [])) {
            try { await guardarArchivoIDB({ id: a.id, pedidoId: a.pedidoId, nombre: a.nombre, tipo: a.tipo, tamano: a.tamano, fecha: a.fecha, blob: await dataURLABlob(a.datos) }); } catch (e) {}
        }
        location.reload();
    };
    rd.readAsText(f);
}

/* ---------------- Calculadoras ---------------- */
function cambiarCalculadora(t) {
    calculadoraActual = t;
    ['planilla', 'rollo', 'maquina'].forEach(x => {
        document.getElementById('calc-' + x).classList.toggle('hidden', x !== t);
        const b = document.getElementById('calc-btn-' + x);
        b.classList.toggle('bg-brand-purple', x === t); b.classList.toggle('text-white', x === t); b.classList.toggle('border-brand-purple', x === t);
        b.classList.toggle('bg-white', x !== t); b.classList.toggle('text-brand-purple', x !== t); b.classList.toggle('border-brand-lilac', x !== t);
    });
    const A = obtenerAjustes();
    if (t === 'planilla' && !document.getElementById('cp-ancho').value) { presetPapel(); document.getElementById('cp-sep').value = A.separacionPlanilla; presetCostoPlanilla(); document.getElementById('cp-min').value = A.minPlanilla; }
    if (t === 'rollo' && !document.getElementById('cr-ancho').value) { presetRollo(); document.getElementById('cr-sep').value = A.separacionRollo; }
    if (t === 'maquina' && !document.getElementById('cm-maq-min').value) { presetMaquina(); document.getElementById('cm-ganancia').value = A.ganancia; }
    if (t === 'planilla') calcularPlanilla(); if (t === 'rollo') calcularRollo(); if (t === 'maquina') calcularMaquina();
}
const num = id => parseFloat(document.getElementById(id).value);
function presetPapel() {
    const v = document.getElementById('cp-papel').value;
    if (v === 'custom') return;
    const [w, h] = v.split('x').map(Number);
    document.getElementById('cp-ancho').value = w; document.getElementById('cp-alto').value = h;
    document.getElementById('cp-margen').value = v === '20x28.5' ? 0 : obtenerAjustes().tabloideMargen;
}
function presetCostoPlanilla() {
    const A = obtenerAjustes(), m = document.getElementById('cp-material').value;
    let c = '';
    if (PAPELES[m]) c = A[PAPELES[m][0]] + A[PAPELES[m][1]];
    if (m === 'tatuaje') c = A.planillaTatuaje;
    document.getElementById('cp-costo').value = c;
}
let CALC_ULTIMO = {};
function calcularPlanilla() {
    const A = obtenerAjustes();
    const W = num('cp-ancho'), H = num('cp-alto'), mg = num('cp-margen') || 0, sep = num('cp-sep') || 0, w = num('cp-w'), h = num('cp-h'), q = parseInt(document.getElementById('cp-cant').value) || 0;
    const res = document.getElementById('cp-resultado'), svg = document.getElementById('cp-svg');
    if (!(W > 0 && H > 0 && w > 0 && h > 0 && q > 0)) { res.innerHTML = '<p class="text-sm text-gray-500">Completa las medidas y la cantidad.</p>'; svg.innerHTML = ''; return; }
    const uW = W - 2 * mg, uH = H - 2 * mg;
    if (uW <= 0 || uH <= 0) { res.innerHTML = '<p class="text-sm text-red-600">El margen es más grande que el papel.</p>'; svg.innerHTML = ''; return; }
    const ac = acomodar(w, h, uW, uH, sep, document.getElementById('cp-orient').value);
    if (!ac.rend) { res.innerHTML = '<p class="text-sm text-red-600">El diseño no cabe en el área útil con esa orientación.</p>'; svg.innerHTML = ''; return; }
    const lam = document.getElementById('cp-laminado').value;
    const costoPl = (num('cp-costo') || 0) + (lam ? A[lam] || 0 : 0);
    const minPl = num('cp-min') || 0;
    const planillas = Math.ceil(q / ac.rend);
    const material = planillas * costoPl, mo = planillas * minPl * A.horaTrabajo / 60, total = material + mo;
    const sobranteArea = 1 - (ac.rend * w * h) / (uW * uH);
    const sobranPiezas = planillas * ac.rend - q;
    const precio = redondearPrecio(precioConGanancia(total, A.ganancia, A.modoGanancia), A.redondeo);
    CALC_ULTIMO.planilla = { nombre: `Impresión en planilla ${w} × ${h} cm`, detalle: `${document.getElementById('cp-material').selectedOptions[0].text}${lam ? ', laminado ' + document.getElementById('cp-laminado').selectedOptions[0].text.toLowerCase() : ''}, ${ac.rend} por planilla`, cantidad: q, costoPedido: total };
    res.innerHTML = `
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-center tabular">
            ${kpi('Piezas por planilla', ac.rend, `${ac.rows} × ${ac.cols}${ac.rot ? ' · girada' : ''}`)}
            ${kpi('Planillas necesarias', planillas, sobranPiezas ? `sobran ${sobranPiezas} lugares` : 'exactas')}
            ${kpi('Material sin usar', Math.round(sobranteArea * 100) + '%', 'del área útil por planilla')}
            ${kpi('Costo total', fmt(total), `material ${fmt(material)} + tiempo ${fmt(mo)}`)}
            ${kpi('Costo por pieza', fmt(total / q), '')}
            ${kpi('Precio sugerido', fmt(precio), `${fmt(precio / q)} por pieza`, true)}
        </div>
        ${lam && !A[lam] ? '<p class="text-xs text-yellow-800 bg-yellow-50 rounded p-2 mt-3">El laminado no tiene costo capturado en Mis costos.</p>' : ''}
        <button onclick="agregarCalcACotizacion('planilla')" class="w-full mt-4 bg-brand-purple text-white font-semibold rounded-xl py-3"><i class="fa-solid fa-plus mr-1"></i> Agregar a la cotización</button>`;
    dibujarPlanillas(svg, { plW: W, plH: H, uW, uH, cols: ac.cols, rows: ac.rows, etqW: ac.etqW, etqH: ac.etqH, sep, rend: ac.rend }, q, 4);
}
function presetRollo() {
    const A = obtenerAjustes(), r = ROLLOS[document.getElementById('cr-material').value];
    document.getElementById('cr-ancho').value = A[r[1]]; document.getElementById('cr-precio').value = A[r[0]];
}
function calcularRollo() {
    const A = obtenerAjustes();
    const ancho = num('cr-ancho'), precio = num('cr-precio'), w = num('cr-w'), h = num('cr-h'), sep = num('cr-sep') || 0, q = parseInt(document.getElementById('cr-cant').value) || 0;
    const res = document.getElementById('cr-resultado'), svg = document.getElementById('cr-svg');
    if (!(ancho > 0 && w > 0 && h > 0 && q > 0)) { res.innerHTML = '<p class="text-sm text-gray-500">Completa las medidas y la cantidad.</p>'; svg.innerHTML = ''; return; }
    const ar = acomodarRollo(w, h, ancho, sep, q, document.getElementById('cr-rotar').checked);
    if (!ar) { res.innerHTML = `<p class="text-sm text-red-600">El diseño es más ancho que el rollo de ${ancho} cm.</p>`; svg.innerHTML = ''; return; }
    const metros = ar.largo / 100, material = metros * (precio || 0);
    const mo = q * (num('cr-min') || 0) * A.horaTrabajo / 60, total = material + mo;
    const precioSug = redondearPrecio(precioConGanancia(total, A.ganancia, A.modoGanancia), A.redondeo);
    const mat = document.getElementById('cr-material').value;
    CALC_ULTIMO.rollo = { nombre: `${mat} ${w} × ${h} cm`, detalle: `${ar.cols} por fila en rollo de ${ancho} cm`, cantidad: q, costoPedido: total };
    res.innerHTML = `
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 text-center tabular">
            ${kpi('Por fila', ar.cols, ar.rot ? 'diseño girado' : 'sin girar')}
            ${kpi('Largo necesario', metros.toFixed(2) + ' m', `${ar.filas} filas`)}
            ${kpi('Desperdicio', Math.round(ar.desperdicio * 100) + '%', 'del material usado')}
            ${kpi('Costo total', fmt(total), `material ${fmt(material)}${mo ? ' + tiempo ' + fmt(mo) : ''}`)}
            ${kpi('Costo por pieza', fmt(total / q), '')}
            ${kpi('Precio sugerido', fmt(precioSug), `${fmt(precioSug / q)} por pieza`, true)}
        </div>
        ${!precio ? '<p class="text-xs text-yellow-800 bg-yellow-50 rounded p-2 mt-3">Este material no tiene precio por metro capturado.</p>' : ''}
        <button onclick="agregarCalcACotizacion('rollo')" class="w-full mt-4 bg-brand-purple text-white font-semibold rounded-xl py-3"><i class="fa-solid fa-plus mr-1"></i> Agregar a la cotización</button>`;
    dibujarRollo(svg, { anchoRollo: ancho, cols: ar.cols, filas: ar.filas, etqW: ar.etqW, etqH: ar.etqH, sep, largo: ar.largo }, q);
}
function presetMaquina() {
    const A = obtenerAjustes();
    document.getElementById('cm-maq-min').value = document.getElementById('cm-maquina').value === 'laser' ? A.laserMin : A.cncMin;
}
function calcularMaquina() {
    const A = obtenerAjustes();
    const p = { cantidad: document.getElementById('cm-cant').value, costoMaterial: document.getElementById('cm-costo-mat').value, minCorte: document.getElementById('cm-corte').value,
        costoMaquinaMin: document.getElementById('cm-maq-min').value, minPreparacion: document.getElementById('cm-prep').value, minDiseno: document.getElementById('cm-diseno').value,
        atiendeCorte: document.getElementById('cm-atiende').checked, ganancia: document.getElementById('cm-ganancia').value };
    const r = calcularCorteMaquina(p, A);
    const maq = document.getElementById('cm-maquina').selectedOptions[0].text, mat = document.getElementById('cm-material').value.trim();
    CALC_ULTIMO.maquina = { nombre: `${maq}${mat ? ' en ' + mat : ''}`, detalle: `${p.minCorte} min de corte por pieza`, cantidad: r.q, costoPedido: r.costoTotal, precioManual: r.precioPieza };
    document.getElementById('cm-resultado').innerHTML = `
        <div class="grid grid-cols-2 gap-3 text-center tabular">
            ${kpi('Material', fmt(r.mat), `${r.q} piezas`)}
            ${kpi('Uso de máquina', fmt(r.maquina), `${(parseFloat(p.minCorte) || 0) * r.q} min de corte`)}
            ${kpi('Tu tiempo', fmt(r.mo), formatoMinutos(r.minutosTrabajo))}
            ${kpi('Costo total', fmt(r.costoTotal), `${fmt(r.costoPieza)} por pieza`)}
            ${kpi('Precio recomendado', fmt(r.precioPieza), 'por pieza', true)}
            ${kpi('Total', fmt(r.total), `ganas ${fmt(r.ganancia)} (${Math.round(r.margen)}% del precio)`, true)}
        </div>
        ${!(parseFloat(p.costoMaquinaMin) > 0) ? '<p class="text-xs text-yellow-800 bg-yellow-50 rounded p-2 mt-3">Captura el costo de uso de la máquina por minuto (luz, desgaste, fresas o tubo láser).</p>' : ''}
        <button onclick="agregarCalcACotizacion('maquina')" class="w-full mt-4 bg-brand-purple text-white font-semibold rounded-xl py-3"><i class="fa-solid fa-plus mr-1"></i> Agregar a la cotización</button>`;
}
function kpi(t, v, s, destacado) {
    return `<div class="rounded-xl p-3 ${destacado ? 'bg-brand-purple text-white' : 'bg-brand-bg border border-gray-100'}">
        <p class="text-[11px] ${destacado ? 'text-white/80' : 'text-gray-500'}">${t}</p><p class="text-lg font-bold font-display ${destacado ? 'text-[#FFE6A8]' : 'text-brand-textDark'}">${v}</p>
        ${s ? `<p class="text-[10px] ${destacado ? 'text-white/70' : 'text-gray-400'}">${s}</p>` : ''}</div>`;
}
function agregarCalcACotizacion(tipo) {
    const d = CALC_ULTIMO[tipo];
    if (!d) return;
    COT.items.push({ tipo: 'libre', nombre: d.nombre, detalle: d.detalle, cantidad: d.cantidad, costoPieza: 0, minPieza: 0, costoPedido: d.costoPedido, minPedido: 0,
        precioManual: d.precioManual || '', sinIndirectos: true, personalizacion: '' });
    cambiarTabCotizador('cotizar');
    toast('Agregado a la cotización');
}
