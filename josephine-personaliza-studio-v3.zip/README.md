# Personaliza Studio · Josephine | Personaliza y Crea

Sistema de cotización y administración para Josephine | Personaliza y Crea.
Esta es la **versión 3**: cotizador profesional (Etapa 2), pedidos, pagos, inventario y panel (Etapa 3) y el rediseño visual boutique.

**Dos formas de usarla:**
- `josephine-studio.html` — un solo archivo con todo adentro (fotos, estilos y código). Ábrelo con doble clic en Chrome.
- Esta carpeta — la misma página separada en archivos, ideal para GitHub Pages.

---

## 1. Qué hay en esta carpeta

```
index.html            Página principal (estructura de todas las secciones)
css/estilos.css       Estilos propios (los originales + los del cotizador nuevo)
js/costos.js          Motor de costos y precios (solo cálculos, se puede probar aparte)
js/acomodo.js         Dibujos del acomodo en planillas y rollos
js/cotizador.js       Pantalla del cotizador, historial, lista de precios, calculadoras, Mis costos
js/pdf.js             Cotización en PDF
js/utilidades.js      Fechas en hora local, avisos, exportar a Excel (CSV)
js/datos.js           Pedidos, pagos, ventas, gastos, inventario, migración y archivos
js/app.js             Navegación y arranque
js/pedidos.js         Pedidos: folio, estados, abonos, archivos, historial
js/finanzas.js        Gastos, ventas y cobranza
js/inventario.js      Inventario de materiales
js/panel.js           Panel de control y gráficas
js/catalogo.js        Catálogo de productos
img/catalogo/         Fotos de los productos
img/fichas/           Fichas del catálogo PDF
pruebas/              Pruebas de los cálculos (node pruebas/pruebas-costos.js)
```

## 2. Cómo instalarla

### En GitHub Pages
1. Abre tu repositorio en github.com.
2. Toca **Add file → Upload files** y arrastra **todo el contenido de esta carpeta** (index.html y las carpetas css, js, img y pruebas). Reemplaza el `index.html` anterior. (También puedes subir solo `josephine-studio.html` renombrado como `index.html`.)
3. Toca **Commit changes**. En uno o dos minutos tu link ya muestra la versión nueva.

### En tu computadora
Descomprime la carpeta y abre `index.html` con Chrome, Edge o Safari. Necesita internet para cargar el diseño (Tailwind), los íconos y el generador de PDF.

> **Tus datos no se pierden.** La versión nueva usa los mismos espacios de guardado del navegador que la anterior (`personalizaStudio_pedidos`, `_gastos`, `_ventas`, `_ajustesCostos`). Ábrela en el **mismo navegador y la misma dirección** donde ya capturabas y ahí estarán. Si cambias de dirección (por ejemplo de un archivo a GitHub), usa **Mis costos → Descargar respaldo** en la versión vieja y **Restaurar respaldo** en la nueva.

## 3. Cómo se usa el cotizador nuevo

1. **Cotizador → Cotizar.** Elige un producto, sus opciones y la cantidad. Abajo ves en vivo el precio por pieza, el total, tu costo y tu ganancia.
2. Si el trabajo lleva algo más (estampado en espalda, laminado, empaque, corte manual, material extra o tiempo extra), márcalo en **Procesos**. Lo que el producto ya incluye aparece como "Ya incluye" y no se puede volver a cobrar.
3. Escribe la **personalización** (nombres, tema, tallas): sale en el PDF.
4. Toca **Agregar a la cotización**. Repite con cada producto.
5. En la columna derecha pon el cliente, un descuento, un cargo extra (envío) o el cobro de diseño, y el anticipo.
6. **Descargar PDF**, **Imprimir** o **WhatsApp**. La primera vez se le asigna un folio (COT-AAAAMMDD-001) y se guarda en el **Historial**.
7. **Crear pedido** pasa todo a Pedidos para que solo revises y guardes.

**Calculadoras:** planillas (medida del papel, márgenes, separación y orientación), rollos de DTF y vinil (ancho configurable y opción de girar) y corte láser/CNC. Cada una puede **agregar su resultado a la cotización**.

**Mis costos:** datos del negocio y logotipo para el PDF, todos los costos y tiempos, merma, desgaste, gastos fijos por pedido, modo de ganancia (recargo o margen), escalas de mayoreo y redondeo. Abajo está el **respaldo**.

## 4. Fórmulas

| Concepto | Fórmula |
|---|---|
| Mano de obra | (minutos ÷ 60) × tu hora de trabajo |
| Tiempo | por pieza × cantidad + por planilla × planillas + por pedido |
| Merma y desgaste | material × (merma % + desgaste %) |
| Precio con **recargo** | costo × (1 + %) → 75% = costo × 1.75 |
| Precio con **margen** | costo ÷ (1 − %) → 40% = costo ÷ 0.60 |
| Mayoreo | precio de menudeo − descuento de la escala, nunca debajo de la ganancia mínima |
| Planillas | el precio se calcula por planilla completa y se divide entre las piezas que caben |
| Mínimo | si piden pocas piezas, se cobra al menos lo que cuestan las planillas usadas + ganancia mínima |
| Anticipo | total × % ; saldo = total − anticipo |

El cotizador avisa en **rojo** si el precio no cubre el costo y en **amarillo** si la ganancia queda debajo de tu mínimo.

## 5. Pruebas de los cálculos (con tus costos reales)

Se ejecutan con `node pruebas/pruebas-costos.js` (35 pruebas) y `node pruebas/pruebas-datos.js` (19 pruebas de migración, pagos y cuentas). Todas correctas. Algunos ejemplos:

| Caso | Resultado |
|---|---|
| Playera blanca + DTF 25×30: costo 45 + 37.50 + 15 min ($15) | Costo $97.50 → $175 / $160 / $140 |
| Cotización: 5 playeras + 2 sudaderas + 30 stickers 5 cm + 1 lona 1×1 m | $875 + $890 + $65 + $97 = **$1,927** |
| La misma con 10% de descuento | $1,734.30, anticipo 50% $867.15 |
| 30 stickers 5 cm (cabe 54 por planilla) | Se cobra el mínimo de 1 planilla: $46 × 1.40 → $65 |
| Taza con 40% de **margen** | $28 ÷ 0.60 = $46.67 → $47 (ganancia real 40% del precio) |
| Taza con precio especial de $25 | Aviso rojo: no cubre el costo de $28 |
| Set de tazas + "Empaque" | No se cobra: la caja ya está incluida |
| Láser: 10 piezas, $8 material, 4 min a $2/min, 30 min de preparación y diseño | Costo $190 → $34 por pieza |
| 23 diseños 10×10 en rollo de 58 cm con 0.5 cm de separación | 5 por fila, 52 cm de largo |

## 6. Etapa 1: análisis del archivo original

**Lo que tenía y se conserva:** inicio, catálogo, cotizador por producto, lista de precios, Mis costos, pedidos, gastos, ventas, panel de utilidad, anticipos y saldos, descuentos por volumen, acomodo en planillas, búsqueda y filtros, WhatsApp y todos los productos y precios.

**Problemas encontrados que quedan para la Etapa 3** (no se tocaron para no romper pedidos y ventas):
1. Las fechas usan hora UTC: después de las 6 pm el filtro "Hoy" y las ventas desde pedido se van al día siguiente.
2. Un pedido entregado se puede registrar como venta varias veces (ingresos duplicados).
3. "Esta semana" deja fuera registros del domingo.
4. Los gastos no se pueden editar (el campo existe pero no está conectado).
5. Todo vive en el navegador: no se comparte entre dispositivos y se pierde si se borran los datos.

## 7. Funciones implementadas y pendientes

**Etapa 2 · Cotizador (probado)**
- Cotización con varios productos; editar, duplicar, reordenar y eliminar partidas.
- Procesos incluidos vs. extras sin doble cobro; tiempo por pieza, planilla y pedido; merma, desgaste y gastos fijos.
- Recargo vs. margen, ganancia mínima, escalas configurables, precio especial, redondeo y avisos.
- Descuento, cargo extra, diseño aparte, anticipo y saldo; folio único e historial.
- PDF con marca (sin datos internos); descargar, imprimir y WhatsApp.
- Calculadoras de planilla, rollo y láser/CNC con vista previa.

**Etapa 3 · Administración (probado)**
- Pedidos con folio PED-0001, prioridad, estados Pendiente → Diseño → Aprobación → Producción → Listo → Entregado (y Cancelado).
- Abonos parciales con fecha y método; saldo siempre actualizado; anticipo al crear el pedido.
- Fotos y archivos del diseño por pedido (se guardan en el navegador, hasta 15 MB cada uno).
- Notas internas e historial de cambios automático.
- Al entregar se registra la venta una sola vez y pregunta si cobraste el saldo. Si el pedido regresa a otro estado, la venta se quita.
- Ventas, cobrado y por cobrar separados; lista de cuentas por cobrar.
- Gastos editables, con proveedor y filtros por periodo.
- Inventario: entradas (opcionalmente registradas como gasto), salidas, ajustes y aviso de materiales por agotarse.
- Panel de inicio: pedidos activos, entregas de hoy, atrasados, por cobrar, ventas, gastos, utilidad, inventario bajo, gráfica de 6 meses, productos más vendidos y pedidos por estado, con filtro de fechas.
- Exportar a Excel (CSV): pedidos, ventas, cobros, gastos e inventario.
- Validaciones y avisos de registros duplicados; protección contra doble clic.
- Errores corregidos: fechas en hora local, ventas duplicadas, "Esta semana" (empieza en lunes) y edición de gastos.
- Migración automática de tus datos anteriores sin borrarlos (se guarda una copia en `personalizaStudio_pedidos_v1_respaldo`).

**Rediseño**
- Paleta rosa chicle, durazno/coral, amarillo, verde agua y crema; tipografías Poppins, Fredoka y Sacramento.
- Barra superior verde agua, encabezado blanco con logotipo (usa el que subas en Mis costos), menú rosa, portada con flores, polaroids y sticker, tarjetas de acceso, favoritos y mensaje de marca.
- Mismo estilo en catálogo, cotizador, pedidos, ventas, gastos, inventario y configuración; menú inferior en celular.

**Pendiente**
- **Etapa 4:** inicio de sesión, roles, portal de clientes y base de datos en línea (ver abajo).
- Compartir el PDF directo por WhatsApp funciona en celular; en computadora se descarga y se abre WhatsApp para adjuntarlo.

## 8. Etapa 4: lo que vas a necesitar para usuarios y base de datos

Una página en GitHub Pages **no puede** proteger información por sí sola: cualquier cosa escondida con JavaScript se puede ver. Para accesos reales hace falta un servicio con base de datos y autenticación. Propuesta: **Supabase** (tiene plan gratuito).

Lo que tendrías que hacer tú:
1. Crear una cuenta en supabase.com y un proyecto (región más cercana a México).
2. Pasarme la **Project URL** y la **anon public key** (son públicas por diseño). **Nunca** compartas la *service_role key*.
3. Activar el inicio de sesión por correo.

Lo que se construiría:
- Tablas: perfiles (rol: administrador, empleado, cliente), clientes, cotizaciones, partidas, pedidos, pagos, gastos, ventas, inventario, historial de cambios y costos.
- **Políticas de seguridad en la base de datos (RLS):** un cliente solo puede leer sus propios pedidos y cotizaciones, nunca costos; los empleados solo lo que tú autorices; el administrador todo.
- Los costos y márgenes vivirían en tablas que el rol cliente no puede leer.
- Migración: el respaldo JSON de esta versión se sube una sola vez, sin borrar nada del navegador hasta que confirmes que todo llegó.
