// Pruebas de pedidos, pagos y cuentas. Ejecutar con: node pruebas/pruebas-datos.js
const mem = {}; global.localStorage = { getItem: k => mem[k] ?? null, setItem: (k, v) => mem[k] = String(v) };
Object.assign(global, require('../js/utilidades.js'));
global.formatoMoneda = v => '$' + Number(v).toFixed(2);
global.nuevoId = (() => { let i = 1; return () => i++; })();
const D = require('../js/datos.js');
let ok = 0, mal = 0;
const igual = (n, r, e) => { const p = JSON.stringify(r) === JSON.stringify(e); p ? ok++ : mal++; console.log(`${p ? '✔' : '✘'} ${n}: ${JSON.stringify(r)}${p ? '' : ' (esperado ' + JSON.stringify(e) + ')'}`); };

// Datos como los guardaba la versión anterior
const pedidosV1 = [
  { id: 100, cliente: 'Ana', producto: 'Tazas', cantidad: '10', fecha: '2026-10-01', entrega: '2026-10-05', precio: '490', anticipo: '200', saldo: '290', estado: '🟢 Entregado' },
  { id: 200, cliente: 'Luis', producto: 'Playeras', cantidad: '20', fecha: '2026-10-10', entrega: '2026-10-20', precio: '3500', anticipo: '1750', saldo: '1750', estado: '🔵 En producción' },
  { id: 300, cliente: 'Eva', producto: 'Lona', cantidad: '1', fecha: '2026-10-12', entrega: '2026-10-14', precio: '160', anticipo: '0', saldo: '160', estado: '🔴 Cancelado' },
];
const ventasV1 = [
  { id: 1, fecha: '2026-10-05', cliente: 'Ana', producto: 'Tazas', cantidad: '10', precio: 490, pago: '💵 Efectivo', observaciones: 'Convertido desde pedido #100' },
  { id: 2, fecha: '2026-10-06', cliente: 'Ana', producto: 'Tazas', cantidad: '10', precio: 490, pago: '💵 Efectivo', observaciones: 'Convertido desde pedido #100' },
  { id: 3, fecha: '2026-10-08', cliente: 'Mostrador', producto: 'Stickers', cantidad: '50', precio: 120, pago: '🏦 Transferencia', observaciones: '' },
];
const r = D.migrarDatos(pedidosV1, ventasV1);
const [ana, luis, eva] = r.pedidos;
igual('Folios por orden', r.pedidos.map(p => p.folio), ['PED-0001', 'PED-0002', 'PED-0003']);
igual('Estados nuevos', r.pedidos.map(p => p.estado), ['entregado', 'produccion', 'cancelado']);
igual('Anticipo de Ana pasa a pago', ana.pagos[0].monto, 200);
igual('Saldo que Ana pagó al convertir la venta se registra (290, efectivo)', [ana.pagos[1].monto, ana.pagos[1].metodo], [290, 'Efectivo']);
igual('Ana queda sin deuda', D.saldoPedido(ana), 0);
igual('Venta duplicada marcada, no borrada', r.ventas.map(v => !!v.duplicada), [false, true, false]);
igual('Luis debe 1750', D.saldoPedido(luis), 1750);
igual('Cancelado no debe nada', D.saldoPedido(eva), 0);
igual('Los datos originales no se modifican', pedidosV1[0].estado, '🟢 Entregado');
const r2 = D.migrarDatos(r.pedidos, r.ventas);
igual('Migrar dos veces no cambia nada', r2.cambios, 0);

const rango = { desde: '2026-10-01', hasta: '2026-10-31' };
const gastos = [{ fecha: '2026-10-03', monto: 300 }, { fecha: '2026-09-30', monto: 999 }];
const res = D.resumenFinanciero(rango, r.pedidos, r.ventas, gastos);
igual('Ventas de octubre (490 + 120, sin la duplicada)', res.ventas, 610);
igual('Cobrado (200 + 290 Ana + 1750 Luis + 120 mostrador)', res.cobrado, 2360);
igual('Gastos de octubre', res.gastos, 300);
igual('Utilidad estimada', res.utilidad, 310);
igual('Por cobrar', res.porCobrar, 1750);
const top = D.productosMasVendidos(rango, r.pedidos, r.ventas);
igual('Más vendido', top[0].nombre, 'Stickers');
igual('Entrega atrasada', D.entregaInfo(luis, '2026-10-22').tipo, 'atrasado');
igual('Rango semana empieza en lunes', rangoPeriodo('semana').desde <= hoyISO(), true);
igual('Fecha local (no UTC)', hoyISO(), fechaISO(new Date()));
console.log(`\n${ok} pruebas correctas, ${mal} con error`); process.exit(mal ? 1 : 0);
