// Pruebas del motor de costos. Ejecutar con:  node pruebas/pruebas-costos.js
global.localStorage = { getItem: () => null, setItem: () => {} };
const M = require('../js/costos.js');
const A = { ...M.AJUSTES_BASE };
let ok = 0, mal = 0;
function igual(nombre, real, esperado) {
    const pasa = Math.abs(real - esperado) < 0.011;
    pasa ? ok++ : mal++;
    console.log(`${pasa ? '✔' : '✘'} ${nombre}: ${real} ${pasa ? '' : '(esperado ' + esperado + ')'}`);
}
const it = (productoId, opciones, cantidad, extra) => M.cotizarItem({ tipo: 'catalogo', productoId, opciones, cantidad, ...(extra || {}) }, A);

// 1. Precios de la versión anterior (no deben cambiar con la configuración original)
let r = it('playera', { talla: 'Adulto', color: 'Blanca', est: 'Mediano 25 × 30 cm' }, 1);
igual('Playera blanca mediano: costo', r.costoUnit, 97.5);
igual('Playera blanca mediano: 1-29', r.escalas[0].precio, 175);
igual('Playera blanca mediano: 30-99', r.escalas[1].precio, 160);
igual('Playera blanca mediano: 100+', r.escalas[2].precio, 140);
r = it('sudadera', { est: 'Mediano 25 × 30 cm' }, 1); igual('Sudadera mediano 1-29', r.escalas[0].precio, 445);
r = it('taza', {}, 1); igual('Taza costo', r.costoUnit, 28); igual('Taza 1-29', r.escalas[0].precio, 49);
r = it('vaso_mini', {}, 1); igual('Vaso mini costo', r.costoUnit, 30.57);
r = it('tatuajes', { tam: '5 cm' }, 25); igual('25 tatuajes 5 cm (mínimo 2 planillas)', r.total, 170);
r = it('lonas', { medida: 'Medida personalizada', anchoM: 1.5, altoM: 1 }, 1); igual('Lona 1.5 × 1 m', r.total, 140);
r = it('medida', { material: 'DTF textil', ancho: 5, alto: 5 }, 40); igual('40 DTF 5×5 cm', r.total, 80);
r = it('stickers', { forma: 'Circular', tam: '5 cm' }, 54); igual('Stickers 5 cm: planilla completa', r.escalas[0].precioLote, 81);
igual('Stickers 5 cm: piezas por planilla', r.info.rend, 54);

// 2. Cotización con varios productos
const cot = {
    items: [
        { tipo: 'catalogo', productoId: 'playera', opciones: { talla: 'Adulto', color: 'Blanca', est: 'Mediano 25 × 30 cm' }, cantidad: 5 },
        { tipo: 'catalogo', productoId: 'sudadera', opciones: { est: 'Mediano 25 × 30 cm' }, cantidad: 2 },
        { tipo: 'catalogo', productoId: 'stickers', opciones: { forma: 'Circular', tam: '5 cm' }, cantidad: 30 },
        { tipo: 'catalogo', productoId: 'lonas', opciones: { medida: '1 × 1 m' }, cantidad: 1 }],
    descuento: { tipo: '%', valor: 0 }, anticipoPct: 50
};
let c = M.cotizarCotizacion(cot, A);
igual('5 playeras', c.partidas[0].total, 875);
igual('2 sudaderas', c.partidas[1].total, 890);
igual('30 stickers 5 cm (mínimo de 1 planilla: 46 × 1.40 = 64.40 → 65)', c.partidas[2].total, 65);
igual('1 lona 1×1', c.partidas[3].total, 97);
igual('Total', c.total, 1927);
igual('Anticipo 50%', c.anticipo, 963.5);
igual('Saldo', c.saldo, 963.5);
cot.descuento = { tipo: '%', valor: 10 };
c = M.cotizarCotizacion(cot, A);
igual('Descuento 10%', c.descuento, 192.7); igual('Total con descuento', c.total, 1734.3);

// 3. Procesos extra y doble cobro
r = it('playera', { talla: 'Adulto', color: 'Blanca', est: 'Mediano 25 × 30 cm' }, 1, { extras: { dtf_adicional: { on: true, valor: 'Grande 30 × 40 cm' } } });
igual('Playera + DTF espalda grande: costo', r.costoUnit, 97.5 + 75);
r = it('set_tazas', {}, 1, { extras: { empaque: { on: true } } });
igual('Set de tazas: el empaque ya incluido no se cobra otra vez', r.costoUnit, 136);
const A2 = { ...A, laminadoMate: 12 };
r = M.cotizarItem({ tipo: 'catalogo', productoId: 'stickers', opciones: { forma: 'Circular', tam: '5 cm' }, cantidad: 54, extras: { laminado: { on: true, valor: 'Mate' } } }, A2);
igual('Stickers + laminado mate $12: costo planilla', r.costoUnit * 54, 46 + 12);

// 4. Margen sobre venta vs recargo sobre costo
const Am = { ...A, modoGanancia: 'margen', ganancia: 40, margenMinimo: 25 };
r = M.cotizarItem({ tipo: 'catalogo', productoId: 'taza', opciones: {}, cantidad: 1 }, Am);
igual('Taza con 40% de margen: 28 ÷ 0.60 = 46.67 → 47', r.escalas[0].precio, 47);
igual('Margen real sobre el precio (%)', Math.round(r.margen), 40);

// 5. Precio personalizado debajo del costo → aviso
r = it('taza', {}, 10, { precioManual: 25 });
igual('Taza a $25 x10', r.total, 250);
console.log('   aviso:', r.avisos.map(a => a.msg).join(' | '));
igual('Aviso de pérdida generado', r.avisos.filter(a => a.tipo === 'perdida').length, 1);

// 6. Merma y desgaste
const A3 = { ...A, mermaPct: 5, desgastePct: 3 };
r = M.cotizarItem({ tipo: 'catalogo', productoId: 'taza', opciones: {}, cantidad: 1 }, A3);
igual('Taza con 5% merma + 3% desgaste: 23×1.08 + 5', r.costoUnit, 23 * 1.08 + 5);

// 7. Acomodo con separación
const ac = M.acomodar(5, 5, 45, 30, 0.3, 'auto');
igual('Stickers 5 cm con 0.3 cm de separación: piezas', ac.rend, 8 * 5);
const ro = M.acomodarRollo(10, 10, 58, 0.5, 23, true);
igual('23 diseños 10×10 en rollo 58 cm (sep 0.5): por fila', ro.cols, 5);
igual('largo (cm)', ro.largo, 5 * 10 + 4 * 0.5);

// 8. Láser / CNC
const L = M.calcularCorteMaquina({ cantidad: 10, costoMaterial: 8, minCorte: 4, costoMaquinaMin: 2, minPreparacion: 10, minDiseno: 20, atiendeCorte: false, ganancia: 75 }, A);
igual('Láser 10 pzs: costo total (80 + 80 + 30)', L.costoTotal, 190);
igual('Láser: precio por pieza 19 × 1.75 = 33.25 → 34', L.precioPieza, 34);

console.log(`\n${ok} pruebas correctas, ${mal} con error`);
process.exit(mal ? 1 : 0);
